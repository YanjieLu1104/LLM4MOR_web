import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite JSON number")
    if isinstance(value, dict):
        for child in value.values():
            check_finite(child)
    elif isinstance(value, list):
        for child in value:
            check_finite(child)


def require(container, key, source):
    if key not in container or container[key] is None:
        raise ValueError("Missing required field: " + source + "." + key)
    return container[key]


def integer(value, source):
    if type(value) is not int:
        raise ValueError(source + " must be an integer")
    return value


def decode_index_set(value, source):
    if not isinstance(value, dict):
        raise ValueError(source + " must be an encoded index set")
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(source + ".range must contain two bounds")
        lower = integer(bounds[0], source + ".range[0]")
        upper = integer(bounds[1], source + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(source + ".set must be an array")
        elements = [
            integer(element, source + ".set") for element in elements
        ]
        if len(set(elements)) != len(elements):
            raise ValueError(source + " contains duplicate indices")
        return sorted(elements)
    raise ValueError(source + " has an invalid index-set encoding")


def decode_array(value, dimensions, source):
    if not isinstance(value, dict):
        raise ValueError(source + " must be an encoded array")
    elements = require(value, "array", source)
    encoded_sets = require(value, "index_sets", source)
    if not isinstance(elements, list):
        raise ValueError(source + ".array must be a list")
    if not isinstance(encoded_sets, list) or len(encoded_sets) != dimensions:
        raise ValueError(source + " has the wrong number of dimensions")
    domains = [
        decode_index_set(encoded, source + ".index_sets[" + str(position) + "]")
        for position, encoded in enumerate(encoded_sets)
    ]
    count = 1
    for domain in domains:
        count *= len(domain)
    if len(elements) != count:
        raise ValueError(source + " has inconsistent dimensions")
    for element in elements:
        integer(element, source + ".array")
    return elements, domains


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(payload)

    variables = require(payload, "variables", "input")
    x_encoded = require(variables, "x", "variables")
    x_values, x_domains = decode_array(x_encoded, 1, "variables.x")
    if any(value not in (0, 1) for value in x_values):
        raise ValueError("variables.x contains a nonbinary value")

    if "bVar" in variables and variables["bVar"] is not None:
        bvar_encoded = variables["bVar"]
        decode_array(bvar_encoded, 1, "variables.bVar")
    else:
        parameters = require(payload, "parameters", "input")
        a_encoded = require(parameters, "a", "parameters")
        a_values, a_domains = decode_array(a_encoded, 2, "parameters.a")
        rows, columns = a_domains
        if columns != x_domains[0]:
            raise ValueError(
                "parameters.a column indices do not match variables.x indices"
            )
        width = len(columns)
        loads = [
            sum(
                a_values[row_position * width + column_position]
                * x_values[column_position]
                for column_position in range(width)
            )
            for row_position in range(len(rows))
        ]
        bvar_encoded = {
            "array": loads,
            "index_sets": [a_encoded["index_sets"][0]],
        }

    result = {"variables": {"x": x_encoded, "bVar": bvar_encoded}}
    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(result, handle, allow_nan=False)
        handle.write("\n")


if __name__ == "__main__":
    main()