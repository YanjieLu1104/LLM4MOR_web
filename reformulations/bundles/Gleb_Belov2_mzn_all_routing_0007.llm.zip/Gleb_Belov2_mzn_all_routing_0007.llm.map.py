import json
import math
import sys


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the reformulated model's "
            "default DZN solution.".format(name)
        )
    return variables[name]


def integer_value(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected integer at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected finite integer at " + path)
    return int(value)


def index_size(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected encoded index set at " + path)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = integer_value(bounds[0], path + ".range[0]")
        upper = integer_value(bounds[1], path + ".range[1]")
        return max(0, upper - lower + 1)
    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        integers = [
            integer_value(item, path + ".set") for item in elements
        ]
        if len(set(integers)) != len(integers):
            raise ValueError("Repeated index at " + path)
        return len(integers)
    raise ValueError("Invalid encoded index set at " + path)


def copy_integer_array(variables, name, dimensions):
    value = require_variable(variables, name)
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid MiniZinc array at " + path)
    if len(index_sets) != dimensions:
        raise ValueError("Incorrect array dimension at " + path)
    count = 1
    for axis, encoded in enumerate(index_sets):
        count *= index_size(
            encoded, "{}.index_sets[{}]".format(path, axis)
        )
    if count != len(elements):
        raise ValueError("Array size does not match index sets at " + path)
    return {
        "array": [
            integer_value(item, "{}.array[{}]".format(path, position))
            for position, item in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Expected a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object.")
    variables = payload["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 153,
        "nXNd__1_1_Y": 51,
        "nXNd__1_1_Z": 13,
        "nXNd__1_10_X": 168,
        "nXNd__1_10_Y": 52,
        "nXNd__1_10_Z": 76,
    }

    for node in range(1, 11):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            if name in fixed_coordinates:
                if name in variables and variables[name] is not None:
                    restored[name] = integer_value(
                        variables[name], "variables." + name
                    )
                else:
                    restored[name] = fixed_coordinates[name]
            else:
                restored[name] = integer_value(
                    require_variable(variables, name), "variables." + name
                )

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        restored[name] = copy_integer_array(variables, name, 2)

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        restored[name] = copy_integer_array(variables, name, 1)

    restored["obj"] = integer_value(
        require_variable(variables, "obj"), "variables.obj"
    )
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(result, stream, allow_nan=False, separators=(",", ":"))
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)