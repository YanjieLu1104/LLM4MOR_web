import json
import math
import sys


ORDER_NAMES = (
    "chooseOrder200", "chooseOrder234", "chooseOrder270",
    "chooseOrder308", "chooseOrder348", "chooseOrder390",
    "chooseOrder434", "chooseOrder480", "chooseOrder528",
    "chooseOrder578", "chooseOrder630", "chooseOrder684",
    "chooseOrder740", "chooseOrder798",
)

LIST_NAMES = (
    "listget899", "listget1112", "listget2256", "listget2966",
    "listget3676", "listget4386", "listget5096", "listget5806",
    "listget6516", "listget7226", "listget7936", "listget8646",
    "listget9356", "listget10066",
)

CHOSEN_NAMES = (
    "chosenIndex964", "chosenIndex1163", "chosenIndex2307",
    "chosenIndex3017", "chosenIndex3727", "chosenIndex4437",
    "chosenIndex5147", "chosenIndex5857", "chosenIndex6567",
    "chosenIndex7277", "chosenIndex7987", "chosenIndex8697",
    "chosenIndex9407", "chosenIndex10117",
)

LOCATION_NAMES = (
    "initialFieldValueslocationID966",
    "initialFieldValueslocationID1165",
    "initialFieldValueslocationID2309",
    "initialFieldValueslocationID3019",
    "initialFieldValueslocationID3729",
    "initialFieldValueslocationID4439",
    "initialFieldValueslocationID5149",
    "initialFieldValueslocationID5859",
    "initialFieldValueslocationID6569",
    "initialFieldValueslocationID7279",
    "initialFieldValueslocationID7989",
    "initialFieldValueslocationID8699",
    "initialFieldValueslocationID9409",
    "initialFieldValueslocationID10119",
)

ROW_NAMES = (
    "mapget1182", "mapget2326", "mapget3036", "mapget3746",
    "mapget4456", "mapget5166", "mapget5876", "mapget6586",
    "mapget7296", "mapget8006", "mapget8716", "mapget9426",
    "mapget10136", "mapget10786",
)

LEG_NAMES = (
    "mapget1645", "mapget2355", "mapget3065", "mapget3775",
    "mapget4485", "mapget5195", "mapget5905", "mapget6615",
    "mapget7325", "mapget8035", "mapget8745", "mapget9455",
    "mapget10165",
)

ARRIVAL_NAMES = (
    "expectedArrivalTime11026", "expectedArrivalTime11029",
    "expectedArrivalTime11040", "expectedArrivalTime11043",
    "expectedArrivalTime11054", "expectedArrivalTime11057",
    "expectedArrivalTime11068", "expectedArrivalTime11071",
    "expectedArrivalTime11082", "expectedArrivalTime11085",
    "expectedArrivalTime11096", "expectedArrivalTime11099",
    "expectedArrivalTime11110", "expectedArrivalTime11113",
)

ARRIVAL_INDEX_NAMES = (
    "expectedArrivalTimeX14", "expectedArrivalTimeX15",
    "expectedArrivalTimeX16", "expectedArrivalTimeX17",
    "expectedArrivalTimeX18", "expectedArrivalTimeX19",
    "expectedArrivalTimeX20", "expectedArrivalTimeX21",
    "expectedArrivalTimeX22", "expectedArrivalTimeX23",
    "expectedArrivalTimeX24", "expectedArrivalTimeX25",
    "expectedArrivalTimeX26", "expectedArrivalTimeX27",
)

# Fixed data from the original self-contained main model.
DEPOT = (6, 9, 14, 15, 10, 15, 13, 18, 10, 13, 6, 9, 2, 7)

DISTANCE = (
    (0,8,15,7,14,13,11,3,1,1,19,15,18,15),
    (8,0,5,19,18,3,20,6,16,9,10,6,9,1),
    (15,5,0,9,4,17,15,15,15,1,5,9,3,14),
    (7,19,9,0,3,10,20,1,16,18,5,20,2,6),
    (14,18,4,3,0,17,19,7,1,13,1,17,9,2),
    (13,3,17,10,17,0,14,4,18,14,12,16,6,2),
    (11,20,15,20,19,14,0,16,18,17,7,19,10,17),
    (3,6,15,1,7,4,16,0,18,16,4,3,20,11),
    (1,16,15,16,1,18,18,18,0,17,19,8,16,15),
    (1,9,1,18,13,14,17,16,17,0,17,13,20,13),
    (19,10,5,5,1,12,7,4,19,17,0,12,11,15),
    (15,6,9,20,17,16,19,3,8,13,12,0,18,16),
    (18,9,3,2,9,6,10,20,16,20,11,18,0,15),
    (15,1,14,6,2,2,17,11,15,13,15,16,15,0),
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Input contains a non-finite number")
    if isinstance(value, dict):
        for nested in value.values():
            check_finite(nested)
    elif isinstance(value, list):
        for nested in value:
            check_finite(nested)


def read_integer(variables, name):
    if name not in variables:
        raise ValueError(
            "Missing variables." + name
            + "; required source: default DZN solution of the reformulated model"
        )
    value = variables[name]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("variables." + name + " must be an integer")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("variables." + name + " must be a finite integer")
    return int(value)


def reconstruct(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    order = [read_integer(variables, name) for name in ORDER_NAMES]
    count = len(ORDER_NAMES)
    if sorted(order) != list(range(count)):
        raise ValueError(
            "The chooseOrder variables must form a permutation of "
            + "0.." + str(count - 1)
        )

    # route[position] is the zero-based location identity.
    route = sorted(range(count), key=lambda node: order[node])
    legs = [
        DISTANCE[route[position]][route[position + 1]]
        for position in range(count - 1)
    ]
    prefix = [DEPOT[route[0]]]
    for cost in legs:
        prefix.append(prefix[-1] + cost)

    result = dict(zip(ORDER_NAMES, order))

    for position, node in enumerate(route):
        location = node + 1
        result[LIST_NAMES[position]] = node + 6
        result[LIST_NAMES[position] + "X"] = node + 2
        result[CHOSEN_NAMES[position]] = node
        result[LOCATION_NAMES[position]] = location
        result[ROW_NAMES[position]] = location + 30
        result[ROW_NAMES[position] + "X"] = location

    result["mapget1048"] = DEPOT[route[0]]
    result["mapget1048X"] = route[0] + 1
    result["mapget10815"] = DEPOT[route[-1]]
    result["mapget10815X"] = route[-1] + 1

    for position, name in enumerate(LEG_NAMES):
        result[name] = legs[position]
        result[name + "X"] = (
            count * route[position] + route[position + 1] + 1
        )

    for node, position in enumerate(order):
        result[ARRIVAL_NAMES[node]] = prefix[position]
        result[ARRIVAL_INDEX_NAMES[node]] = position + 2

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(payload)
    result = reconstruct(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(result, stream, allow_nan=False, separators=(",", ":"))
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)