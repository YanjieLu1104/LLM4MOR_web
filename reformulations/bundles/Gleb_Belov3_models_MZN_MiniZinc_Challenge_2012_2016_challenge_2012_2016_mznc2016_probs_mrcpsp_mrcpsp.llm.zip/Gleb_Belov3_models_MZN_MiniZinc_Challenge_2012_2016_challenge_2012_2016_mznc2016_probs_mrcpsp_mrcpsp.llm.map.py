import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, child in value.items():
            check_finite(child, path + "." + key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            check_finite(child, path + "[" + str(index) + "]")


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(data, "input")

    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")
    if "parameters" not in data or not isinstance(data["parameters"], dict):
        raise ValueError("Missing or invalid input field: parameters")

    variables = data["variables"]
    parameters = data["parameters"]
    restored = {}

    for name in ("mrun", "start", "objective"):
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in parameters and parameters[name] is not None:
            restored[name] = parameters[name]
        else:
            raise ValueError(
                "Missing original variable "
                + name
                + ": expected variables."
                + name
                + " from default DZN solution output, or parameters."
                + name
                + " if externally fixed and exported as original instance data"
            )

    for name in ("mrun", "start"):
        value = restored[name]
        if (
            not isinstance(value, dict)
            or "array" not in value
            or "index_sets" not in value
            or not isinstance(value["array"], list)
            or not isinstance(value["index_sets"], list)
            or len(value["index_sets"]) != 1
        ):
            raise ValueError(
                "Invalid array encoding for " + name
                + ": expected array and one index set"
            )

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            ensure_ascii=False,
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)