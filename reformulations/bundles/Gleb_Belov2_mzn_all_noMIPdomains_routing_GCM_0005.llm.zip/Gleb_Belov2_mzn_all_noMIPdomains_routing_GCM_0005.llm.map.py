import json
import math
import sys


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from the solver's default "
            "DZN solution.".format(name)
        )
    return variables[name]


def map_solution(document):
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = document["variables"]
    result = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 246,
        "nXNd__1_1_Y": 52,
        "nXNd__1_1_Z": 200,
        "nXNd__1_10_X": 309,
        "nXNd__1_10_Y": 96,
        "nXNd__1_10_Z": 80,
    }

    for name, fixed_value in fixed_coordinates.items():
        if name in variables and variables[name] is not None:
            result[name] = variables[name]
        else:
            result[name] = fixed_value

    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            result[name] = require_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        result[name] = require_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    elif "objective" in document and document["objective"] is not None:
        value = document["objective"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(value, float):
            if not math.isfinite(value) or not value.is_integer():
                raise ValueError("objective must be a finite integer-valued number")
        result["obj"] = int(value)
    else:
        raise ValueError(
            "Missing variables.obj and objective: the unchanged original "
            "objective variable must come from the solver solution."
        )

    check_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")

    check_finite(document, "input")
    mapped = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()