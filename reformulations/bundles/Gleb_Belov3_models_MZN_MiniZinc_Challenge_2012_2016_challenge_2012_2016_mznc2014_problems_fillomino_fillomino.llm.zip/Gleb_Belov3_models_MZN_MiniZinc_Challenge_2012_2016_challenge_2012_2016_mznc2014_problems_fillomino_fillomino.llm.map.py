import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("All JSON numbers must be finite")
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload)

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required input field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Input field variables must be a JSON object")

    restored = {}
    for name in ("size", "area", "when", "what"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables."
                + name
                + "; its source must be the reformulated model's "
                + "default DZN solution output"
            )
        restored[name] = variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            ensure_ascii=False,
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)