import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def required_number(values, key, prefix):
    if key not in values:
        raise ValueError("Missing required field: " + prefix + key)
    value = values[key]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected numeric value for " + prefix + key)
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite value for " + prefix + key)
    return value


def required_dimension(parameters, name):
    value = required_number(parameters, name, "parameters.")
    if value < 0 or value != int(value):
        raise ValueError("Expected nonnegative integer for parameters." + name)
    return int(value)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    for field in ("parameters", "variables"):
        if field not in payload:
            raise ValueError("Missing required field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError("Expected an object for " + field)

    parameters = payload["parameters"]
    variables = payload["variables"]

    num_node = required_dimension(parameters, "num_node")
    num_comp = required_dimension(parameters, "num_comp")
    dist = required_number(parameters, "dist", "parameters.")

    restored = {}

    def copy_value(name):
        restored[name] = required_number(variables, name, "variables.")

    for u in range(1, num_node + 1):
        for i in range(1, num_comp + 1):
            copy_value(f"c[{u},{i}]")
            copy_value(f"y[{u},{i}]")

        for v in range(1, num_node + 1):
            name = f"x[{u},{v}]"
            if 0 < v - u <= dist:
                copy_value(name)
            else:
                restored[name] = 0

        for i in range(1, num_comp + 1):
            for j in range(1, num_comp + 1):
                name = f"cc[{u},{i},{j}]"
                if i < j:
                    copy_value(name)
                else:
                    restored[name] = 0

            for v in range(1, num_node + 1):
                name = f"cx[{u},{i},{v}]"
                if 0 < v - u <= dist:
                    copy_value(name)
                else:
                    restored[name] = 0

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": restored},
            stream,
            allow_nan=False,
            separators=(",", ":"),
        )
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)