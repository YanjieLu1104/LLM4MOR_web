import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload)

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    required = ("s", "l", "makespan", "start", "line", "followed")
    restored = {}

    for name in required:
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing original decision variable "
                + name
                + "; required source: variables."
                + name
                + " in the reformulated solver's default DZN solution"
            )
        restored[name] = variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": restored},
            stream,
            ensure_ascii=False,
            allow_nan=False,
        )
        stream.write("\n")


if __name__ == "__main__":
    main()