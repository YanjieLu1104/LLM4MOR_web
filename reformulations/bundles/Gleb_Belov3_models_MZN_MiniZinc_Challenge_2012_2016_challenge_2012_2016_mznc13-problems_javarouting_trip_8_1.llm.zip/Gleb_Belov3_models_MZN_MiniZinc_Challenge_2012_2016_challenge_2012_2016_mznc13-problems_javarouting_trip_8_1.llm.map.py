import json
import sys


ORDER_SUFFIXES = (
    258, 296, 336, 378, 422, 468, 516, 566,
    618, 672, 728, 786, 846, 908, 972, 1038,
)

LIST_SUFFIXES = (
    1151, 1388, 2850, 3752, 4654, 5556, 6458, 7360,
    8262, 9164, 10066, 10968, 11870, 12772, 13674, 14576,
)

CHOSEN_SUFFIXES = (
    1224, 1445, 2907, 3809, 4711, 5613, 6515, 7417,
    8319, 9221, 10123, 11025, 11927, 12829, 13731, 14633,
)

LOCATION_SUFFIXES = (
    1226, 1447, 2909, 3811, 4713, 5615, 6517, 7419,
    8321, 9223, 10125, 11027, 11929, 12831, 13733, 14635,
)

COST_SUFFIXES = (
    1316, 2057, 2959, 3861, 4763, 5665, 6567, 7469,
    8371, 9273, 10175, 11077, 11979, 12881, 13783, 14685,
    15521,
)

ROW_SUFFIXES = (
    1464, 2926, 3828, 4730, 5632, 6534, 7436, 8338,
    9240, 10142, 11044, 11946, 12848, 13750, 14652, 15488,
)

ARRIVAL_SUFFIXES = (
    15784, 15787, 15798, 15801, 15812, 15815, 15826, 15829,
    15840, 15843, 15854, 15857, 15868, 15871, 15882, 15885,
)


def original_variable_names():
    names = []
    names.extend("chooseOrder" + str(s) for s in ORDER_SUFFIXES)
    names.extend("listget" + str(s) for s in LIST_SUFFIXES)
    names.extend("chosenIndex" + str(s) for s in CHOSEN_SUFFIXES)
    names.extend(
        "initialFieldValueslocationID" + str(s)
        for s in LOCATION_SUFFIXES
    )
    names.extend("mapget" + str(s) for s in COST_SUFFIXES)
    names.extend("mapget" + str(s) for s in ROW_SUFFIXES)
    names.extend("expectedArrivalTime" + str(s) for s in ARRIVAL_SUFFIXES)
    names.extend("expectedArrivalTimeX" + str(s) for s in range(16, 32))
    names.extend("listget" + str(s) + "X" for s in LIST_SUFFIXES)
    names.extend("mapget" + str(s) + "X" for s in COST_SUFFIXES)
    names.extend("mapget" + str(s) + "X" for s in ROW_SUFFIXES)
    return names


def reject_constant(value):
    raise ValueError("Non-finite JSON number is not permitted: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required input field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Input field variables must be a JSON object")

    required = original_variable_names()
    missing = [name for name in required if name not in variables]
    if missing:
        raise ValueError(
            "Missing original variables from the reformulated model's "
            "default DZN solution: " + ", ".join(missing)
        )

    absent = [name for name in required if variables[name] is None]
    if absent:
        raise ValueError(
            "Original variables have absent solution values: "
            + ", ".join(absent)
        )

    result = {"variables": {name: variables[name] for name in required}}
    encoded = json.dumps(result, allow_nan=False, separators=(",", ":"))

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        destination.write(encoded)
        destination.write("\n")


if __name__ == "__main__":
    main()