import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("All JSON numbers must be finite")
    elif isinstance(value, list):
        for item in value:
            check_finite(item)
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    if not isinstance(data["variables"], dict):
        raise ValueError("Field variables must be a JSON object")
    if "heart" not in data["variables"]:
        raise ValueError(
            "Missing required field: variables.heart "
            "(required from the reformulated solver's default DZN output)"
        )
    if data["variables"]["heart"] is None:
        raise ValueError("Required field variables.heart is absent (null)")

    result = {"variables": {"heart": data["variables"]["heart"]}}
    encoded = json.dumps(result, ensure_ascii=False, allow_nan=False)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        destination.write(encoded)
        destination.write("\n")


if __name__ == "__main__":
    main()