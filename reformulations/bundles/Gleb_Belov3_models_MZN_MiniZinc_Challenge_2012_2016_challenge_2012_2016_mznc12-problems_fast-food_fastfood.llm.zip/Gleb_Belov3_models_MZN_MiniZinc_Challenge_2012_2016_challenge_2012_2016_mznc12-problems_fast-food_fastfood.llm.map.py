import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, list):
        for item in value:
            check_finite(item)
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")

    if "variables" not in data:
        raise ValueError("Missing required field: variables")

    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    if "p" not in variables or variables["p"] is None:
        raise ValueError(
            "Missing required field: variables.p "
            "(original depot locations from the solver's default DZN output)"
        )

    p = variables["p"]
    if not isinstance(p, dict):
        raise ValueError("variables.p must use the MiniZinc array encoding")

    if "array" not in p or "index_sets" not in p:
        raise ValueError(
            "variables.p must contain array and index_sets"
        )

    if not isinstance(p["array"], list):
        raise ValueError("variables.p.array must be a JSON array")

    if (
        not isinstance(p["index_sets"], list)
        or len(p["index_sets"]) != 1
    ):
        raise ValueError(
            "variables.p.index_sets must contain exactly one index set"
        )

    for value in p["array"]:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(
                "variables.p.array must contain integer depot positions"
            )

    result = {"variables": {"p": p}}

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()