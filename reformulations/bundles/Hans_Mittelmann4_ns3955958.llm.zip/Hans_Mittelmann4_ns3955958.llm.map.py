import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def required(container, key, location):
    if not isinstance(container, dict):
        raise ValueError(location + " must be an object")
    if key not in container:
        raise ValueError("Missing required field: " + location + "." + key)
    return container[key]


def number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(label + " must be numeric")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(label + " must be finite")
    return value


def integer(value, label, tolerance=0.0):
    value = number(value, label)
    rounded = round(value)
    if abs(value - rounded) > tolerance:
        raise ValueError(label + " must be integral")
    return int(rounded)


def numeric_set(context, name):
    values = required(context, name, "sets")
    if not isinstance(values, list):
        raise ValueError("sets." + name + " must be a list")
    result = [integer(value, "sets." + name) for value in values]
    if len(result) != len(set(result)):
        raise ValueError("Duplicate member in sets." + name)
    if not result:
        raise ValueError("sets." + name + " must not be empty")
    return sorted(result)


def key(name, *indices):
    return name + "[" + ",".join(str(index) for index in indices) + "]"


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        source = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    variables = required(source, "variables", "input")
    parameters = required(source, "parameters", "input")
    sets = required(source, "sets", "input")

    agents = numeric_set(sets, "Agentes")
    days = numeric_set(sets, "Dias")
    periods = numeric_set(sets, "Periodos")

    if len(days) != 1:
        raise ValueError("The reformulation requires exactly one day")
    if periods != list(range(periods[0], periods[-1] + 1)):
        raise ValueError("Periodos must contain consecutive integers")
    day = days[0]

    daily = {}
    weekly = {}
    minimum = {}

    for agent in agents:
        name = key("Cap_dia", agent)
        daily[agent] = number(
            required(parameters, name, "parameters"), name
        )
        name = key("Cap_sem", agent)
        weekly[agent] = number(
            required(parameters, name, "parameters"), name
        )
        name = key("Periodos_min", agent)
        minimum[agent] = integer(
            required(parameters, name, "parameters"), name
        )

    min_length = min(minimum.values())
    max_length = min(math.floor(value) for value in daily.values())

    if min_length < 1 or max_length < min_length:
        raise ValueError("Invalid working-interval length bounds")
    for agent in agents:
        if minimum[agent] != min_length:
            raise ValueError("Periodos_min is not uniform")
        if math.floor(daily[agent]) != max_length:
            raise ValueError("Effective daily capacities are not uniform")
        if math.floor(weekly[agent]) < max_length:
            raise ValueError("Weekly capacity is not redundant")

    demand = {}
    for period in periods:
        name = key("Demanda", day, period)
        demand[period] = integer(
            required(parameters, name, "parameters"), name
        )
        if demand[period] < 0:
            raise ValueError(name + " must be nonnegative")

    selected = []
    for start in periods:
        for end in periods:
            length = end - start + 1
            if min_length <= length <= max_length:
                name = key("rf4_shift", start, end)
                count = integer(
                    required(variables, name, "variables"),
                    name,
                    tolerance=1e-5,
                )
                if count < 0:
                    raise ValueError(name + " must be nonnegative")
                if len(selected) + count > len(agents):
                    raise ValueError("Interval counts exceed available agents")
                selected.extend([(start, end)] * count)

    result = {}
    for agent in agents:
        result[key("Y", agent)] = 0
        for period in periods:
            for family in ("X", "XE", "Q", "B"):
                result[key(family, agent, day, period)] = 0

    active = {period: [] for period in periods}
    for agent, (start, end) in zip(agents, selected):
        result[key("Y", agent)] = 1
        result[key("XE", agent, day, start)] = 1
        for period in range(start, end + 1):
            result[key("X", agent, day, period)] = 1
            active[period].append(agent)

    for period in periods:
        working = active[period]
        needed = demand[period]
        if len(working) < needed:
            raise ValueError(
                "Insufficient coverage at " + key("Demanda", day, period)
            )
        for agent in working[needed:]:
            result[key("Q", agent, day, period)] = 1

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": result}, stream, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)