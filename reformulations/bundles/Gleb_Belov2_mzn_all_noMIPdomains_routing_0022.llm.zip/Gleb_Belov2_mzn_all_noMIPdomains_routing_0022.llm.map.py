import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; source: default DZN solution of the reformulated model"
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    # These constants come from this self-contained original instance.
    # The second node's Y/Z coordinates follow from the first +X leg.
    # The ninth node's X/Y coordinates follow from the last possible -Z
    # leg, including its zero-length case.
    fixed_coordinates = {
        "nXNd__1_1_X": 315,
        "nXNd__1_1_Y": 54,
        "nXNd__1_1_Z": 73,
        "nXNd__1_2_Y": 54,
        "nXNd__1_2_Z": 73,
        "nXNd__1_9_X": 335,
        "nXNd__1_9_Y": 53,
        "nXNd__1_10_X": 335,
        "nXNd__1_10_Y": 53,
        "nXNd__1_10_Z": 8,
    }

    restored = {}
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = required_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        restored[name] = required_variable(variables, name)

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)