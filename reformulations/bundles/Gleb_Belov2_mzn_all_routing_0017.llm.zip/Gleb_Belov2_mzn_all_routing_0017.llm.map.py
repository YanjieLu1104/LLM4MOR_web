import json
import math
import sys


def reject_constant(value):
    raise ValueError("Nonfinite JSON constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, child in value.items():
            check_finite(child, path + "." + key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            check_finite(child, "{}[{}]".format(path, index))


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected integer at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected finite integer at " + path)
    return int(value)


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected encoded index set at " + path)
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        decoded = [
            require_integer(element, "{}.set[{}]".format(path, index))
            for index, element in enumerate(elements)
        ]
        if len(decoded) != len(set(decoded)):
            raise ValueError("Duplicate index at " + path)
        return sorted(decoded)
    raise ValueError("Invalid index-set encoding at " + path)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from default DZN solution output".format(name)
        )
    return variables[name]


def copy_array(variables, name, dimensions):
    value = require_variable(variables, name)
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected encoded array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding at " + path)
    if len(index_sets) != dimensions:
        raise ValueError("Incorrect number of dimensions at " + path)
    count = 1
    for dimension, encoded in enumerate(index_sets):
        count *= len(
            decode_index_set(
                encoded, "{}.index_sets[{}]".format(path, dimension)
            )
        )
    if len(elements) != count:
        raise ValueError("Array element count does not match index sets at " + path)
    return {
        "array": [
            require_integer(element, "{}.array[{}]".format(path, index))
            for index, element in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = payload["variables"]
    result = {}

    # These singleton domains are fixed data in the self-contained original model.
    fixed_coordinates = {
        "nXNd__1_1_X": 211,
        "nXNd__1_1_Y": 48,
        "nXNd__1_1_Z": 5,
        "nXNd__1_10_X": 210,
        "nXNd__1_10_Y": 77,
        "nXNd__1_10_Z": 45,
    }

    # Every nonfixed coordinate remains an independent scalar in the new model.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                result[name] = require_integer(variables[name], "variables." + name)
            elif name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                require_variable(variables, name)

    for name, dimensions in (
        ("nXLeg1", 2),
        ("nXLeg2", 2),
        ("nLLeg", 2),
        ("nDirLeg", 1),
        ("fExistLeg", 1),
        ("fLastLeg", 1),
    ):
        result[name] = copy_array(variables, name, dimensions)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        result["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; the original obj variable "
            "requires the unchanged solution objective"
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    mapped = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)