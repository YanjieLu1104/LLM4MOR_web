import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 65,
    "nXNd__1_1_Y": 114,
    "nXNd__1_1_Z": 80,
    "nXNd__1_10_X": 64,
    "nXNd__1_10_Y": 41,
    "nXNd__1_10_Z": 5,
}

FREE_COORDINATES = (
    "nXNd__1_2_X", "nXNd__1_2_Y", "nXNd__1_2_Z",
    "nXNd__1_3_X", "nXNd__1_3_Y", "nXNd__1_3_Z",
    "nXNd__1_4_X", "nXNd__1_4_Y", "nXNd__1_4_Z",
    "nXNd__1_5_X", "nXNd__1_5_Y", "nXNd__1_5_Z",
    "nXNd__1_6_X", "nXNd__1_6_Y", "nXNd__1_6_Z",
    "nXNd__1_7_X", "nXNd__1_7_Y", "nXNd__1_7_Z",
    "nXNd__1_8_X", "nXNd__1_8_Y", "nXNd__1_8_Z",
    "nXNd__1_9_X", "nXNd__1_9_Y", "nXNd__1_9_Z",
)

ORIGINAL_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the reformulated "
            "model's default DZN solution".format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = payload["variables"]
    restored = {}

    for name, fixed_value in FIXED_COORDINATES.items():
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    for name in FREE_COORDINATES:
        restored[name] = required_variable(variables, name)

    for name in ORIGINAL_ARRAYS:
        value = required_variable(variables, name)
        if (
            not isinstance(value, dict)
            or "array" not in value
            or "index_sets" not in value
            or not isinstance(value["array"], list)
            or not isinstance(value["index_sets"], list)
        ):
            raise ValueError(
                "variables.{} must contain array and index_sets "
                "in the MiniZinc array encoding".format(name)
            )
        restored[name] = value

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    else:
        if "objective" not in payload or payload["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; one must provide "
                "the unchanged objective value"
            )
        objective = payload["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be a finite integer-valued number")
        restored["obj"] = int(objective)

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(result, stream, allow_nan=False, separators=(",", ":"))
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)