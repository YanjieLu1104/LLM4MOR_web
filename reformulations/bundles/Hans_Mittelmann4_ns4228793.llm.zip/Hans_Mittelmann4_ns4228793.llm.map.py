import json
import math
import re
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected numeric value for " + name)
    if not math.isfinite(value):
        raise ValueError("Nonfinite value for " + name)
    return value


def required(mapping, key, prefix):
    if key not in mapping:
        raise ValueError("Missing required field: " + prefix + key)
    return number(mapping[key], prefix + key)


def indexed(name, *indices):
    return name + "[" + ",".join(str(i) for i in indices) + "]"


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    for field in ("variables", "parameters"):
        if field not in payload:
            raise ValueError("Missing required field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError("Expected object: " + field)

    parameters = payload["parameters"]
    raw_variables = payload["variables"]
    variables = {}

    for key, value in raw_variables.items():
        normalized = re.sub(r"\s+", "", key)
        if normalized in variables:
            raise ValueError("Duplicate normalized variable: " + normalized)
        variables[normalized] = number(value, "variables." + key)

    node_value = required(parameters, "nodes", "parameters.")
    method_value = required(parameters, "K", "parameters.")
    if node_value != int(node_value) or node_value < 1:
        raise ValueError("parameters.nodes must be a positive integer")
    if method_value != int(method_value) or method_value < 0:
        raise ValueError("parameters.K must be a nonnegative integer")

    node_count = int(node_value)
    method_count = int(method_value)
    arcs = set()

    for key in variables:
        match = re.fullmatch(r"xs\[(\d+),(\d+)\]", key)
        if match:
            arc = (int(match.group(1)), int(match.group(2)))
            if not all(1 <= endpoint <= node_count for endpoint in arc):
                raise ValueError("Out-of-domain variable: " + key)
            arcs.add(arc)

    if not arcs:
        raise ValueError("Missing required field: variables.xs[i,j]")

    for i, j in arcs:
        if (j, i) not in arcs:
            raise ValueError(
                "Missing required field: variables." + indexed("xs", j, i)
            )

    def get(name, *indices):
        key = indexed(name, *indices) if indices else name
        return required(variables, key, "variables.")

    output = {"Mwp": get("Mwp"), "Mbp": get("Mbp")}

    for i, j in sorted(arcs):
        output[indexed("xs", i, j)] = get("xs", i, j)

        for method in range(1, method_count + 1):
            output[indexed("Inc", i, j, method)] = get(
                "Inc", i, j, method
            )

        for source in range(1, node_count + 1):
            for target in range(1, node_count + 1):
                if source < target:
                    stored = (i, j, source, target)
                elif source > target:
                    stored = (j, i, target, source)
                else:
                    stored = None

                for name in ("x", "y"):
                    output[indexed(name, i, j, source, target)] = (
                        0 if stored is None else get(name, *stored)
                    )

                for method in range(1, method_count + 1):
                    for name in ("Incx", "Incy"):
                        output[
                            indexed(name, i, j, source, target, method)
                        ] = (
                            0
                            if stored is None
                            else get(name, *stored, method)
                        )

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": output},
            stream,
            allow_nan=False,
            separators=(",", ":"),
        )


if __name__ == "__main__":
    main()