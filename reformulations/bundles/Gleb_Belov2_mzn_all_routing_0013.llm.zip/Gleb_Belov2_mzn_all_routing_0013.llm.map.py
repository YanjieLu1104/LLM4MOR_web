import json
import math
import sys


FIXED_ENDPOINTS = {
    "nXNd__1_1_X": 210,
    "nXNd__1_1_Y": 77,
    "nXNd__1_1_Z": 52,
    "nXNd__1_10_X": 236,
    "nXNd__1_10_Y": 62,
    "nXNd__1_10_Z": 181,
}

COORDINATE_NAMES = [
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
]

OTHER_INDEPENDENT_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
    "obj",
)


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the default DZN "
            "solution of the reformulated model".format(name)
        )
    return variables[name]


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document:
        raise ValueError("Missing variables in input")
    variables = document["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    check_finite(document, "input")
    restored = {}

    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in FIXED_ENDPOINTS:
            restored[name] = FIXED_ENDPOINTS[name]
        else:
            restored[name] = required_variable(variables, name)

    for name in OTHER_INDEPENDENT_NAMES:
        if name == "obj" and (
            name not in variables or variables[name] is None
        ):
            if "objective" not in document or document["objective"] is None:
                raise ValueError(
                    "Missing variables.obj and objective; one is required "
                    "to restore the original objective variable"
                )
            value = document["objective"]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("objective must be a finite integer value")
            if isinstance(value, float) and not value.is_integer():
                raise ValueError("objective is not an integer")
            restored[name] = int(value)
        else:
            restored[name] = required_variable(variables, name)

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)