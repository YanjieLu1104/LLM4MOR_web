import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from the default DZN solution".format(name)
        )
    return variables[name]


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected a finite integer at " + path)
    return int(value)


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid index range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid index set at " + path)
        decoded = [
            require_integer(item, path + ".set")
            for item in elements
        ]
        if decoded != sorted(set(decoded)):
            raise ValueError("Index set must be sorted and unique at " + path)
        return decoded
    raise ValueError("Invalid index-set encoding at " + path)


def copy_integer_array(variables, name, expected_domains):
    value = require_variable(variables, name)
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding at " + path)
    if len(index_sets) != len(expected_domains):
        raise ValueError("Incorrect array dimension at " + path)
    size = 1
    for axis, (encoded, expected) in enumerate(zip(index_sets, expected_domains)):
        actual = decode_index_set(
            encoded, "{}.index_sets[{}]".format(path, axis)
        )
        if actual != expected:
            raise ValueError("Incorrect index domain at " + path)
        size *= len(actual)
    if len(elements) != size:
        raise ValueError("Incorrect array element count at " + path)
    for index, item in enumerate(elements):
        require_integer(item, "{}.array[{}]".format(path, index))
    return value


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid variables object")
    variables = document["variables"]
    restored = {}

    # These singleton domains and dimensions are embedded in the original
    # self-contained model, not inferred from external instance data.
    fixed_coordinates = {
        "nXNd__1_1_X": 212,
        "nXNd__1_1_Y": 36,
        "nXNd__1_1_Z": 100,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 43,
        "nXNd__1_10_Z": 58,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                value = require_integer(variables[name], "variables." + name)
            elif name in fixed_coordinates:
                value = fixed_coordinates[name]
            else:
                value = require_integer(
                    require_variable(variables, name), "variables." + name
                )
            restored[name] = value

    node_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        restored[name] = copy_integer_array(
            variables, name, [node_domain, coordinate_domain]
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        restored[name] = copy_integer_array(
            variables, name, [node_domain]
        )

    restored["obj"] = require_integer(
        require_variable(variables, "obj"), "variables.obj"
    )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(document, "input")
    result = map_solution(document)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)