import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def required_integer(variables, name):
    if name not in variables:
        raise ValueError(
            "Missing required field variables."
            + name
            + " from the reformulated model's default DZN solution"
        )
    value = variables[name]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer for variables." + name)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected a finite integer for variables." + name)
    return int(value)


def reconstruct(payload):
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    source = payload["variables"]
    result = {}

    # These identifiers and correspondences are fixed in the original
    # self-contained instance, not supplied by an external data file.
    task_ids = [
        (750, 756, 761),
        (791, 797, 802),
        (832, 838, 843),
        (873, 879, 884),
        (914, 920, 925),
        (955, 961, 966),
        (996, 1002, 1007),
        (1037, 1043, 1048),
        (1078, 1084, 1089),
        (1119, 1125, 1130),
        (1160, 1166, 1171),
        (1201, 1207, 1212),
        (1242, 1248, 1253),
        (1283, 1289, 1294),
        (1324, 1330, 1335),
    ]

    days = []
    for choice_id, chosen_id, day_id in task_ids:
        name = "chooseint_" + str(choice_id)
        value = required_integer(source, name)
        days.append(value)
        result[name] = value
        result["chosenDay_" + str(chosen_id)] = value
        result["ichosenDay_" + str(chosen_id)] = 1
        result["day_" + str(day_id)] = value
        result["iday_" + str(day_id)] = 1

    def lookup(prefix, identifier, value):
        name = prefix + "_" + str(identifier)
        result[name] = value
        result["i" + name] = 1

    # Each dependency check succeeds in every feasible original solution:
    # permutation flow from prev[1] = 51 forces the complete successful
    # dependency path. All conditional dependency lookups are therefore active.
    # Entries: target task, prerequisite task, target lookup, prerequisite
    # lookup, returned prerequisite lookup, earliest-day lookup, minimum lag.
    dependency_rows = [
        (6, 1, 1627, 1641, 1645, 1651, 1),
        (10, 7, 1857, 1871, 1875, 1881, 1),
        (11, 10, 1958, 1972, 1976, 1982, 0),
        (12, 1, 2059, 2073, 2077, 2083, 0),
        (12, 10, 2116, 2130, 2134, 2140, 1),
        (12, 4, 2173, 2187, 2191, 2197, 2),
        (13, 5, 2274, 2288, 2292, 2298, 2),
        (13, 12, 2331, 2345, 2349, 2355, 2),
        (13, 3, 2388, 2402, 2406, 2412, 1),
        (14, 8, 2489, 2503, 2507, 2513, 2),
        (14, 2, 2546, 2560, 2564, 2570, 0),
        (14, 9, 2603, 2617, 2621, 2627, 0),
        (15, 9, 2704, 2718, 2722, 2728, 2),
        (15, 1, 2761, 2775, 2779, 2785, 2),
        (15, 4, 2818, 2832, 2836, 2842, 0),
    ]

    for (
        target,
        prerequisite,
        target_lookup,
        prerequisite_lookup,
        returned_lookup,
        earliest_lookup,
        lag,
    ) in dependency_rows:
        target_day = days[target - 1]
        prerequisite_day = days[prerequisite - 1]
        lookup("scheduledDay", target_lookup, target_day)
        lookup("scheduledDay", prerequisite_lookup, prerequisite_day)
        lookup("ret_getScheduledDay", returned_lookup, prerequisite_day)
        lookup(
            "ret_getEarliestAllowedDay",
            earliest_lookup,
            prerequisite_day + lag,
        )

    for identifier, successful_index in [
        (1664, 2),
        (1894, 2),
        (1995, 2),
        (2210, 4),
        (2425, 4),
        (2640, 4),
        (2855, 4),
    ]:
        result["ret_dependenciesSatisfied_" + str(identifier)] = True
        result["iret_dependenciesSatisfied_" + str(identifier)] = successful_index

    # Selecting the first entry is valid even for inactive optional lookups.
    # It provides a deterministic extension without restricting task days.
    records = []
    running_maximum = 1
    running_index = 1

    for task, day in enumerate(days, start=1):
        offset = 45 * (task - 1)
        lookup("scheduledDay", 2898 + offset, day)
        lookup("ret_getScheduledDay", 2902 + offset, day)
        lookup("scheduledDay", 2912 + offset, day)
        lookup("ret_getScheduledDay", 2916 + offset, day)

        is_record = day > running_maximum
        records.append(is_record)
        if is_record:
            running_maximum = day
            running_index = task + 1

        if task < len(days):
            finish_id = 2948 + offset
        else:
            finish_id = 3551

        result["finishDay_" + str(finish_id)] = running_maximum
        result["ifinishDay_" + str(finish_id)] = running_index

    result["objective"] = running_maximum
    result["iobjective"] = 1

    # All unvisited control-flow nodes are self-loops. The visited nodes form
    # the unique successful execution cycle, including strict record updates.
    path = [
        1, 3, 4, 6, 8, 9, 11, 13, 14, 16, 18, 20, 22, 23,
        25, 27, 29, 31, 32, 34, 36, 38, 40, 41, 43, 45,
        47, 49, 50, 52,
    ]
    record_branches = [
        (53, 54),
        (55, 56),
        (57, 58),
        (59, 60),
        (61, 62),
        (63, 64),
        (65, 66),
        (67, 68),
        (69, 70),
        (71, 72),
        (73, 74),
        (75, 5),
        (10, 15),
        (24, 33),
        (42, 51),
    ]

    for is_record, (optional_node, join_node) in zip(records, record_branches):
        if is_record:
            path.append(optional_node)
        path.append(join_node)

    prev = list(range(1, 76))
    for position, node in enumerate(path):
        prev[node - 1] = path[position - 1]

    result["prev"] = {
        "array": prev,
        "index_sets": [{"range": [1, 75]}],
    }

    # Original variables declared with "=" (Add_, Less_, Greater_, and
    # notret_dependenciesSatisfied_) are recomputed by their original
    # definitions and deliberately omitted.
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object")

    mapped = reconstruct(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(mapped, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    main()