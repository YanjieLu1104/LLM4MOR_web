import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("Non-finite JSON number: " + value)
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
            parse_float=finite_float,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")

    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    if "A" not in data["variables"] or data["variables"]["A"] is None:
        raise ValueError(
            "Missing required field variables.A from the default DZN solution"
        )

    original_a = data["variables"]["A"]
    if (
        not isinstance(original_a, dict)
        or "array" not in original_a
        or "index_sets" not in original_a
        or not isinstance(original_a["array"], list)
        or not isinstance(original_a["index_sets"], list)
        or len(original_a["index_sets"]) != 2
    ):
        raise ValueError(
            "variables.A must use the two-dimensional MiniZinc array encoding"
        )

    result = {"variables": {"A": original_a}}

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)