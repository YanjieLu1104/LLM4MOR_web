import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite JSON number")
    if isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    restored = {}
    for name in ("path", "next"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables."
                + name
                + " (required from the solver's default DZN solution)"
            )
        value = variables[name]
        if (
            not isinstance(value, dict)
            or "array" not in value
            or "index_sets" not in value
        ):
            raise ValueError(
                "variables." + name
                + " must use the MiniZinc array encoding with index_sets"
            )
        if not isinstance(value["array"], list):
            raise ValueError("variables." + name + ".array must be a list")
        if (
            not isinstance(value["index_sets"], list)
            or len(value["index_sets"]) != 1
        ):
            raise ValueError(
                "variables." + name + " must have exactly one index set"
            )
        if any(type(item) is not int for item in value["array"]):
            raise ValueError(
                "variables." + name + " must contain integer values"
            )
        restored[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump({"variables": restored}, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)