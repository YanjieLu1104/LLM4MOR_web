import json
import math
import re
import sys


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    values = payload["variables"]
    if not isinstance(values, dict):
        raise ValueError("Field variables must be an object")

    original_pattern = re.compile(
        r"(?:(?:X_FC|X_ES_in|X_ES_out|CostFC)\[\s*\d+\s*\]"
        r"|Effpt\[\s*\d+\s*,\s*\d+\s*\])"
    )
    mapped = {}
    for name, value in values.items():
        if original_pattern.fullmatch(name):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("Expected numeric variable value: " + name)
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError("Nonfinite variable value: " + name)
            mapped[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": mapped}, stream, allow_nan=False)


if __name__ == "__main__":
    main()