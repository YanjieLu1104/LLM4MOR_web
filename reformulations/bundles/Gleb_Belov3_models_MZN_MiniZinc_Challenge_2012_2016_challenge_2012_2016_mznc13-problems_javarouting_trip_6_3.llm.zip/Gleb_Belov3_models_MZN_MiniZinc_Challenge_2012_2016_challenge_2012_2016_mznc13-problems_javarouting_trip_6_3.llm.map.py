import json
import math
import sys


REQUIRED_VARIABLES = """
chooseOrder150
chooseOrder180
chooseOrder212
chooseOrder246
chooseOrder282
chooseOrder320
chooseOrder360
chooseOrder402
chooseOrder446
chooseOrder492
chooseOrder540
chooseOrder590
listget679
chosenIndex736
initialFieldValueslocationID738
mapget812
listget868
chosenIndex913
initialFieldValueslocationID915
mapget932
mapget1281
listget1734
chosenIndex1779
initialFieldValueslocationID1781
mapget1798
mapget1823
listget2276
chosenIndex2321
initialFieldValueslocationID2323
mapget2340
mapget2365
listget2818
chosenIndex2863
initialFieldValueslocationID2865
mapget2882
mapget2907
listget3360
chosenIndex3405
initialFieldValueslocationID3407
mapget3424
mapget3449
listget3902
chosenIndex3947
initialFieldValueslocationID3949
mapget3966
mapget3991
listget4444
chosenIndex4489
initialFieldValueslocationID4491
mapget4508
mapget4533
listget4986
chosenIndex5031
initialFieldValueslocationID5033
mapget5050
mapget5075
listget5528
chosenIndex5573
initialFieldValueslocationID5575
mapget5592
mapget5617
listget6070
chosenIndex6115
initialFieldValueslocationID6117
mapget6134
mapget6159
listget6612
chosenIndex6657
initialFieldValueslocationID6659
mapget6676
mapget6701
mapget7164
mapget7189
expectedArrivalTime7354
expectedArrivalTime7357
expectedArrivalTime7368
expectedArrivalTime7371
expectedArrivalTime7382
expectedArrivalTime7385
expectedArrivalTime7396
expectedArrivalTime7399
expectedArrivalTime7410
expectedArrivalTime7413
expectedArrivalTime7424
expectedArrivalTime7427
expectedArrivalTimeX12
expectedArrivalTimeX13
expectedArrivalTimeX14
expectedArrivalTimeX15
expectedArrivalTimeX16
expectedArrivalTimeX17
expectedArrivalTimeX18
expectedArrivalTimeX19
expectedArrivalTimeX20
expectedArrivalTimeX21
expectedArrivalTimeX22
expectedArrivalTimeX23
listget679X
listget868X
listget1734X
listget2276X
listget2818X
listget3360X
listget3902X
listget4444X
listget4986X
listget5528X
listget6070X
listget6612X
mapget812X
mapget932X
mapget1281X
mapget1798X
mapget1823X
mapget2340X
mapget2365X
mapget2882X
mapget2907X
mapget3424X
mapget3449X
mapget3966X
mapget3991X
mapget4508X
mapget4533X
mapget5050X
mapget5075X
mapget5592X
mapget5617X
mapget6134X
mapget6159X
mapget6676X
mapget6701X
mapget7164X
mapget7189X
""".split()


def reject_constant(value):
    raise ValueError("Non-finite JSON constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(data, "input")

    if "variables" not in data:
        raise ValueError(
            "Missing required field 'variables' from the reformulated solution"
        )
    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field 'variables' must be a JSON object")

    missing = [name for name in REQUIRED_VARIABLES if name not in variables]
    if missing:
        raise ValueError(
            "Missing required original scalar variables from default DZN output: "
            + ", ".join(missing)
        )

    restored = {}
    for name in REQUIRED_VARIABLES:
        value = variables[name]
        if value is None:
            raise ValueError(
                "Missing solution value for 'variables." + name + "'"
            )
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(
                "Expected an integer scalar at 'variables." + name + "'"
            )
        if isinstance(value, float) and not value.is_integer():
            raise ValueError(
                "Expected an integer scalar at 'variables." + name + "'"
            )
        restored[name] = int(value)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)