import json
import math
import re
import sys


TOLERANCE = 1e-5


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def finite_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected a numeric value for " + name)
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite value for " + name)
    return value


def integer_value(value, name):
    value = finite_number(value, name)
    rounded = round(value)
    if abs(value - rounded) > TOLERANCE:
        raise ValueError("Expected an integer value for " + name)
    return int(rounded)


def binary_value(value, name):
    result = integer_value(value, name)
    if result not in (0, 1):
        raise ValueError("Expected a binary value for " + name)
    return result


def indexed_entries(source, name, dimension):
    index_pattern = r"\s*,\s*".join([r"(-?\d+)"] * dimension)
    pattern = re.compile(
        r"^" + re.escape(name) + r"\[\s*" + index_pattern + r"\s*\]$"
    )
    result = {}
    for key, value in source.items():
        match = pattern.fullmatch(key)
        if match:
            index = tuple(int(part) for part in match.groups())
            if index in result:
                raise ValueError("Duplicate indexed entry for " + name + str(index))
            result[index] = value
    return result


def required(entries, index, name):
    if index not in entries:
        subscript = ",".join(str(part) for part in index)
        raise ValueError("Missing required field: " + name + "[" + subscript + "]")
    return entries[index]


def context_domain(context_sets, name, fallback):
    if name not in context_sets:
        if not fallback:
            raise ValueError("Missing required context for set " + name)
        return sorted(fallback)
    values = context_sets[name]
    if not isinstance(values, list):
        raise ValueError("Expected a list for sets." + name)
    parsed = [integer_value(value, "sets." + name) for value in values]
    if len(parsed) != len(set(parsed)):
        raise ValueError("Duplicate members in sets." + name)
    return sorted(parsed)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    if "parameters" not in payload:
        raise ValueError("Missing required field: parameters")

    variables = payload["variables"]
    parameters = payload["parameters"]
    context_sets = payload.get("sets", {})

    if not isinstance(variables, dict):
        raise ValueError("variables must be an object")
    if not isinstance(parameters, dict):
        raise ValueError("parameters must be an object")
    if not isinstance(context_sets, dict):
        raise ValueError("sets must be an object")

    for key, value in variables.items():
        finite_number(value, "variables." + key)

    weekly_capacity = indexed_entries(parameters, "Cap_sem", 1)
    demand_entries = indexed_entries(parameters, "Demanda", 2)

    if not demand_entries:
        raise ValueError("Missing required fields: parameters.Demanda[d,t]")

    agents = context_domain(
        context_sets, "Agentes", {index[0] for index in weekly_capacity}
    )
    days = context_domain(
        context_sets, "Dias", {index[0] for index in demand_entries}
    )
    periods = context_domain(
        context_sets, "Periodos", {index[1] for index in demand_entries}
    )

    x_entries = indexed_entries(variables, "X", 3)
    xe_entries = indexed_entries(variables, "XE", 3)
    y_entries = indexed_entries(variables, "Y", 1)

    output = {}
    x_values = {}
    xe_values = {}
    demands = {}

    for agent in agents:
        name = "Y[{}]".format(agent)
        output[name] = binary_value(
            required(y_entries, (agent,), "Y"), name
        )

    for day in days:
        for period in periods:
            name = "Demanda[{},{}]".format(day, period)
            demand = integer_value(
                required(demand_entries, (day, period), "Demanda"), name
            )
            if demand < 0:
                raise ValueError("Negative demand: " + name)
            demands[day, period] = demand

    for agent in agents:
        for day in days:
            for period in periods:
                index = (agent, day, period)
                suffix = "[{},{},{}]".format(*index)
                x_value = binary_value(
                    required(x_entries, index, "X"), "X" + suffix
                )
                xe_value = binary_value(
                    required(xe_entries, index, "XE"), "XE" + suffix
                )
                x_values[index] = x_value
                xe_values[index] = xe_value
                output["X" + suffix] = x_value
                output["XE" + suffix] = xe_value
                output["B" + suffix] = 0

    for day in days:
        daily_surplus = 0
        for period in periods:
            workers = [
                agent for agent in agents if x_values[agent, day, period] == 1
            ]
            surplus = len(workers) - demands[day, period]
            if surplus < 0:
                raise ValueError(
                    "Demand is not covered at [{},{}]".format(day, period)
                )

            surplus_agents = set(workers[:surplus])
            daily_surplus += surplus

            for agent in agents:
                output["Q[{},{},{}]".format(agent, day, period)] = (
                    1 if agent in surplus_agents else 0
                )

        starts = sum(
            xe_values[agent, day, period]
            for agent in agents
            for period in periods
        )
        if 4 * daily_surplus < starts:
            raise ValueError(
                "Daily surplus requirement is violated on day {}".format(day)
            )

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(
            {"variables": output},
            handle,
            allow_nan=False,
            separators=(",", ":"),
        )
        handle.write("\n")


if __name__ == "__main__":
    main()