import json
import math
import re
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def numeric(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected numeric value for " + name)
    if not math.isfinite(value):
        raise ValueError("Non-finite value for " + name)
    return value


def index_value(value, name):
    numeric(value, name)
    if value != int(value):
        raise ValueError("Expected integer index in " + name)
    return int(value)


def binary_value(value, name):
    numeric(value, name)
    rounded = round(value)
    if rounded not in (0, 1) or abs(value - rounded) > 1e-5:
        raise ValueError("Expected binary solution value for " + name)
    return int(rounded)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    for field in ("variables", "parameters"):
        if field not in payload:
            raise ValueError("Missing field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError("Expected object: " + field)

    variables = payload["variables"]
    parameters = payload["parameters"]
    sets = payload.get("sets", {})
    if not isinstance(sets, dict):
        raise ValueError("Expected object: sets")

    parsed_variables = {"X": {}, "XE": {}}
    variable_pattern = re.compile(
        r"(X|XE)\[\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\]"
    )

    for name, value in variables.items():
        match = variable_pattern.fullmatch(name)
        if match is None:
            raise ValueError("Unexpected reformulated variable: " + name)
        family = match.group(1)
        index = tuple(int(match.group(i)) for i in (2, 3, 4))
        if index in parsed_variables[family]:
            raise ValueError("Duplicate variable index: " + name)
        parsed_variables[family][index] = binary_value(value, name)

    demand = {}
    capacity_agents = set()
    demand_pattern = re.compile(
        r"Demanda\[\s*(-?\d+)\s*,\s*(-?\d+)\s*\]"
    )
    capacity_pattern = re.compile(r"Cap_sem\[\s*(-?\d+)\s*\]")

    for name, value in parameters.items():
        match = demand_pattern.fullmatch(name)
        if match is not None:
            index = (int(match.group(1)), int(match.group(2)))
            if index in demand:
                raise ValueError("Duplicate parameter index: " + name)
            numeric(value, name)
            if value < 0 or value != int(value):
                raise ValueError("Expected nonnegative integer demand: " + name)
            demand[index] = int(value)
        match = capacity_pattern.fullmatch(name)
        if match is not None:
            capacity_agents.add(int(match.group(1)))

    if "Agentes" in sets:
        agents = sorted({
            index_value(value, "sets.Agentes") for value in sets["Agentes"]
        })
    else:
        if not capacity_agents:
            raise ValueError("Missing sets.Agentes or parameters.Cap_sem[a]")
        agents = sorted(capacity_agents)

    if "Dias" in sets:
        days = sorted({
            index_value(value, "sets.Dias") for value in sets["Dias"]
        })
    else:
        if not demand:
            raise ValueError("Missing sets.Dias and parameters.Demanda[d,t]")
        days = sorted({d for d, t in demand})

    if "Periodos" in sets:
        periods = sorted({
            index_value(value, "sets.Periodos") for value in sets["Periodos"]
        })
    else:
        if not demand:
            raise ValueError("Missing sets.Periodos and parameters.Demanda[d,t]")
        periods = sorted({t for d, t in demand})

    if not agents or not days or not periods:
        raise ValueError("Original index domains must be nonempty")

    expected = {
        (a, d, t)
        for a in agents
        for d in days
        for t in periods
    }

    for family in ("X", "XE"):
        actual = set(parsed_variables[family])
        missing = expected - actual
        if missing:
            a, d, t = min(missing)
            raise ValueError(
                f"Missing variables.{family}[{a},{d},{t}]"
            )
        extra = actual - expected
        if extra:
            raise ValueError(
                f"Out-of-domain index for {family}: {min(extra)}"
            )

    result = {}
    for a in agents:
        result[f"Y[{a}]"] = 1
        for d in days:
            for t in periods:
                index = (a, d, t)
                result[f"X[{a},{d},{t}]"] = parsed_variables["X"][index]
                result[f"XE[{a},{d},{t}]"] = parsed_variables["XE"][index]
                result[f"B[{a},{d},{t}]"] = 0

    for d in days:
        for t in periods:
            if (d, t) not in demand:
                raise ValueError(f"Missing parameters.Demanda[{d},{t}]")

            working = [
                a for a in agents if parsed_variables["X"][(a, d, t)] == 1
            ]
            surplus = len(working) - demand[(d, t)]
            if surplus < 0:
                raise ValueError(f"Demand coverage violated at [{d},{t}]")

            surplus_agents = set(working[:surplus])
            for a in agents:
                result[f"Q[{a},{d},{t}]"] = int(a in surplus_agents)

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump({"variables": result}, handle, allow_nan=False)


if __name__ == "__main__":
    main()