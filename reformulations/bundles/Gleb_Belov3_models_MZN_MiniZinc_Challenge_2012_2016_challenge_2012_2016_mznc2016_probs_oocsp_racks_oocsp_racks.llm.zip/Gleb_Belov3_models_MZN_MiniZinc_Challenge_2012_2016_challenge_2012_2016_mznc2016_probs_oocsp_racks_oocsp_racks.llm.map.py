import json
import math
import sys


ORIGINAL_INDEPENDENT_VARIABLES = (
    "start",
    "nrofobjects",
    "Configuration_configtype",
    "Element_configuration",
    "Configuration_elements_count",
    "Frame_rack",
    "Rack_frames_count",
    "Module_frame",
    "Frame_modules_count",
    "Module_element",
    "Element_modules_count",
    "Rack_configuration",
    "Configuration_racks_count",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))


def check_present(value, path):
    if value is None:
        raise ValueError("Missing solution value at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_present(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_present(item, "{}[{}]".format(path, position))


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document:
        raise ValueError("Missing required field: variables")
    if "parameters" not in document:
        raise ValueError("Missing required field: parameters")

    variables = document["variables"]
    parameters = document["parameters"]

    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")
    if not isinstance(parameters, dict):
        raise ValueError("parameters must be a JSON object")

    result = {}
    missing = []

    for name in ORIGINAL_INDEPENDENT_VARIABLES:
        if name in variables and variables[name] is not None:
            value = variables[name]
        elif name in parameters and parameters[name] is not None:
            value = parameters[name]
        else:
            missing.append(name)
            continue

        check_present(value, "variables." + name)
        result[name] = value

    if missing:
        raise ValueError(
            "Missing original decision-variable values: "
            + ", ".join(missing)
            + ". Required source: variables from the default DZN solution, "
              "or parameters under the same original name if externally bound."
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(document, "input")
    mapped = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, ensure_ascii=False, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)