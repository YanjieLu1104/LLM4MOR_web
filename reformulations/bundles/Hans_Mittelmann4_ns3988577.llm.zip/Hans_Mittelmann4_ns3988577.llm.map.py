import json
import math
import re
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def finite_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(name + " must be a numeric value")
    if not math.isfinite(value):
        raise ValueError(name + " must be finite")
    return value


def binary_value(value, name):
    value = finite_number(value, name)
    rounded = round(value)
    if rounded not in (0, 1) or abs(value - rounded) > 1e-5:
        raise ValueError(name + " is not a binary solution value")
    return int(rounded)


def indexed_key(name, indices):
    return name + "[" + ",".join(str(i) for i in indices) + "]"


def parse_family(values, name, dimension):
    pattern = re.compile(
        r"^" + re.escape(name) + r"\[\s*"
        + r"\s*,\s*".join([r"(-?\d+)"] * dimension)
        + r"\s*\]$"
    )
    result = {}
    for key, value in values.items():
        match = pattern.fullmatch(key)
        if match is not None:
            indices = tuple(int(part) for part in match.groups())
            if indices in result:
                raise ValueError("Duplicate indexed value: "
                                 + indexed_key(name, indices))
            result[indices] = binary_value(value, key)
    if not result:
        raise ValueError("Missing required variable family: " + name)
    return result


def context_domain(payload, name, inferred):
    sets = payload.get("sets", {})
    if not isinstance(sets, dict):
        raise ValueError("sets must be an object")
    if name not in sets:
        return sorted(inferred)
    values = sets[name]
    if not isinstance(values, list):
        raise ValueError("sets." + name + " must be a list")
    domain = []
    for value in values:
        finite_number(value, "sets." + name)
        if int(value) != value:
            raise ValueError("Noninteger index in sets." + name)
        domain.append(int(value))
    if len(set(domain)) != len(domain):
        raise ValueError("Duplicate index in sets." + name)
    if set(domain) != inferred:
        raise ValueError("Variable indices do not match sets." + name)
    return sorted(domain)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant
        )

    for field in ("variables", "parameters"):
        if field not in payload:
            raise ValueError("Missing required field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError(field + " must be an object")

    values = payload["variables"]
    parameters = payload["parameters"]
    x = parse_family(values, "X", 3)
    xe = parse_family(values, "XE", 3)
    y = parse_family(values, "Y", 1)

    agents = context_domain(
        payload, "Agentes", {indices[0] for indices in x}
    )
    days = context_domain(
        payload, "Dias", {indices[1] for indices in x}
    )
    periods = context_domain(
        payload, "Periodos", {indices[2] for indices in x}
    )

    expected = {
        (a, d, t) for a in agents for d in days for t in periods
    }
    for name, family in (("X", x), ("XE", xe)):
        missing = expected - set(family)
        if missing:
            raise ValueError("Missing required variable: "
                             + indexed_key(name, min(missing)))
        if set(family) != expected:
            raise ValueError("Unexpected indices in " + name)

    expected_y = {(a,) for a in agents}
    missing_y = expected_y - set(y)
    if missing_y:
        raise ValueError("Missing required variable: "
                         + indexed_key("Y", min(missing_y)))
    if set(y) != expected_y:
        raise ValueError("Unexpected indices in Y")

    output = {}
    for indices in sorted(expected):
        output[indexed_key("X", indices)] = x[indices]
        output[indexed_key("XE", indices)] = xe[indices]
        output[indexed_key("B", indices)] = 0
    for indices in sorted(expected_y):
        output[indexed_key("Y", indices)] = y[indices]

    for d in days:
        daily_surplus = 0
        for t in periods:
            demand_key = indexed_key("Demanda", (d, t))
            if demand_key not in parameters:
                raise ValueError("Missing required parameter: " + demand_key)
            demand = finite_number(parameters[demand_key], demand_key)
            if demand < 0 or demand != round(demand):
                raise ValueError(
                    demand_key + " must be a nonnegative integer "
                    "for a feasible original binary solution"
                )
            demand = int(demand)
            working = [a for a in agents if x[a, d, t] == 1]
            surplus = len(working) - demand
            if surplus < 0:
                raise ValueError("Coverage violation at " + demand_key)

            assigned = set(working[:surplus])
            for a in agents:
                output[indexed_key("Q", (a, d, t))] = int(a in assigned)
            daily_surplus += surplus

        starts = sum(xe[a, d, t] for a in agents for t in periods)
        if 4 * daily_surplus < starts:
            raise ValueError("Daily surplus requirement violated on day "
                             + str(d))

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": output}, stream, allow_nan=False)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        sys.exit(str(error))