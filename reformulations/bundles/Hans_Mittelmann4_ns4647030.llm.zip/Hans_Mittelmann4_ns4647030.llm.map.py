import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    original_names = {"X_FC", "X_ES_in", "X_ES_out", "CostFC", "Effpt"}
    restored = {}
    for key, value in variables.items():
        name = key.split("[", 1)[0]
        if name not in original_names:
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Expected a numeric assignment for " + key)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Nonfinite assignment for " + key)
        restored[key] = value

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump({"variables": restored}, target, allow_nan=False)
        target.write("\n")


if __name__ == "__main__":
    main()