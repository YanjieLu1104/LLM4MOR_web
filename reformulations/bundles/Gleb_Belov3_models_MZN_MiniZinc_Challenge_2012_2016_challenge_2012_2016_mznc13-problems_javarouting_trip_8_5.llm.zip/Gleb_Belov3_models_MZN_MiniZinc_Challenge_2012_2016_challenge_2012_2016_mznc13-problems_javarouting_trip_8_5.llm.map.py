import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def original_independent_names():
    order_ids = (
        258, 296, 336, 378, 422, 468, 516, 566,
        618, 672, 728, 786, 846, 908, 972, 1038
    )
    list_ids = (
        1151, 1388, 2850, 3752, 4654, 5556, 6458, 7360,
        8262, 9164, 10066, 10968, 11870, 12772, 13674, 14576
    )
    chosen_ids = (
        1224, 1445, 2907, 3809, 4711, 5613, 6515, 7417,
        8319, 9221, 10123, 11025, 11927, 12829, 13731, 14633
    )
    location_ids = (
        1226, 1447, 2909, 3811, 4713, 5615, 6517, 7419,
        8321, 9223, 10125, 11027, 11929, 12831, 13733, 14635
    )
    map_ids = (
        1316, 1464, 2057, 2926, 2959, 3828, 3861,
        4730, 4763, 5632, 5665, 6534, 6567, 7436,
        7469, 8338, 8371, 9240, 9273, 10142, 10175,
        11044, 11077, 11946, 11979, 12848, 12881,
        13750, 13783, 14652, 14685, 15488, 15521
    )
    arrival_ids = (
        15784, 15787, 15798, 15801, 15812, 15815, 15826, 15829,
        15840, 15843, 15854, 15857, 15868, 15871, 15882, 15885
    )

    names = []
    names.extend("chooseOrder" + str(item) for item in order_ids)
    names.extend("listget" + str(item) for item in list_ids)
    names.extend("chosenIndex" + str(item) for item in chosen_ids)
    names.extend(
        "initialFieldValueslocationID" + str(item)
        for item in location_ids
    )
    names.extend("mapget" + str(item) for item in map_ids)
    names.extend("expectedArrivalTime" + str(item) for item in arrival_ids)
    names.extend("expectedArrivalTimeX" + str(item) for item in range(16, 32))
    names.extend("listget" + str(item) + "X" for item in list_ids)
    names.extend("mapget" + str(item) + "X" for item in map_ids)
    return names


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(data, dict):
        raise ValueError("The input must be a JSON object")
    check_finite(data, "input")

    if "variables" not in data:
        raise ValueError("Missing required input field: variables")
    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("The input field variables must be a JSON object")

    names = original_independent_names()
    missing = [name for name in names if name not in variables]
    if missing:
        raise ValueError(
            "Missing required fields from the default DZN solution variables: "
            + ", ".join(missing)
        )

    restored = {}
    for name in names:
        value = variables[name]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Expected an integer scalar in variables." + name)
        if isinstance(value, float) and not value.is_integer():
            raise ValueError("Expected an integer scalar in variables." + name)
        restored[name] = int(value)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)