import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, list):
        for item in value:
            check_finite(item)
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = data["variables"]
    if "p" not in variables or variables["p"] is None:
        raise ValueError(
            "Missing required field variables.p from the default DZN solution"
        )

    value = variables["p"]
    if not isinstance(value, dict):
        raise ValueError("variables.p must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "variables.p requires both array and index_sets"
        )
    if not isinstance(value["array"], list):
        raise ValueError("variables.p.array must be a list")
    if (
        not isinstance(value["index_sets"], list)
        or len(value["index_sets"]) != 2
    ):
        raise ValueError("variables.p must have exactly two index sets")
    if any(type(item) is not int for item in value["array"]):
        raise ValueError("variables.p.array must contain integers")

    result = {"variables": {"p": value}}
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False)
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)