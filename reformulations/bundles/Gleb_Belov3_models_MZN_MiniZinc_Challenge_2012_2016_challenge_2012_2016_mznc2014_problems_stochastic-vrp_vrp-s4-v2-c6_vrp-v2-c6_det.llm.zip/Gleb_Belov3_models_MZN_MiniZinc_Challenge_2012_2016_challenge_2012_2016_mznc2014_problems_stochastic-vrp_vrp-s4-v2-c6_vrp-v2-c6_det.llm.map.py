import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            check_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    required = (
        "successor",
        "predecessor",
        "vehicle",
        "arrivalTime",
        "objective",
    )

    result = {}
    for name in required:
        if name not in variables:
            raise ValueError(
                "Missing required field: variables."
                + name
                + "; expected from the reformulated model's default DZN solution"
            )
        if variables[name] is None:
            raise ValueError("Absent solution value: variables." + name)
        result[name] = variables[name]

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload, "input")
    mapped = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)