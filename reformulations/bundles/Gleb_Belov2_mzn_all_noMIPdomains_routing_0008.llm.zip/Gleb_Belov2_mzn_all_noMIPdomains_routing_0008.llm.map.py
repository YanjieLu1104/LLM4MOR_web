import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 246,
    "nXNd__1_1_Y": 43,
    "nXNd__1_1_Z": 45,
    "nXNd__1_10_X": 211,
    "nXNd__1_10_Y": 53,
    "nXNd__1_10_Z": 5,
}

ARRAY_VARIABLES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; expected in the reformulated model's default DZN solution."
        )
    return variables[name]


def require_integer(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer value for " + name)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected a finite integer value for " + name)
        return int(value)
    return value


def check_array(value, name):
    if not isinstance(value, dict):
        raise ValueError("Expected encoded MiniZinc array for variables." + name)
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "Missing array or index_sets in variables." + name
        )
    if not isinstance(value["array"], list):
        raise ValueError("Expected a list in variables." + name + ".array")
    if not isinstance(value["index_sets"], list):
        raise ValueError("Expected a list in variables." + name + ".index_sets")

    count = 1
    for dimension, index_set in enumerate(value["index_sets"]):
        location = name + ".index_sets[" + str(dimension) + "]"
        if not isinstance(index_set, dict):
            raise ValueError("Invalid index set at " + location)
        if "range" in index_set:
            bounds = index_set["range"]
            if not isinstance(bounds, list) or len(bounds) != 2:
                raise ValueError("Invalid range at " + location)
            lower = require_integer(bounds[0], location)
            upper = require_integer(bounds[1], location)
            count *= max(0, upper - lower + 1)
        elif "set" in index_set:
            elements = index_set["set"]
            if not isinstance(elements, list):
                raise ValueError("Invalid set at " + location)
            count *= len(elements)
        else:
            raise ValueError("Missing set or range at " + location)

    if count != len(value["array"]):
        raise ValueError("Array size does not match index sets for " + name)

    for position, item in enumerate(value["array"]):
        require_integer(item, name + ".array[" + str(position) + "]")
    return value


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing required object: variables")

    variables = payload["variables"]
    restored = {}

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = require_integer(variables[name], name)
            elif name in FIXED_COORDINATES:
                restored[name] = FIXED_COORDINATES[name]
            else:
                restored[name] = require_integer(
                    require_variable(variables, name), name
                )

    for name in ARRAY_VARIABLES:
        restored[name] = check_array(require_variable(variables, name), name)

    restored["obj"] = require_integer(
        require_variable(variables, "obj"), "obj"
    )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)