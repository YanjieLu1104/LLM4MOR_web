import json
import math
import re
import sys
from collections import deque


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected numeric value for " + name)
    if not math.isfinite(value):
        raise ValueError("Nonfinite value for " + name)
    return value


def required_number(mapping, name):
    if name not in mapping:
        raise ValueError("Missing required field: " + name)
    return number(mapping[name], name)


def required_integer(mapping, name, minimum):
    value = required_number(mapping, name)
    if value != int(value) or value < minimum:
        raise ValueError("Invalid integer parameter: " + name)
    return int(value)


def canonical_name(name):
    return re.sub(r"\s+", "", name)


def normalize(mapping, label):
    if not isinstance(mapping, dict):
        raise ValueError("Expected object: " + label)
    result = {}
    for name, value in mapping.items():
        key = canonical_name(name)
        if key in result:
            raise ValueError("Duplicate normalized name: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        source = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if "variables" not in source:
        raise ValueError("Missing required field: variables")
    if "parameters" not in source:
        raise ValueError("Missing required field: parameters")

    variables = normalize(source["variables"], "variables")
    parameters = normalize(source["parameters"], "parameters")

    n = required_integer(parameters, "nodes", 2)
    method_count = required_integer(parameters, "K", 1)
    nodes = range(1, n + 1)
    methods = range(1, method_count + 1)

    da_pattern = re.compile(r"da\[(\d+),(\d+),(\d+)\]")
    arcs = set()
    for name in parameters:
        match = da_pattern.fullmatch(name)
        if match:
            i, j, method = map(int, match.groups())
            if not (1 <= i <= n and 1 <= j <= n):
                raise ValueError("Availability index outside Nodes: " + name)
            if not 1 <= method <= method_count:
                raise ValueError("Availability method outside k: " + name)
            arcs.add((i, j))

    if not arcs:
        raise ValueError("Missing required fields: da[i,j,kk]")

    for i, j in arcs:
        if i == j or (j, i) not in arcs:
            raise ValueError("Expected a loop-free symmetric arc domain")

    availability = {}
    for i, j in sorted(arcs):
        for method in methods:
            name = f"da[{i},{j},{method}]"
            availability[i, j, method] = required_number(parameters, name)

    for i, j in arcs:
        for method in methods:
            value = availability[i, j, method]
            if value > 1:
                raise ValueError("Negative unavailability is unsupported")
            if value != availability[j, i, method]:
                raise ValueError("Asymmetric availability is unsupported")

    candidates = [
        method
        for method in methods
        if all(
            availability[i, j, method] >= availability[i, j, other]
            for i, j in arcs
            for other in methods
        )
    ]
    if not candidates:
        raise ValueError("No common dominating method")
    selected_method = min(candidates)

    budget = required_number(parameters, "C")
    total_cost = sum(
        required_number(parameters, f"dc[{i},{j},{selected_method}]")
        for i, j in arcs
    )
    if total_cost > 2 * budget:
        raise ValueError("The dominating-method assignment exceeds the budget")

    edges = sorted((i, j) for i, j in arcs if i < j)
    selected = {}
    adjacency = {i: [] for i in nodes}

    for i, j in edges:
        name = f"rf421_z[{i},{j}]"
        value = required_number(variables, name)
        rounded = int(round(value))
        if rounded not in (0, 1) or abs(value - rounded) > 1e-5:
            raise ValueError("Nonbinary tree-edge value: " + name)
        selected[i, j] = rounded
        if rounded:
            adjacency[i].append(j)
            adjacency[j].append(i)

    if sum(selected.values()) != n - 1:
        raise ValueError("Selected edges do not have spanning-tree cardinality")

    mwp = required_number(variables, "Mwp")
    if mwp < 0:
        raise ValueError("Mwp must be nonnegative")

    paths = {}
    maximum_path_loss = 0.0
    for start in nodes:
        parent = {start: None}
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for neighbor in sorted(adjacency[current]):
                if neighbor not in parent:
                    parent[neighbor] = current
                    queue.append(neighbor)

        if len(parent) != n:
            raise ValueError("Selected edges are not connected")

        for end in nodes:
            path = set()
            current = end
            while current != start:
                previous = parent[current]
                path.add((previous, current))
                current = previous
            paths[start, end] = path
            loss = sum(
                1 - availability[i, j, selected_method]
                for i, j in path
            )
            maximum_path_loss = max(maximum_path_loss, loss)

    tolerance = 1e-6 * max(1.0, abs(mwp), maximum_path_loss)
    if maximum_path_loss > mwp + tolerance:
        raise ValueError("Mwp does not bound the reconstructed tree paths")

    output = {"Mwp": mwp}
    for i, j in sorted(arcs):
        edge = (min(i, j), max(i, j))
        output[f"xs[{i},{j}]"] = selected[edge]

        for method in methods:
            output[f"Inc[{i},{j},{method}]"] = int(
                method == selected_method
            )

        for start in nodes:
            for end in nodes:
                routed = int((i, j) in paths[start, end])
                output[f"x[{i},{j},{start},{end}]"] = routed
                output[f"y[{i},{j},{start},{end}]"] = 0
                for method in methods:
                    product = routed if method == selected_method else 0
                    output[
                        f"Incx[{i},{j},{start},{end},{method}]"
                    ] = product
                    output[
                        f"Incy[{i},{j},{start},{end},{method}]"
                    ] = product

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": output},
            stream,
            allow_nan=False,
            separators=(",", ":"),
        )


if __name__ == "__main__":
    main()