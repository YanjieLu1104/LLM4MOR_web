import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            validate_finite(item, "{}[{}]".format(path, index))


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{} from the default DZN solution".format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    variables = payload["variables"]
    result = {}

    # These values are the singleton coordinate domains in the original
    # self-contained instance, not values inferred from a solver solution.
    fixed_coordinates = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 62,
        "nXNd__1_1_Z": 122,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 102,
        "nXNd__1_10_Z": 100,
    }
    result.update(fixed_coordinates)

    # The original self-contained model explicitly declares nodes 2 through 9
    # as its nonfixed coordinate variables. Their names are unchanged.
    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            result[name] = require_variable(variables, name)

    # Preserve each array's supplied MiniZinc value encoding and index sets.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        value = require_variable(variables, name)
        if not isinstance(value, dict):
            raise ValueError(
                "variables.{} must use the MiniZinc array encoding".format(name)
            )
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables.{} requires array and index_sets fields".format(name)
            )
        if not isinstance(value["array"], list):
            raise ValueError("variables.{}.array must be a list".format(name))
        if not isinstance(value["index_sets"], list):
            raise ValueError("variables.{}.index_sets must be a list".format(name))
        result[name] = value

    # obj is an independent original variable constrained by an equality.
    # Its unchanged declaration is emitted in the default DZN solution.
    result["obj"] = require_variable(variables, "obj")

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    validate_finite(payload, "input")
    result = map_solution(payload)
    validate_finite(result, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)