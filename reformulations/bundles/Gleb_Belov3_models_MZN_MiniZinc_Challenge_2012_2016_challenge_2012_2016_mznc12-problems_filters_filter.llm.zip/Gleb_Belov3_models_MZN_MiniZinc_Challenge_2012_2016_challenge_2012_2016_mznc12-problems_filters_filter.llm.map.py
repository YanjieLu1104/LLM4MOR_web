import json
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    if not isinstance(payload["variables"], dict):
        raise ValueError("Field variables must be a JSON object")

    supplied = payload["variables"]
    restored = {}

    for name in ("t", "r", "end"):
        if name not in supplied or supplied[name] is None:
            raise ValueError(
                "Missing required field: variables."
                + name
                + "; expected from the reformulated model's default DZN solution"
            )
        restored[name] = supplied[name]

    encoded = json.dumps(
        {"variables": restored},
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
    )

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        destination.write(encoded)
        destination.write("\n")


if __name__ == "__main__":
    main()