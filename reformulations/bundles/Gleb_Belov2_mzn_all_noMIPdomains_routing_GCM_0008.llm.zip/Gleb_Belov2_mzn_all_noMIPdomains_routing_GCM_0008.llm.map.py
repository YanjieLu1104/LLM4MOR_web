import json
import math
import sys


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from the default DZN solution".format(name)
        )
    return variables[name]


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(data, "input")
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = data["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 246,
        "nXNd__1_1_Y": 43,
        "nXNd__1_1_Z": 45,
        "nXNd__1_10_X": 211,
        "nXNd__1_10_Y": 53,
        "nXNd__1_10_Z": 5,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = required(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        restored[name] = required(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    else:
        if "objective" not in data or data["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective: one is required "
                "from the reformulated solution"
            )
        objective = data["objective"]
        if (
            isinstance(objective, bool)
            or not isinstance(objective, (int, float))
            or objective != int(objective)
        ):
            raise ValueError("objective must be a finite integer for obj")
        restored["obj"] = int(objective)

    check_finite(restored, "output.variables")
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    main()