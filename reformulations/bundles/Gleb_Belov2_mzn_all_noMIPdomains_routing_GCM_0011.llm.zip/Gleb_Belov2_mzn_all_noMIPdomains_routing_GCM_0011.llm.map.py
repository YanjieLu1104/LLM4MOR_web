import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution"
        )
    return variables[name]


def map_solution(payload):
    if "variables" not in payload:
        raise ValueError("Missing variables; required from the solver solution")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    # These are singleton domains in the original self-contained model.
    fixed_coordinates = {
        "nXNd__1_1_X": 79,
        "nXNd__1_1_Y": 41,
        "nXNd__1_1_Z": 5,
        "nXNd__1_10_X": 125,
        "nXNd__1_10_Y": 60,
        "nXNd__1_10_Z": 163,
    }

    # This literal is the unchanged original nNodePipe instance data.
    original_node_pipe = (1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
    result = {}

    for node in range(1, len(original_node_pipe) + 1):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                result[name] = variables[name]
            elif name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                result[name] = require_variable(variables, name)

    # All six original independent arrays retain their names, meanings,
    # dimensions, and index domains. Copy their complete encoded values.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        result[name] = require_variable(variables, name)

    # obj was independently declared and constrained by an equality.
    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    elif "objective" in payload and payload["objective"] is not None:
        value = payload["objective"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("objective must be finite")
        if value != int(value):
            raise ValueError("objective must be integer-valued for original obj")
        result["obj"] = int(value)
    else:
        raise ValueError(
            "Missing variables.obj and objective; original obj requires "
            "the unchanged reformulated objective value"
        )

    check_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(payload, "input")
    mapped = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(mapped, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    main()