import json
import math
import re
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def finite_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected a numeric value for " + name)
    if not math.isfinite(value):
        raise ValueError("Non-finite value for " + name)
    return value


def integer_value(value, name):
    value = finite_number(value, name)
    result = round(value)
    if abs(value - result) > 1e-5:
        raise ValueError("Expected an integral value for " + name)
    return int(result)


def binary_value(value, name):
    result = integer_value(value, name)
    if result not in (0, 1):
        raise ValueError("Expected a binary value for " + name)
    return result


def required(mapping, key, prefix):
    if key not in mapping:
        raise ValueError("Missing required field: " + prefix + key)
    return mapping[key]


def normalize_keys(mapping, name):
    if not isinstance(mapping, dict):
        raise ValueError(name + " must be an object")
    result = {}
    for key, value in mapping.items():
        normalized = re.sub(r"\s+", "", key)
        if normalized in result:
            raise ValueError("Duplicate normalized key in " + name + ": " + normalized)
        result[normalized] = value
    return result


def supplied_set(sets, name):
    if name not in sets:
        return None
    values = sets[name]
    if not isinstance(values, list):
        raise ValueError("sets." + name + " must be a list")
    result = [integer_value(value, "sets." + name) for value in values]
    if len(result) != len(set(result)):
        raise ValueError("Duplicate member in sets." + name)
    return sorted(result)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    variables = normalize_keys(
        required(payload, "variables", ""), "variables"
    )
    parameters = normalize_keys(
        required(payload, "parameters", ""), "parameters"
    )
    sets = payload.get("sets", {})
    if not isinstance(sets, dict):
        raise ValueError("sets must be an object")

    agents = supplied_set(sets, "Agentes")
    days = supplied_set(sets, "Dias")
    periods = supplied_set(sets, "Periodos")

    if agents is None:
        agents = sorted({
            int(match.group(1))
            for key in parameters
            for match in [re.fullmatch(r"Cap_sem\[(-?\d+)\]", key)]
            if match is not None
        })
        if not agents:
            raise ValueError(
                "Missing required field: sets.Agentes or parameters.Cap_sem[...]"
            )

    demand_indices = {
        (int(match.group(1)), int(match.group(2)))
        for key in parameters
        for match in [re.fullmatch(r"Demanda\[(-?\d+),(-?\d+)\]", key)]
        if match is not None
    }

    if days is None:
        if not demand_indices:
            raise ValueError(
                "Missing required field: sets.Dias or parameters.Demanda[...]"
            )
        days = sorted({day for day, period in demand_indices})

    if periods is None:
        if not demand_indices:
            raise ValueError(
                "Missing required field: sets.Periodos or parameters.Demanda[...]"
            )
        periods = sorted({period for day, period in demand_indices})

    if not agents or not days or not periods:
        raise ValueError("The original index domains must be nonempty")

    output = {}
    work = {}

    for agent in agents:
        key = f"Y[{agent}]"
        output[key] = binary_value(
            required(variables, key, "variables."), key
        )

        for day in days:
            previous = 0
            starts = 0
            for period in periods:
                suffix = f"[{agent},{day},{period}]"
                key = "X" + suffix
                value = binary_value(
                    required(variables, key, "variables."), key
                )
                output[key] = value
                work[agent, day, period] = value

                start = int(value == 1 and previous == 0)
                starts += start
                output["XE" + suffix] = start
                output["B" + suffix] = 0
                previous = value

            if starts > 1:
                raise ValueError(
                    f"Noncontiguous working interval for agent {agent}, day {day}"
                )

    for day in days:
        for period in periods:
            demand_key = f"Demanda[{day},{period}]"
            demand = integer_value(
                required(parameters, demand_key, "parameters."),
                demand_key,
            )
            if demand < 0:
                raise ValueError("Negative demand: " + demand_key)

            working_agents = [
                agent for agent in agents if work[agent, day, period] == 1
            ]
            surplus = len(working_agents) - demand
            if surplus < 0:
                raise ValueError(
                    f"Insufficient coverage for day {day}, period {period}"
                )

            excess_agents = set(working_agents[:surplus])
            for agent in agents:
                output[f"Q[{agent},{day},{period}]"] = int(
                    agent in excess_agents
                )

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": output}, stream, allow_nan=False)


if __name__ == "__main__":
    main()