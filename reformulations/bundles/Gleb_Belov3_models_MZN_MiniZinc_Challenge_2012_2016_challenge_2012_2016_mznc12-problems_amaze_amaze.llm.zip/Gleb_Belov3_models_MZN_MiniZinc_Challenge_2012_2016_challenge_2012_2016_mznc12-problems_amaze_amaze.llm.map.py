import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, list):
        for item in value:
            check_finite(item)
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)


def index_cardinality(value):
    if not isinstance(value, dict):
        raise ValueError("Board index sets must use the set encoding")
    if set(value) == {"range"}:
        bounds = value["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(bound) is not int for bound in bounds)
        ):
            raise ValueError("Invalid board index range")
        return max(0, bounds[1] - bounds[0] + 1)
    if set(value) == {"set"}:
        elements = value["set"]
        if (
            not isinstance(elements, list)
            or any(type(element) is not int for element in elements)
            or len(set(elements)) != len(elements)
        ):
            raise ValueError("Invalid board index set")
        return len(elements)
    raise ValueError("Invalid board index-set encoding")


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")
    if "board" not in data["variables"]:
        raise ValueError(
            "Missing required field variables.board from the solver's "
            "default DZN solution"
        )

    board = data["variables"]["board"]
    if not isinstance(board, dict):
        raise ValueError("variables.board must use the MiniZinc array encoding")
    if "array" not in board or "index_sets" not in board:
        raise ValueError(
            "variables.board requires array and index_sets fields"
        )

    values = board["array"]
    indices = board["index_sets"]
    if not isinstance(values, list):
        raise ValueError("variables.board.array must be a list")
    if not isinstance(indices, list) or len(indices) != 2:
        raise ValueError("variables.board must have two index sets")
    expected_size = index_cardinality(indices[0]) * index_cardinality(indices[1])
    if len(values) != expected_size:
        raise ValueError("Board element count does not match its index sets")
    if any(type(value) is not int for value in values):
        raise ValueError("Board values must be integers")

    result = {
        "variables": {
            "board": {
                "array": values,
                "index_sets": indices,
            }
        }
    }
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()