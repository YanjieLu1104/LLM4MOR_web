import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")

    source = payload["variables"]
    if not isinstance(source, dict):
        raise ValueError("variables must be an object")

    original_names = {"X_FC", "X_ES_in", "X_ES_out", "CostFC", "Effpt"}
    result = {}

    for name, value in source.items():
        if name.split("[", 1)[0] not in original_names:
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Expected numeric value for variables." + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Non-finite value for variables." + name)
        result[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": result}, stream, allow_nan=False)


if __name__ == "__main__":
    main()