import json
import math
import sys


LOCATIONS = (
    "c3_xlarge___0",
    "c3_xlarge___1",
    "c3_xlarge___2",
    "c3_xlarge___3",
    "c3_xlarge___4",
    "m3_medium___5",
    "m3_medium___6",
    "m3_medium___7",
    "m3_medium___8",
    "m3_medium___9",
    "m1_large___10",
    "m1_large___11",
    "m1_large___12",
    "m1_large___13",
    "m1_large___14",
    "m1_xlarge___15",
    "m1_xlarge___16",
    "m1_xlarge___17",
    "m1_xlarge___18",
    "m1_xlarge___19",
    "c3_large___20",
    "c3_large___21",
    "c3_large___22",
    "c3_large___23",
    "c3_large___24",
    "amazon_internals___25",
)

COMPONENTS = (
    "def___fredhoppercloudservices_platformserviceimpl_on",
    "def___fredhoppercloudservices_loadbalancerserviceimpl_on",
    "def___fredhoppercloudservices_deploymentserviceimpl_on",
    "def___fredhoppercloudservices_serviceproviderimpl_on",
    "def___fredhoppercloudservices_queryserviceimpl_on",
    "amazon_internals___fredhoppercloudservices_infrastructureserviceimpl_on",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def integer_value(value, field):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError(field + " must contain a finite integer")


def decode_index_set(encoded, field):
    if not isinstance(encoded, dict):
        raise ValueError(field + " must use the MiniZinc set encoding")

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(field + ".range must contain two bounds")
        lower = integer_value(bounds[0], field + ".range[0]")
        upper = integer_value(bounds[1], field + ".range[1]")
        return list(range(lower, upper + 1))

    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError(field + ".set must be a list")
        values = [
            integer_value(value, field + ".set")
            for value in elements
        ]
        if len(set(values)) != len(values):
            raise ValueError(field + " contains duplicate indices")
        return sorted(values)

    raise ValueError(field + " must contain exactly 'range' or 'set'")


def reconstruct(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document:
        raise ValueError("Missing required input field: variables")
    variables = document["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    name = "zeph_reform_2_counts"
    if name not in variables:
        raise ValueError(
            "Missing required field variables.zeph_reform_2_counts; "
            "it must come from the reformulated model's default DZN output"
        )

    encoded = variables[name]
    if not isinstance(encoded, dict):
        raise ValueError("variables." + name + " must use MiniZinc array encoding")
    if "array" not in encoded:
        raise ValueError("Missing required field variables." + name + ".array")
    if "index_sets" not in encoded:
        raise ValueError(
            "Missing required field variables." + name + ".index_sets"
        )

    index_sets = encoded["index_sets"]
    if not isinstance(index_sets, list) or len(index_sets) != 2:
        raise ValueError(name + " must have exactly two index sets")

    location_indices = decode_index_set(
        index_sets[0], name + ".index_sets[0]"
    )
    component_indices = decode_index_set(
        index_sets[1], name + ".index_sets[1]"
    )

    if location_indices != list(range(1, len(LOCATIONS) + 1)):
        raise ValueError(name + " has an unexpected location index domain")
    if component_indices != list(range(1, len(COMPONENTS) + 1)):
        raise ValueError(name + " has an unexpected component index domain")

    elements = encoded["array"]
    expected_length = len(LOCATIONS) * len(COMPONENTS)
    if not isinstance(elements, list) or len(elements) != expected_length:
        raise ValueError(name + " has an incorrect flattened element count")

    counts = [
        integer_value(value, name + ".array[" + str(position) + "]")
        for position, value in enumerate(elements)
    ]

    restored = {}
    totals = [0 for _ in COMPONENTS]
    width = len(COMPONENTS)

    for location_position, location in enumerate(LOCATIONS):
        for component_position, component in enumerate(COMPONENTS):
            value = counts[location_position * width + component_position]
            original_name = "local_" + location + "_component_" + component
            restored[original_name] = value
            totals[component_position] += value

    for component, total in zip(COMPONENTS, totals):
        restored["global_component_" + component] = total

    restored["objective"] = (
        2 * (totals[0] + totals[1] + totals[3] + totals[4])
        + totals[2]
        + totals[5]
    )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    result = reconstruct(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, indent=2)
        destination.write("\n")


if __name__ == "__main__":
    main()