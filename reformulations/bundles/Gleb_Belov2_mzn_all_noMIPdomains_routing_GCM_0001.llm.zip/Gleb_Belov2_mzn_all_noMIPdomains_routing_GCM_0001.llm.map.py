import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 348,
    "nXNd__1_1_Y": 142,
    "nXNd__1_1_Z": 20,
    "nXNd__1_10_X": 302,
    "nXNd__1_10_Y": 60,
    "nXNd__1_10_Z": 88,
}

ORIGINAL_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{}; "
            "source must be the reformulated model's default DZN solution."
            .format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables.")

    variables = payload["variables"]
    restored = {}

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in FIXED_COORDINATES:
                if name in variables and variables[name] is not None:
                    restored[name] = variables[name]
                else:
                    restored[name] = FIXED_COORDINATES[name]
            else:
                restored[name] = required_value(variables, name)

    for name in ORIGINAL_ARRAYS:
        value = required_value(variables, name)
        if not isinstance(value, dict):
            raise ValueError(
                "variables.{} must use the MiniZinc array encoding.".format(name)
            )
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables.{} must contain array and index_sets.".format(name)
            )
        if not isinstance(value["array"], list):
            raise ValueError("variables.{}.array must be a list.".format(name))
        if not isinstance(value["index_sets"], list):
            raise ValueError(
                "variables.{}.index_sets must be a list.".format(name)
            )
        restored[name] = value

    restored["obj"] = required_value(variables, "obj")
    result = {"variables": restored}
    check_finite(result, "output")
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)