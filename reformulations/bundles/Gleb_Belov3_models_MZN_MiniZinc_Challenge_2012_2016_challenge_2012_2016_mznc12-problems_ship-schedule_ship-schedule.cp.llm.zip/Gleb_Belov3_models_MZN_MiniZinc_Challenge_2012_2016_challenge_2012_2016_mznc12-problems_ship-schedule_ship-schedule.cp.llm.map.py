import json
import math
import sys


ORIGINAL_VARIABLES = (
    "TransitStartTimeSlot",
    "ShipSails",
    "Draft_cm",
    "TugsBusy",
    "TugsBusyExtra",
    "TugsBusyPerTimeSlot",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_value(value, path):
    if value is None:
        raise ValueError("Missing solution value at " + path)
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite solution value at " + path)
    if isinstance(value, list):
        for index, item in enumerate(value):
            validate_value(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_value(item, path + "." + key)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    missing = [
        name for name in ORIGINAL_VARIABLES
        if name not in variables or variables[name] is None
    ]
    if missing:
        raise ValueError(
            "Missing original solution arrays from default DZN output "
            "(required source: variables): " + ", ".join(missing)
        )

    restored = {}
    for name in ORIGINAL_VARIABLES:
        value = variables[name]
        validate_value(value, "variables." + name)
        restored[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)