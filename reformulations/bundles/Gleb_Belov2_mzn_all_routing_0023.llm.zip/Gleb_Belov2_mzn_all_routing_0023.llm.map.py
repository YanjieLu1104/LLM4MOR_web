import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 275,
    "nXNd__1_1_Y": 54,
    "nXNd__1_1_Z": 8,
    "nXNd__1_10_X": 255,
    "nXNd__1_10_Y": 52,
    "nXNd__1_10_Z": 143,
}

COORDINATE_NAMES = tuple(
    f"nXNd__1_{node}_{axis}"
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
)

ARRAY_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError(f"Invalid nonfinite JSON number: {value}")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON object key: {key}")
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"Nonfinite number at {path}")
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, f"{path}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, f"{path}[{index}]")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            f"Missing required field variables.{name}; "
            "it must be supplied by the reformulated model's default DZN output."
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field: variables")

    check_finite(payload, "input")
    variables = payload["variables"]
    restored = {}

    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in FIXED_COORDINATES:
            restored[name] = FIXED_COORDINATES[name]
        else:
            restored[name] = require_variable(variables, name)

    for name in ARRAY_NAMES:
        value = require_variable(variables, name)
        if not isinstance(value, dict):
            raise ValueError(
                f"variables.{name} must use the MiniZinc array encoding."
            )
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                f"variables.{name} requires both array and index_sets."
            )
        if not isinstance(value["array"], list):
            raise ValueError(f"variables.{name}.array must be a list.")
        if not isinstance(value["index_sets"], list):
            raise ValueError(f"variables.{name}.index_sets must be a list.")
        restored[name] = value

    restored["obj"] = require_variable(variables, "obj")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    result = map_solution(payload)
    encoded = json.dumps(result, allow_nan=False, separators=(",", ":"))

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        destination.write(encoded)
        destination.write("\n")


if __name__ == "__main__":
    main()