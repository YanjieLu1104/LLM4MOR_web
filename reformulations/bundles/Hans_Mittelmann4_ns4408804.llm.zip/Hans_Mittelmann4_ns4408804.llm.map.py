import json
import math
import sys


def reject_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=reject_duplicates,
            parse_constant=reject_constant,
        )

    if "variables" not in data:
        raise ValueError("Missing required field: variables")

    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be an object")

    for name, value in variables.items():
        if not (name.startswith("x[") or name.startswith("y[")):
            raise ValueError("Unexpected variable: " + name)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Variable must have a numeric value: " + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Variable must have a finite value: " + name)

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump({"variables": variables}, target, allow_nan=False)


if __name__ == "__main__":
    main()