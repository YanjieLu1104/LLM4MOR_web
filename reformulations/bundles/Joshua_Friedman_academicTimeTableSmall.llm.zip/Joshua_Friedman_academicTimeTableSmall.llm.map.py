import json
import math
import sys


def reject_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=reject_duplicates,
            parse_constant=reject_constant,
        )

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be an object")

    original_names = {
        "z", "gapday", "tg2", "tg3", "y1", "y2", "w",
        "y3", "y4", "y5", "tues", "ptv", "ptvDoc",
        "ptvAdj", "x", "u",
    }

    restored = {}
    for name, value in variables.items():
        if name.split("[", 1)[0] not in original_names:
            raise ValueError("Unexpected variable: " + name)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Variable must have a numeric value: " + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Non-finite variable value: " + name)
        restored[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            ensure_ascii=False,
        )


if __name__ == "__main__":
    main()