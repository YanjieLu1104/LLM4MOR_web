import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def require_number(container, name, prefix):
    if name not in container:
        raise ValueError("Missing required field: " + prefix + name)
    value = container[name]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected numeric value: " + prefix + name)
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite value: " + prefix + name)
    return value


def require_dimension(parameters, name):
    value = require_number(parameters, name, "parameters.")
    if value < 0 or value != int(value):
        raise ValueError("Expected nonnegative integer: parameters." + name)
    return int(value)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    for field in ("variables", "parameters"):
        if field not in payload:
            raise ValueError("Missing required field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError("Expected object: " + field)

    variables = payload["variables"]
    parameters = payload["parameters"]
    num_comp = require_dimension(parameters, "num_comp")
    num_node = require_dimension(parameters, "num_node")
    dist = require_number(parameters, "dist", "parameters.")

    restored = {}

    def copy_value(name):
        restored[name] = require_number(variables, name, "variables.")

    for u in range(1, num_node + 1):
        for i in range(1, num_comp + 1):
            copy_value(f"c[{u},{i}]")
            copy_value(f"y[{u},{i}]")

        for v in range(1, num_node + 1):
            name = f"x[{u},{v}]"
            if 0 < v - u <= dist:
                copy_value(name)
            else:
                restored[name] = 0

        for i in range(1, num_comp + 1):
            for j in range(1, num_comp + 1):
                name = f"cc[{u},{i},{j}]"
                if i < j:
                    copy_value(name)
                else:
                    restored[name] = 0

            for v in range(1, num_node + 1):
                name = f"cx[{u},{i},{v}]"
                if 0 < v - u <= dist:
                    copy_value(name)
                else:
                    restored[name] = 0

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": restored},
            stream,
            allow_nan=False,
            separators=(",", ":"),
        )
        stream.write("\n")


if __name__ == "__main__":
    main()