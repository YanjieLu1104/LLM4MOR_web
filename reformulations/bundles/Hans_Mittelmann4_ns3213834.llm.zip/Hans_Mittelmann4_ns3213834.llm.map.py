import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def finite_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(name + " must be a finite number")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(name + " must be a finite number")
    return value


def required_number(container, key, prefix):
    if key not in container:
        raise ValueError("Missing required field: " + prefix + key)
    return finite_number(container[key], prefix + key)


def dimension(parameters, name):
    value = required_number(parameters, name, "parameters.")
    if value < 0 or int(value) != value:
        raise ValueError("parameters." + name + " must be a nonnegative integer")
    return int(value)


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    for field in ("variables", "parameters"):
        if field not in payload:
            raise ValueError("Missing required field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError(field + " must be a JSON object")

    parameters = payload["parameters"]
    source = payload["variables"]

    num_comp = dimension(parameters, "num_comp")
    num_node = dimension(parameters, "num_node")
    dist = required_number(parameters, "dist", "parameters.")

    def read(key):
        return required_number(source, key, "variables.")

    restored = {}

    for u in range(1, num_node + 1):
        for i in range(1, num_comp + 1):
            for name in ("c", "y"):
                key = f"{name}[{u},{i}]"
                restored[key] = read(key)

        for v in range(1, num_node + 1):
            active = 0 < v - u <= dist
            key = f"x[{u},{v}]"
            restored[key] = read(key) if active else 0

            for i in range(1, num_comp + 1):
                original_key = f"cx[{u},{i},{v}]"
                restored[original_key] = (
                    read(f"cx[{u},{v},{i}]") if active else 0
                )

        for i in range(1, num_comp + 1):
            for j in range(1, num_comp + 1):
                key = f"cc[{u},{i},{j}]"
                restored[key] = read(key) if i < j else 0

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(result, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)