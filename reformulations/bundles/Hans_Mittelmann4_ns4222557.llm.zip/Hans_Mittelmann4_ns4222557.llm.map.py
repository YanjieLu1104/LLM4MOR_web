import json
import math
import re
import sys


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def numeric(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected a numeric value for " + name)
    if not math.isfinite(value):
        raise ValueError("Nonfinite value for " + name)
    return value


def required_number(container, key, prefix):
    if key not in container:
        raise ValueError("Missing field: " + prefix + key)
    return numeric(container[key], prefix + key)


def integer_parameter(parameters, name):
    value = required_number(parameters, name, "parameters.")
    if value != int(value) or value < 1:
        raise ValueError("Expected a positive integer parameter: " + name)
    return int(value)


def variable_key(name, *indices):
    return name + "[" + ",".join(str(index) for index in indices) + "]"


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    for field in ("variables", "parameters"):
        if field not in payload:
            raise ValueError("Missing field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError("Expected an object for " + field)

    parameters = payload["parameters"]
    node_count = integer_parameter(parameters, "nodes")
    method_count = integer_parameter(parameters, "K")

    variables = {}
    for key, value in payload["variables"].items():
        normalized = re.sub(r"\s+", "", key)
        if normalized in variables:
            raise ValueError("Duplicate normalized variable: " + normalized)
        variables[normalized] = numeric(value, "variables." + key)

    def get(name, *indices):
        key = variable_key(name, *indices) if indices else name
        return required_number(variables, key, "variables.")

    edges = set()
    spine_pattern = re.compile(r"xs\[(\d+),(\d+)\]")
    for key in variables:
        match = spine_pattern.fullmatch(key)
        if match:
            i, j = map(int, match.groups())
            if not 1 <= i < j <= node_count:
                raise ValueError("Invalid reduced spine index: " + key)
            edges.add((i, j))

    upgrade_arcs = set()
    upgrade_pattern = re.compile(r"Inc\[(\d+),(\d+),(\d+)\]")
    for key in variables:
        match = upgrade_pattern.fullmatch(key)
        if match:
            i, j, method = map(int, match.groups())
            if not (
                1 <= i <= node_count
                and 1 <= j <= node_count
                and i != j
                and 1 <= method <= method_count
            ):
                raise ValueError("Invalid upgrade index: " + key)
            upgrade_arcs.add((i, j))

    if not edges:
        raise ValueError("Missing field: variables.xs[...]")
    if not upgrade_arcs:
        raise ValueError("Missing field: variables.Inc[...]")

    arcs = set()
    for i, j in edges:
        arcs.add((i, j))
        arcs.add((j, i))

    if arcs != upgrade_arcs:
        missing_spine = upgrade_arcs - arcs
        if missing_spine:
            i, j = min(missing_spine)
            raise ValueError(
                "Missing field: variables."
                + variable_key("xs", min(i, j), max(i, j))
            )
        i, j = min(arcs - upgrade_arcs)
        raise ValueError(
            "Missing field: variables." + variable_key("Inc", i, j, 1)
        )

    output = {"Mwp": get("Mwp")}

    for i, j in sorted(arcs):
        output[variable_key("xs", i, j)] = get("xs", min(i, j), max(i, j))

        improvements = {}
        for method in range(1, method_count + 1):
            value = get("Inc", i, j, method)
            improvements[method] = value
            output[variable_key("Inc", i, j, method)] = value

        for s in range(1, node_count + 1):
            for t in range(1, node_count + 1):
                if s == t:
                    working = 0
                    backup = 0
                elif s < t:
                    working = get("x", i, j, s, t)
                    backup = get("y", i, j, s, t)
                else:
                    working = get("x", j, i, t, s)
                    backup = get("y", j, i, t, s)

                output[variable_key("x", i, j, s, t)] = working
                output[variable_key("y", i, j, s, t)] = backup

                for method, improvement in improvements.items():
                    wp_key = variable_key("Incx", i, j, s, t, method)
                    bp_key = variable_key("Incy", i, j, s, t, method)
                    output[wp_key] = numeric(working * improvement, wp_key)
                    output[bp_key] = numeric(backup * improvement, bp_key)

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": output}, stream, allow_nan=False)


if __name__ == "__main__":
    main()