import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("All JSON numbers must be finite")
    elif isinstance(value, list):
        for item in value:
            check_finite(item)
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object")
    if "parameters" not in data or not isinstance(data["parameters"], dict):
        raise ValueError("Missing or invalid parameters object")

    variables = data["variables"]
    parameters = data["parameters"]
    restored = {}

    for name in ("p", "objective"):
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in parameters and parameters[name] is not None:
            restored[name] = parameters[name]
        elif name == "objective" and data.get("objective") is not None:
            value = data["objective"]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("The objective field must be a finite number")
            if isinstance(value, float) and not value.is_integer():
                raise ValueError("The original objective must be integral")
            restored[name] = int(value)
        else:
            raise ValueError(
                "Missing original variable "
                + name
                + ": required from variables."
                + name
                + " in the default DZN solution, or parameters."
                + name
                + " if externally fixed"
            )

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump({"variables": restored}, target, allow_nan=False)
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)