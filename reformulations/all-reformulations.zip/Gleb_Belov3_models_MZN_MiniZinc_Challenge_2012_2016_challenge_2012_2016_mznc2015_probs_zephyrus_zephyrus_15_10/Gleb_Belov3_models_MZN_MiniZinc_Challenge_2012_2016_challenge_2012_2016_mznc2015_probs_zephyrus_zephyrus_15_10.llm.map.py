import json
import math
import sys


GROUPS = (
    ("c3_xlarge", 15),
    ("m3_medium", 15),
    ("m1_large", 15),
    ("m1_xlarge", 15),
    ("c3_large", 15),
    ("amazon_internals", 1),
)

COMPONENTS = (
    ("def", "platformserviceimpl"),
    ("def", "loadbalancerserviceimpl"),
    ("def", "deploymentserviceimpl"),
    ("def", "serviceproviderimpl"),
    ("def", "queryserviceimpl"),
    ("amazon_internals", "infrastructureserviceimpl"),
)

WEIGHTS = (2, 2, 1, 2, 2, 1)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def decode_index_set(value):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded integer index set")
    if set(value) == {"range"}:
        bounds = value["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(bound) is not int for bound in bounds)
        ):
            raise ValueError("Invalid index range")
        return list(range(bounds[0], bounds[1] + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if (
            not isinstance(elements, list)
            or any(type(element) is not int for element in elements)
            or len(set(elements)) != len(elements)
        ):
            raise ValueError("Invalid integer index set")
        return sorted(elements)
    raise ValueError("Unsupported index-set encoding")


def integer_value(value):
    if type(value) is int:
        return value
    if type(value) is float and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("zph15_counts must contain finite integers")


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        source = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if "variables" not in source or not isinstance(source["variables"], dict):
        raise ValueError("Missing required input field: variables")

    variables = source["variables"]
    if "zph15_counts" not in variables:
        raise ValueError(
            "Missing required solver-output field: variables.zph15_counts"
        )

    encoded = variables["zph15_counts"]
    if not isinstance(encoded, dict):
        raise ValueError("zph15_counts must use the MiniZinc array encoding")
    if "array" not in encoded or "index_sets" not in encoded:
        raise ValueError("zph15_counts requires array and index_sets fields")

    locations = [
        group_name
        for group_name, group_size in GROUPS
        for _ in range(group_size)
    ]
    n_locations = len(locations)
    n_components = len(COMPONENTS)

    index_sets = encoded["index_sets"]
    if not isinstance(index_sets, list) or len(index_sets) != 2:
        raise ValueError("zph15_counts must have exactly two index sets")
    if decode_index_set(index_sets[0]) != list(range(1, n_locations + 1)):
        raise ValueError("Unexpected location index set for zph15_counts")
    if decode_index_set(index_sets[1]) != list(range(1, n_components + 1)):
        raise ValueError("Unexpected component index set for zph15_counts")

    flat = encoded["array"]
    if not isinstance(flat, list) or len(flat) != n_locations * n_components:
        raise ValueError("Unexpected element count for zph15_counts")
    flat = [integer_value(value) for value in flat]

    restored = {}
    totals = [0 for _ in COMPONENTS]

    for location_id, location_name in enumerate(locations):
        for component_id, (namespace, component_name) in enumerate(COMPONENTS):
            value = flat[location_id * n_components + component_id]
            original_name = (
                f"local_{location_name}___{location_id}_component_"
                f"{namespace}___fredhoppercloudservices_{component_name}_on"
            )
            restored[original_name] = value
            totals[component_id] += value

    for component_id, (namespace, component_name) in enumerate(COMPONENTS):
        original_name = (
            f"global_component_{namespace}___fredhoppercloudservices_"
            f"{component_name}_on"
        )
        restored[original_name] = totals[component_id]

    restored["objective"] = sum(
        weight * total for weight, total in zip(WEIGHTS, totals)
    )

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": restored}, stream, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()