import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, list):
        for entry in value:
            check_finite(entry)
    elif isinstance(value, dict):
        for entry in value.values():
            check_finite(entry)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(payload)

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise KeyError("Missing field: variables (solver DZN output)")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")
    if "b" not in variables or variables["b"] is None:
        raise KeyError("Missing field: variables.b (solver DZN output)")

    result = {"variables": {"b": variables["b"]}}
    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(result, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    main()