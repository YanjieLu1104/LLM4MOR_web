import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def map_solution(data):
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid required field: variables")
    variables = data["variables"]
    result = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 176,
        "nXNd__1_1_Y": 44,
        "nXNd__1_1_Z": 27,
        "nXNd__1_10_X": 210,
        "nXNd__1_10_Y": 83,
        "nXNd__1_10_Z": 45,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                result[name] = variables[name]
            elif name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                raise ValueError(
                    "Missing required field: variables." + name
                    + " (original coordinate retained in the reformulated model)"
                )

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables." + name
                + " (original independent array retained in the reformulated model)"
            )
        value = variables[name]
        if not isinstance(value, dict):
            raise ValueError("Expected encoded MiniZinc array: variables." + name)
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "Missing array or index_sets in variables." + name
            )
        result[name] = value

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    elif "objective" in data and data["objective"] is not None:
        objective = data["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("Expected numeric field: objective")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("Expected finite integer objective")
        result["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing required field: variables.obj or objective"
        )

    check_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(data, "input")
    mapped = map_solution(data)
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(mapped, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)