import json
import math
import sys


ORIGINAL_VARIABLES = (
    "TransitStartTimeSlot",
    "ShipSails",
    "Draft_cm",
    "TugsBusy",
    "TugsBusyExtra",
    "TugsBusyPerTimeSlot",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            validate_finite(item, path + "[" + str(position) + "]")


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    validate_finite(payload, "input")

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    restored = {}
    for name in ORIGINAL_VARIABLES:
        if name not in variables:
            raise ValueError(
                "Missing required field: variables."
                + name
                + " (required source: default DZN solution of the "
                  "retained original decision-variable array)"
            )
        if variables[name] is None:
            raise ValueError("Missing solution value: variables." + name)
        restored[name] = variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    main()