import json
import math
import sys


def zrf_unique_object(zrf_pairs):
    zrf_result = {}
    for zrf_key, zrf_value in zrf_pairs:
        if zrf_key in zrf_result:
            raise ValueError("Duplicate JSON key: " + zrf_key)
        zrf_result[zrf_key] = zrf_value
    return zrf_result


def zrf_reject_constant(zrf_token):
    raise ValueError("Non-finite JSON number: " + zrf_token)


def zrf_read_integer(zrf_variables, zrf_name):
    if zrf_name not in zrf_variables:
        raise ValueError(
            "Missing required field variables."
            + zrf_name
            + " from the reformulated model's default DZN solution"
        )
    zrf_value = zrf_variables[zrf_name]
    if isinstance(zrf_value, bool):
        raise ValueError("Expected integer for variables." + zrf_name)
    if isinstance(zrf_value, int):
        return zrf_value
    if (
        isinstance(zrf_value, float)
        and math.isfinite(zrf_value)
        and zrf_value.is_integer()
    ):
        return int(zrf_value)
    raise ValueError("Expected finite integer for variables." + zrf_name)


def zrf_main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as zrf_stream:
        zrf_payload = json.load(
            zrf_stream,
            object_pairs_hook=zrf_unique_object,
            parse_constant=zrf_reject_constant,
        )

    if "variables" not in zrf_payload:
        raise ValueError("Missing required field variables")
    zrf_variables = zrf_payload["variables"]
    if not isinstance(zrf_variables, dict):
        raise ValueError("Field variables must be a JSON object")

    zrf_components = (
        "def___fredhoppercloudservices_platformserviceimpl_on",
        "def___fredhoppercloudservices_loadbalancerserviceimpl_on",
        "def___fredhoppercloudservices_deploymentserviceimpl_on",
        "def___fredhoppercloudservices_serviceproviderimpl_on",
        "def___fredhoppercloudservices_queryserviceimpl_on",
        "amazon_internals___fredhoppercloudservices_infrastructureserviceimpl_on",
    )

    zrf_totals = []
    for zrf_component_index, zrf_component in enumerate(zrf_components):
        if zrf_component_index == 4:
            zrf_totals.append(2)
        else:
            zrf_totals.append(
                zrf_read_integer(
                    zrf_variables, "global_component_" + zrf_component
                )
            )

    zrf_restored = {
        "global_component_" + zrf_component: zrf_totals[zrf_component_index]
        for zrf_component_index, zrf_component in enumerate(zrf_components)
    }
    zrf_restored["objective"] = (
        2 * (
            zrf_totals[0]
            + zrf_totals[1]
            + zrf_totals[3]
            + zrf_totals[4]
        )
        + zrf_totals[2]
        + zrf_totals[5]
    )

    zrf_location_groups = (
        ("c3_xlarge", 0, 15),
        ("m3_medium", 15, 30),
        ("m1_large", 30, 45),
        ("m1_xlarge", 45, 60),
        ("c3_large", 60, 75),
        ("amazon_internals", 75, 76),
    )

    for zrf_location_type, zrf_start, zrf_stop in zrf_location_groups:
        for zrf_location in range(zrf_start, zrf_stop):
            zrf_local = [0] * len(zrf_components)

            if zrf_location == 0:
                zrf_local[2] = zrf_totals[2] - 1
                zrf_local[4] = 1
            elif zrf_location == 1:
                zrf_local[2] = 1
                zrf_local[4] = 1
            elif zrf_location == 2:
                zrf_local[0] = zrf_totals[0]
                zrf_local[3] = zrf_totals[3]
            elif zrf_location == 3:
                zrf_local[1] = zrf_totals[1]
            elif zrf_location == 4:
                zrf_local[5] = zrf_totals[5]

            zrf_prefix = (
                "local_"
                + zrf_location_type
                + "___"
                + str(zrf_location)
                + "_component_"
            )
            for zrf_component_index, zrf_component in enumerate(zrf_components):
                zrf_restored[zrf_prefix + zrf_component] = (
                    zrf_local[zrf_component_index]
                )

    with open(sys.argv[2], "w", encoding="utf-8") as zrf_stream:
        json.dump(
            {"variables": zrf_restored},
            zrf_stream,
            allow_nan=False,
            sort_keys=True,
        )
        zrf_stream.write("\n")


if __name__ == "__main__":
    zrf_main()