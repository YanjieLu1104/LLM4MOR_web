import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("All JSON numbers must be finite")
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload)

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field: variables")

    variables = payload["variables"]
    if "s" not in variables or variables["s"] is None:
        raise ValueError(
            "Missing required field: variables.s; "
            "source must be the reformulated solver's default DZN solution"
        )

    sequence = variables["s"]
    if not isinstance(sequence, dict):
        raise ValueError("variables.s must use the MiniZinc array encoding")
    if "array" not in sequence or not isinstance(sequence["array"], list):
        raise ValueError("Missing or invalid required field: variables.s.array")
    if "index_sets" not in sequence:
        raise ValueError("Missing required field: variables.s.index_sets")
    if (
        not isinstance(sequence["index_sets"], list)
        or len(sequence["index_sets"]) != 1
    ):
        raise ValueError("variables.s must have exactly one index set")
    if any(type(value) is not int for value in sequence["array"]):
        raise ValueError("variables.s.array must contain integer values")

    result = {
        "variables": {
            "s": {
                "array": sequence["array"],
                "index_sets": sequence["index_sets"],
            }
        }
    }

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()