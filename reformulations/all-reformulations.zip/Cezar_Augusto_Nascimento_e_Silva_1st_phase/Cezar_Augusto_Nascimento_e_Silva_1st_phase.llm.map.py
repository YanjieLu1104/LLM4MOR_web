import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    original_names = {"x", "center_dist", "dist", "zV"}

    for name, value in variables.items():
        if name.split("[", 1)[0] not in original_names:
            raise ValueError("Unexpected variable: " + name)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Variable value must be numeric: " + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Variable value must be finite: " + name)

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": variables}, stream, allow_nan=False)


if __name__ == "__main__":
    main()