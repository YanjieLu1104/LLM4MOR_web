import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite numeric value in input")
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        data = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = data["variables"]
    parameters = data["parameters"] if "parameters" in data else {}
    if not isinstance(parameters, dict):
        raise ValueError("Invalid input field: parameters")

    restored = {}
    for name in ("es", "objective", "root", "h", "p"):
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in parameters and parameters[name] is not None:
            restored[name] = parameters[name]
        elif (
            name == "objective"
            and "objective" in data
            and data["objective"] is not None
        ):
            value = data["objective"]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("The objective must be an integer-valued number")
            if isinstance(value, float) and not value.is_integer():
                raise ValueError("The objective must be integer-valued")
            restored[name] = int(value)
        else:
            raise ValueError(
                "Missing original variable "
                + name
                + ": expected variables."
                + name
                + " from default DZN output, or its original data binding "
                + "in parameters."
                + name
            )

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": restored}, stream, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()