import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            check_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        source = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(source, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(source, "input")

    if "variables" not in source:
        raise ValueError("Missing required field: variables")
    variables = source["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    restored = {}
    for name in ("def", "loc", "sel", "place", "succ"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables."
                + name
                + " from the reformulated model's default DZN solution"
            )
        restored[name] = variables[name]

    if "objective" in variables and variables["objective"] is not None:
        objective = variables["objective"]
    elif "objective" in source and source["objective"] is not None:
        objective = source["objective"]
    else:
        raise ValueError(
            "Missing original objective: require variables.objective "
            "from the default DZN solution or the shared objective field"
        )

    if isinstance(objective, bool) or not isinstance(objective, (int, float)):
        raise ValueError("objective must be a finite integer-valued number")
    if isinstance(objective, float):
        if not math.isfinite(objective) or not objective.is_integer():
            raise ValueError("objective must be a finite integer-valued number")
        objective = int(objective)

    restored["objective"] = objective

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": restored},
            stream,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        )
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)