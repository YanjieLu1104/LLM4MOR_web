import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{} from the default DZN "
            "solution output".format(name)
        )
    return variables[name]


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    variables = data["variables"]
    restored = {}

    # These singleton domains are fixed in the original self-contained model.
    fixed_coordinates = {
        "nXNd__1_1_X": 348,
        "nXNd__1_1_Y": 142,
        "nXNd__1_1_Z": 20,
        "nXNd__1_10_X": 302,
        "nXNd__1_10_Y": 60,
        "nXNd__1_10_Z": 88,
    }

    # The node count and names below are from the original embedded instance.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = required_variable(variables, name)

    # These original independent arrays are retained with unchanged index sets.
    # Copying their encoded values preserves dimensions and index domains.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        restored[name] = required_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in data and data["objective"] is not None:
        value = data["objective"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Field objective must be a finite integer value")
        if isinstance(value, float):
            if not math.isfinite(value) or not value.is_integer():
                raise ValueError("Field objective must be a finite integer value")
        restored["obj"] = int(value)
    else:
        raise ValueError(
            "Missing variables.obj from default DZN output and missing "
            "objective for the same reformulated solution"
        )

    result = {"variables": restored}
    check_finite(result, "output")
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        data = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data, "input")
    result = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(result, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)