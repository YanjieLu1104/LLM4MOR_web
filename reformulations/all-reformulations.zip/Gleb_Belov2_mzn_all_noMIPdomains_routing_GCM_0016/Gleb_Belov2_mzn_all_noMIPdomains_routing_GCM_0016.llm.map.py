import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def require_integer(value, name):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(name + " must be an integer")
    return value


def decode_index_set(value, name):
    if not isinstance(value, dict):
        raise ValueError(name + " must use the MiniZinc index-set encoding")
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(name + ".range must contain two integers")
        lower = require_integer(bounds[0], name + ".range[0]")
        upper = require_integer(bounds[1], name + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(name + ".set must be a list")
        for element in elements:
            require_integer(element, name + ".set element")
        if len(set(elements)) != len(elements):
            raise ValueError(name + ".set contains duplicate indices")
        return sorted(elements)
    raise ValueError(name + " has an invalid index-set encoding")


def require_field(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables." + name
            + "; it must come from the reformulated model's default DZN solution"
        )
    return variables[name]


def copy_array(variables, name, expected_indices, context_indices):
    value = require_field(variables, name)
    if not isinstance(value, dict):
        raise ValueError("variables." + name + " must be an encoded array")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "variables." + name + " must contain array and index_sets"
        )
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding for variables." + name)
    decoded = [
        decode_index_set(index_set, "variables." + name + ".index_sets")
        for index_set in index_sets
    ]
    if decoded != expected_indices:
        raise ValueError("Incorrect index domains for variables." + name)
    size = 1
    for domain in decoded:
        size *= len(domain)
    if len(elements) != size:
        raise ValueError("Incorrect element count for variables." + name)
    for element in elements:
        require_integer(element, "variables." + name + ".array element")
    if name in context_indices:
        original_sets = context_indices[name]
        if not isinstance(original_sets, list):
            raise ValueError("indices." + name + " must be a list")
        original_decoded = [
            decode_index_set(index_set, "indices." + name)
            for index_set in original_sets
        ]
        if original_decoded != decoded:
            raise ValueError(
                "variables." + name + " disagrees with original indices." + name
            )
    return {"array": elements, "index_sets": index_sets}


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables")
    variables = payload["variables"]
    context_indices = payload["indices"] if "indices" in payload else {}
    if not isinstance(context_indices, dict):
        raise ValueError("indices must be an object")

    result = {}

    # These values and dimensions are embedded in the original self-contained
    # model, not taken from an external instance or auxiliary model parameters.
    fixed_coordinates = {
        "nXNd__1_1_X": 210,
        "nXNd__1_1_Y": 83,
        "nXNd__1_1_Z": 52,
        "nXNd__1_10_X": 55,
        "nXNd__1_10_Y": 114,
        "nXNd__1_10_Z": 80,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                result[name] = require_integer(
                    require_field(variables, name), "variables." + name
                )

    node_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        result[name] = copy_array(
            variables, name, [node_domain, coordinate_domain], context_indices
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        result[name] = copy_array(
            variables, name, [node_domain], context_indices
        )

    result["obj"] = require_integer(
        require_field(variables, "obj"), "variables.obj"
    )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)