import json
import math
import sys


RF01_GROUPS = (
    ("c3_xlarge", 0, 19),
    ("m3_medium", 20, 39),
    ("m1_large", 40, 59),
    ("m1_xlarge", 60, 79),
    ("c3_large", 80, 99),
    ("amazon_internals", 100, 100),
)

RF01_COMPONENTS = (
    "component_def___fredhoppercloudservices_platformserviceimpl_on",
    "component_def___fredhoppercloudservices_loadbalancerserviceimpl_on",
    "component_def___fredhoppercloudservices_deploymentserviceimpl_on",
    "component_def___fredhoppercloudservices_serviceproviderimpl_on",
    "component_def___fredhoppercloudservices_queryserviceimpl_on",
    "component_amazon_internals___fredhoppercloudservices_infrastructureserviceimpl_on",
)


def rf01_unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def rf01_reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def rf01_integer(value, field):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError(field + " must be a finite integer")


def rf01_decode_index(value, field):
    if not isinstance(value, dict):
        raise ValueError(field + " must be an encoded index set")
    if set(value) == {"range"}:
        endpoints = value["range"]
        if not isinstance(endpoints, list) or len(endpoints) != 2:
            raise ValueError(field + ".range must contain two endpoints")
        lower = rf01_integer(endpoints[0], field + ".range[0]")
        upper = rf01_integer(endpoints[1], field + ".range[1]")
        if upper < lower:
            return []
        if upper - lower > 10000:
            raise ValueError(field + " has an unexpected size")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(field + ".set must be a list")
        result = [
            rf01_integer(element, field + ".set")
            for element in elements
        ]
        if len(set(result)) != len(result):
            raise ValueError(field + " contains duplicate indices")
        return sorted(result)
    raise ValueError(field + " must use range or set encoding")


def rf01_map(payload):
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be an object")
    if "rf01_count" not in variables:
        raise ValueError(
            "Missing required field: variables.rf01_count "
            "(independent array from default DZN output)"
        )

    encoded = variables["rf01_count"]
    if not isinstance(encoded, dict):
        raise ValueError("variables.rf01_count must be an encoded array")
    for field in ("array", "index_sets"):
        if field not in encoded:
            raise ValueError("Missing required field: variables.rf01_count." + field)

    locations = [
        (family, location)
        for family, lower, upper in RF01_GROUPS
        for location in range(lower, upper + 1)
    ]
    row_count = len(locations)
    column_count = len(RF01_COMPONENTS)

    index_sets = encoded["index_sets"]
    if not isinstance(index_sets, list) or len(index_sets) != 2:
        raise ValueError("variables.rf01_count must have two index sets")

    rows = rf01_decode_index(index_sets[0], "rf01_count.index_sets[0]")
    columns = rf01_decode_index(index_sets[1], "rf01_count.index_sets[1]")
    if rows != list(range(1, row_count + 1)):
        raise ValueError("Unexpected row index domain for rf01_count")
    if columns != list(range(1, column_count + 1)):
        raise ValueError("Unexpected component index domain for rf01_count")

    flat = encoded["array"]
    if not isinstance(flat, list) or len(flat) != row_count * column_count:
        raise ValueError("Unexpected number of elements in rf01_count")
    values = [
        rf01_integer(value, "rf01_count.array[" + str(position) + "]")
        for position, value in enumerate(flat)
    ]

    restored = {}
    totals = [0] * column_count

    for row, (family, location) in enumerate(locations):
        for column, component in enumerate(RF01_COMPONENTS):
            value = values[row * column_count + column]
            name = (
                "local_" + family + "___" + str(location) + "_" + component
            )
            restored[name] = value
            totals[column] += value

    for column, component in enumerate(RF01_COMPONENTS):
        restored["global_" + component] = totals[column]

    restored["objective"] = (
        sum(values) + totals[0] + totals[1] + totals[3] + totals[4]
    )
    return {"variables": restored}


def rf01_main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=rf01_unique_object,
            parse_constant=rf01_reject_constant,
        )
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    result = rf01_map(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    rf01_main()