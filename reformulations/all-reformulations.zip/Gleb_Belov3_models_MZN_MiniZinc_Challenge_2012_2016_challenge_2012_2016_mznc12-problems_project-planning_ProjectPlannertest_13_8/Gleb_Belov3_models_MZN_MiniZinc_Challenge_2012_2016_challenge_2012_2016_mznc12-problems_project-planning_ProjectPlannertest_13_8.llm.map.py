import json
import math
import sys


BASES = (0, 19, 41, 64, 88, 113, 139, 166, 194, 223, 253, 284, 316)
DURATIONS = (3, 1, 2, 2, 1, 1, 2, 3, 4, 3, 1, 1, 4)
CALENDAR = tuple(range(17, 30))
CAPACITIES = (2, 4, 0, 1, 2, 0, 0, 2, 4, 0, 1, 2, 0)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError("Missing required field variables." + name)
    return variables[name]


def integer_value(variables, name):
    value = required(variables, name)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected integer in variables." + name)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected finite integer in variables." + name)
    return int(value)


def boolean_value(variables, name):
    value = required(variables, name)
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and value in (0, 1):
        return bool(value)
    raise ValueError("Expected Boolean or 0/1 in variables." + name)


def reconstruct(payload):
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing required object variables")
    variables = payload["variables"]

    days = [
        integer_value(variables, "chooseDay" + str(base))
        for base in BASES
    ]
    chosen = [
        boolean_value(variables, "chooseBool" + str(base + 1))
        for base in BASES
    ]

    calendar_index = {day: pos for pos, day in enumerate(CALENDAR)}
    for base, day in zip(BASES, days):
        if day not in calendar_index:
            raise ValueError(
                "variables.chooseDay" + str(base) + " is outside 17..29"
            )
    positions = [calendar_index[day] for day in days]

    result = {}

    def put(prefix, suffix, value):
        name = prefix + str(suffix)
        if name in result:
            raise ValueError("Duplicate reconstructed variable: " + name)
        result[name] = value

    for base, day, flag in zip(BASES, days, chosen):
        put("chooseDay", base, day)
        put("chooseBool", base + 1, flag)

    hours = [0] * len(CALENDAR)
    count = int(chosen[0])
    ranks = [0]

    put("ite", 2, count)
    put("index", 3, positions[0] + 1)

    if not chosen[0]:
        hours[positions[0]] = DURATIONS[0]

    for offset, value in enumerate(hours):
        put("hoursAssigned", 4 + offset, value)
    put("hoursAssigned", 17, hours[positions[0]])
    put("maxHours", 18, CAPACITIES[positions[0]])

    for task in range(1, len(BASES)):
        base = BASES[task]
        flag = chosen[task]

        new_rank = count if flag else task
        updated_ranks = [
            rank + int(flag and rank >= count)
            for rank in ranks
        ]

        put("ite", base + 2, new_rank)
        for offset, rank in enumerate(updated_ranks):
            put("ite", base + 3 + offset, rank)

        count += int(flag)
        put("ite", base + task + 3, count)
        ranks = updated_ranks + [new_rank]

        index_suffix = base + task + 4
        position = positions[task]
        put("index", index_suffix, position + 1)
        put("hoursAssigned", index_suffix + 1, hours[position])

        if not flag:
            hours[position] += DURATIONS[task]

        for offset, value in enumerate(hours):
            put("hoursAssigned", index_suffix + 2 + offset, value)

        put("hoursAssigned", index_suffix + 15, hours[position])
        put("maxHours", index_suffix + 16, CAPACITIES[position])

    day_number_tasks = (2, 0, 3, 1, 4, 8, 10, 12, 5, 9)
    for offset, task in enumerate(day_number_tasks):
        put("dayNumber", 349 + offset, positions[task] + 1)

    lookup_indices = []
    for target_rank in range(len(BASES)):
        lookup_value = len(BASES) + 1
        for offset, task in enumerate(range(len(BASES) - 2, -1, -1)):
            if ranks[task] == target_rank:
                lookup_value = task + 2
            put("ite", 359 + 12 * target_rank + offset, lookup_value)
        lookup_indices.append(lookup_value - 1)

    cost = 5 * len({day for day, flag in zip(days, chosen) if flag})
    for target_rank, lookup_index in enumerate(lookup_indices):
        index_suffix = 515 + 3 * target_rank
        duration = DURATIONS[lookup_index - 1]
        put("index", index_suffix, lookup_index)
        put("duration", index_suffix + 1, duration)
        if count > target_rank:
            cost += 2 * duration
        put("ite", index_suffix + 2, cost)

    expected_cost = (
        5 * len({day for day, flag in zip(days, chosen) if flag})
        + 2 * sum(
            duration for duration, flag in zip(DURATIONS, chosen) if flag
        )
    )
    if cost != expected_cost:
        raise ValueError("Reconstructed objective disagrees with reformulation")

    suffixes = set()
    for name in result:
        start = len(name)
        while start > 0 and name[start - 1].isdigit():
            start -= 1
        suffixes.add(int(name[start:]))

    if len(result) != 554 or suffixes != set(range(554)):
        raise ValueError("Incomplete reconstruction of original variables")

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    mapped = reconstruct(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(mapped, stream, allow_nan=False, sort_keys=True)
        stream.write("\n")


if __name__ == "__main__":
    main()