import json
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in payload:
        raise ValueError("Missing required input field: variables")

    source = payload["variables"]
    if not isinstance(source, dict):
        raise ValueError("The variables field must be a JSON object.")

    names = ("Items", "TransP", "TransN", "Trans_pos", "Trans_neg")
    restored = {}

    for name in names:
        if name not in source or source[name] is None:
            raise ValueError(
                "Missing required field variables."
                + name
                + "; its value must come from the reformulated model's "
                "default DZN solution."
            )
        restored[name] = source[name]

    result = json.dumps(
        {"variables": restored},
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    )
    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        handle.write(result)
        handle.write("\n")


if __name__ == "__main__":
    main()