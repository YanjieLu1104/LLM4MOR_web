import json
import math
import sys


WEIGHTS = (4, 1, 8, 8, 10, 1, 5, 3, 8, 6, 1)
BIN_IDS = (4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34)
CAPACITY = 20

CHOOSE_SUFFIXES = (
    588, 641, 694, 747, 800, 853, 906, 959, 1012, 1065, 1118
)
ITEM_SUFFIXES = (
    597, 650, 703, 756, 809, 862, 915, 968, 1021, 1074, 1127
)
BEFORE_SUFFIXES = (
    660, 713, 766, 819, 872, 925, 978, 1031, 1084, 1137
)
FINAL_SUFFIXES = (
    1192, 1252, 1312, 1372, 1432, 1492,
    1552, 1612, 1672, 1732, 1792
)
TOO_FULL_SUFFIXES = (
    1198, 1258, 1318, 1378, 1438, 1498,
    1558, 1618, 1678, 1738, 1798
)
EMPTY_SUFFIXES = (
    1213, 1273, 1333, 1393, 1453, 1513,
    1573, 1633, 1693, 1753, 1813
)
COUNTER_SUFFIXES = (
    1277, 1337, 1397, 1457, 1517, 1577,
    1637, 1697, 1757, 1817, 1825
)

ENTRY = (26, 32, 5, 11, 17, 23, 8, 21, 16, 31, 20)
PREDECESSOR = (1, 28, 34, 7, 13, 19, 29, 14, 30, 3, 10)
INCREMENT = (27, 33, 6, 12, 18, 24, 9, 22, 2, 4, 15)
EXIT = (28, 34, 7, 13, 19, 29, 14, 30, 3, 10, 25)


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def validate_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("JSON contains a non-finite number")
    if isinstance(value, list):
        for element in value:
            validate_finite(element)
    elif isinstance(value, dict):
        for element in value.values():
            validate_finite(element)


def require_integer(value, field):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(field + " must be an integer")
    return value


def decode_index_set(value, field):
    if not isinstance(value, dict):
        raise ValueError(field + " must be an encoded index set")

    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(field + ".range must contain two integers")
        lower = require_integer(bounds[0], field + ".range[0]")
        upper = require_integer(bounds[1], field + ".range[1]")
        return list(range(lower, upper + 1))

    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(field + ".set must be a list")
        decoded = [
            require_integer(element, field + ".set")
            for element in elements
        ]
        if len(set(decoded)) != len(decoded):
            raise ValueError(field + ".set contains duplicates")
        return sorted(decoded)

    raise ValueError(field + " must use range or set encoding")


def read_assignment(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required input field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be an object")

    field = "variables.rb11_assignment"
    if "rb11_assignment" not in variables:
        raise ValueError(
            "Missing required field: variables.rb11_assignment; "
            "it must come from the model's default DZN solution"
        )

    encoded = variables["rb11_assignment"]
    if not isinstance(encoded, dict):
        raise ValueError(field + " must use MiniZinc array encoding")
    if "array" not in encoded:
        raise ValueError("Missing required field: " + field + ".array")
    if "index_sets" not in encoded:
        raise ValueError("Missing required field: " + field + ".index_sets")

    index_sets = encoded["index_sets"]
    if not isinstance(index_sets, list) or len(index_sets) != 1:
        raise ValueError(field + " must be a one-dimensional array")

    expected_indices = list(range(1, len(WEIGHTS) + 1))
    actual_indices = decode_index_set(
        index_sets[0], field + ".index_sets[0]"
    )
    if actual_indices != expected_indices:
        raise ValueError(field + " has an incorrect index domain")

    elements = encoded["array"]
    if not isinstance(elements, list) or len(elements) != len(WEIGHTS):
        raise ValueError(field + " has an incorrect element count")

    assignment = []
    for position, element in enumerate(elements, start=1):
        bin_number = require_integer(
            element, field + "[" + str(position) + "]"
        )
        if not 1 <= bin_number <= len(BIN_IDS):
            raise ValueError(
                field + "[" + str(position) + "] is outside its domain"
            )
        assignment.append(bin_number)

    return assignment


def reconstruct(payload):
    assignment = read_assignment(payload)
    number_of_bins = len(BIN_IDS)

    loads = [0 for _ in BIN_IDS]
    last_item = [0 for _ in BIN_IDS]
    result = {}

    for position, (bin_number, weight) in enumerate(
        zip(assignment, WEIGHTS), start=1
    ):
        bin_offset = bin_number - 1
        object_id = BIN_IDS[bin_offset]

        result["chooseobj_" + str(CHOOSE_SUFFIXES[position - 1])] = object_id
        result["items_" + str(ITEM_SUFFIXES[position - 1])] = object_id + 1
        result["iitems_" + str(ITEM_SUFFIXES[position - 1])] = bin_number

        if position > 1:
            suffix = BEFORE_SUFFIXES[position - 2]
            result["spaceLeft_" + str(suffix)] = (
                CAPACITY - loads[bin_offset]
            )
            result["ispaceLeft_" + str(suffix)] = (
                number_of_bins + last_item[bin_offset]
                if last_item[bin_offset] != 0
                else bin_number
            )

        loads[bin_offset] += weight
        last_item[bin_offset] = position

    if any(load > CAPACITY for load in loads):
        raise ValueError(
            "variables.rb11_assignment violates the original bin capacities"
        )

    used = [load > 0 for load in loads]

    for bin_offset in range(number_of_bins):
        result["spaceLeft_" + str(FINAL_SUFFIXES[bin_offset])] = (
            CAPACITY - loads[bin_offset]
        )
        result["ispaceLeft_" + str(FINAL_SUFFIXES[bin_offset])] = (
            last_item[bin_offset] + 1
        )

        full_suffix = TOO_FULL_SUFFIXES[bin_offset]
        result["ret_tooFull_" + str(full_suffix)] = (
            loads[bin_offset] > CAPACITY
        )
        result["iret_tooFull_" + str(full_suffix)] = 1

        empty_suffix = EMPTY_SUFFIXES[bin_offset]
        result["ret_isEmpty_" + str(empty_suffix)] = not used[bin_offset]
        result["iret_isEmpty_" + str(empty_suffix)] = 1

    occupied_count = 0
    latest_occupied_bin = 0
    for bin_number, suffix in enumerate(COUNTER_SUFFIXES, start=1):
        if used[bin_number - 1]:
            occupied_count += 1
            latest_occupied_bin = bin_number

        result["numUsed_" + str(suffix)] = occupied_count
        result["inumUsed_" + str(suffix)] = latest_occupied_bin + 1

    result["objective"] = occupied_count
    result["iobjective"] = 1

    prev = [None] * 34
    prev[0] = 25

    for bin_offset in range(number_of_bins):
        entry = ENTRY[bin_offset]
        increment = INCREMENT[bin_offset]
        exit_node = EXIT[bin_offset]

        prev[entry - 1] = PREDECESSOR[bin_offset]
        prev[increment - 1] = entry if used[bin_offset] else increment
        prev[exit_node - 1] = increment if used[bin_offset] else entry

    if sorted(prev) != list(range(1, 35)):
        raise ValueError("Reconstructed prev is not a permutation")

    result["prev"] = {
        "array": prev,
        "index_sets": [{"range": [1, 34]}],
    }

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    validate_finite(payload)
    mapped = reconstruct(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, indent=2)
        destination.write("\n")


if __name__ == "__main__":
    main()