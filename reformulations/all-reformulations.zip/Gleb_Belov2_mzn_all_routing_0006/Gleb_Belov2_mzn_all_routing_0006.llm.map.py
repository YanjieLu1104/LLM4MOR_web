import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, list):
        for index, element in enumerate(value):
            validate_finite(element, path + "[" + str(index) + "]")
    elif isinstance(value, dict):
        for key, element in value.items():
            validate_finite(element, path + "." + key)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution."
        )
    return variables[name]


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    validate_finite(data, "input")

    if not isinstance(data, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object.")

    variables = data["variables"]
    result = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 108,
        "nXNd__1_1_Z": 115,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 62,
        "nXNd__1_10_Z": 113,
    }
    result.update(fixed_coordinates)

    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            result[name] = required_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        result[name] = required_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    elif "objective" in data and data["objective"] is not None:
        objective = data["objective"]
        if (
            isinstance(objective, bool)
            or not isinstance(objective, (int, float))
            or (isinstance(objective, float) and not objective.is_integer())
        ):
            raise ValueError("objective must be an integer-valued finite number.")
        result["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj and objective; one is required "
            "to restore the original objective variable."
        )

    validate_finite(result, "output.variables")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": result},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    main()