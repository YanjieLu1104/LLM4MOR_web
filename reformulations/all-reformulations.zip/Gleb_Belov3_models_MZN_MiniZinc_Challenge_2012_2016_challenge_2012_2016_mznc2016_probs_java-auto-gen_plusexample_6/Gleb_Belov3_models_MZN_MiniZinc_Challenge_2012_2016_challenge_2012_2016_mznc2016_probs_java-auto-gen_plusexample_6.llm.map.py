import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def require_integer(variables, name):
    if name not in variables:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; required source: reformulated default DZN solution"
        )
    value = variables[name]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected integer value for variables." + name)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected finite integer value for variables." + name)
    value = int(value)
    if not 0 <= value <= 5:
        raise ValueError("Value outside original domain for variables." + name)
    return value


def reconstruct(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    choice_ids = (
        239, 268, 297, 326, 355, 384, 413,
        442, 471, 500, 529, 558, 587,
    )
    choices = [
        require_integer(variables, "chooseint_" + str(identifier))
        for identifier in choice_ids
    ]

    restored = {}

    for position, identifier in enumerate(choice_ids):
        value = choices[position]
        restored["chooseint_" + str(identifier)] = value
        restored["unnamed_" + str(identifier + 3)] = value
        restored["iunnamed_" + str(identifier + 3)] = 1

        item_id = 2025 + 20 * position
        restored["i_" + str(item_id)] = value
        restored["ii_" + str(item_id)] = 1

    total_ids = (
        2044, 2064, 2084, 2104, 2124, 2144, 2164,
        2184, 2204, 2224, 2244, 2264, 2270,
    )
    running_total = 0
    for identifier, value in zip(total_ids, choices):
        running_total += value
        restored["total_" + str(identifier)] = running_total
        restored["itotal_" + str(identifier)] = 1

    restored["obj_max"] = running_total
    restored["iobjective"] = 1

    group_ids = (
        (647, 674, 701, 728, 755, 781),
        (818, 845, 872, 899, 926, 952),
        (989, 1016, 1043, 1070, 1097, 1123),
        (1160, 1187, 1214, 1241, 1268, 1294),
        (1331, 1358, 1385, 1412, 1439, 1465),
        (1502, 1529, 1556, 1583, 1610, 1636),
        (1673, 1700, 1727, 1754, 1781, 1807),
        (1844, 1871, 1898, 1925, 1952, 1978),
    )
    for start, identifiers in enumerate(group_ids):
        group_total = 0
        for offset, identifier in enumerate(identifiers):
            group_total += choices[start + offset]
            restored["grouptotal_" + str(identifier)] = group_total
            restored["igrouptotal_" + str(identifier)] = 1

    restored["prev"] = {
        "array": [2, 6, 1, 9, 3, 8, 5, 4, 7],
        "index_sets": [{"range": [1, 9]}],
    }

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    result = reconstruct(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, indent=2)
        destination.write("\n")


if __name__ == "__main__":
    main()