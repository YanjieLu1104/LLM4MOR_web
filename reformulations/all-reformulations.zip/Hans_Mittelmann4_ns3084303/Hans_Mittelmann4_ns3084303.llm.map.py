import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing field: variables")
    if not isinstance(payload["variables"], dict):
        raise ValueError("Field variables must be a JSON object")

    restored = {}
    present = set()

    for name, value in payload["variables"].items():
        base = name.split("[", 1)[0]
        if base not in {"x", "y", "f"}:
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Non-numeric variable value: " + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Non-finite variable value: " + name)
        restored[name] = value
        present.add(base)

    missing = {"x", "y", "f"} - present
    if missing:
        raise ValueError(
            "Missing original variable values: " + ", ".join(sorted(missing))
        )

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": restored}, stream, allow_nan=False)


if __name__ == "__main__":
    main()