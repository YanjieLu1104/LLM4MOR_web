import json
import math
import sys


SCALARS = (
    "poAct0",
    "poAct1",
    "poAct2",
    "poAct3",
    "poAct4",
    "poAct5",
    "piPort",
)

ARRAYS = (
    "piWeek",
    "reposType",
    "sosAct",
    "sos",
    "sosActSavings",
    "seAct",
    "seBfixed",
    "seBdur",
    "seDfixed",
    "seDdur",
    "seAfixed",
    "seAdur",
    "directCost",
    "sosActBCost",
    "sosActACost",
)

FIXED_ZERO_ARRAYS = frozenset((
    "sosAct",
    "sos",
    "sosActSavings",
    "sosActBCost",
    "sosActACost",
))

# The original main file fixes vv = 6 and VESSELS = 1..vv.
# These are embedded original data, not assumptions about external data.
VESSEL_INDICES = list(range(1, 7))


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected integer at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected finite integer at " + path)
    return int(value)


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected encoded index set at " + path)
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = integer(bounds[0], path + ".range[0]")
        upper = integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        decoded = [
            integer(item, path + ".set[" + str(i) + "]")
            for i, item in enumerate(elements)
        ]
        if len(decoded) != len(set(decoded)):
            raise ValueError("Duplicate index at " + path)
        return sorted(decoded)
    raise ValueError("Invalid index-set encoding at " + path)


def decode_array(value, name):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    dimensions = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError("Expected flat array at " + path + ".array")
    if not isinstance(dimensions, list) or len(dimensions) != 1:
        raise ValueError("Expected one index domain at " + path + ".index_sets")
    domain = decode_index_set(dimensions[0], path + ".index_sets[0]")
    if domain != VESSEL_INDICES:
        raise ValueError("Index domain must equal original VESSELS at " + path)
    if len(elements) != len(domain):
        raise ValueError("Array length does not match index domain at " + path)
    return [
        integer(item, path + ".array[" + str(i) + "]")
        for i, item in enumerate(elements)
    ]


def encode_array(elements):
    return {
        "array": list(elements),
        "index_sets": [{"range": [1, 6]}],
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=no_duplicate_keys,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(payload, "input")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing required object: variables")

    variables = payload["variables"]
    restored = {}

    for name in SCALARS:
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables." + name
                + " from default DZN solver output"
            )
        restored[name] = integer(variables[name], "variables." + name)

    decoded = {}
    for name in ARRAYS:
        if name in variables and variables[name] is not None:
            decoded[name] = decode_array(variables[name], name)

    for name in FIXED_ZERO_ARRAYS:
        if name not in decoded:
            # Positive SOS actions are infeasible in the original fixed table:
            # their after-sailing cost is -1, but sosActACost is nonnegative.
            # Both remaining repositioning types force these arrays to zero.
            decoded[name] = [0 for _ in VESSEL_INDICES]

    if "reposType" not in decoded and "seAct" in decoded:
        decoded["reposType"] = [1 + 2 * item for item in decoded["seAct"]]

    if "seAct" not in decoded and "reposType" in decoded:
        equipment = []
        for item in decoded["reposType"]:
            if item not in (1, 3):
                raise ValueError(
                    "Cannot reconstruct seAct: reposType must be 1 or 3"
                )
            equipment.append((item - 1) // 2)
        decoded["seAct"] = equipment

    if "seDfixed" not in decoded and "seAct" in decoded:
        # The unchanged original seDfixedArr has columns 0 and 771667.
        decoded["seDfixed"] = [771667 * item for item in decoded["seAct"]]

    for name in ARRAYS:
        if name not in decoded:
            raise ValueError(
                "Missing required field variables." + name
                + " from default DZN solver output"
            )
        restored[name] = encode_array(decoded[name])

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": restored},
            stream,
            allow_nan=False,
            separators=(",", ":"),
        )
        stream.write("\n")


if __name__ == "__main__":
    main()