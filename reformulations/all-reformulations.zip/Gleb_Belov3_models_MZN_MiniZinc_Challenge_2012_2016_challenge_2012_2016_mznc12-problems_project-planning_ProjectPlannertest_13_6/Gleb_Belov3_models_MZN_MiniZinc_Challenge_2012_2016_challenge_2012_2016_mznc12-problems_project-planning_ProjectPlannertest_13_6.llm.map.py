import json
import math
import sys


DURATIONS = (3, 1, 2, 2, 1, 1, 2, 3, 4, 3, 1, 1, 4)
CAPACITIES = (2, 4, 0, 1, 2, 0, 0, 2, 4, 0, 1, 2, 0)
CALENDAR = (17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29)
STAGE_BASES = (0, 19, 41, 64, 88, 113, 139, 166, 194, 223, 253, 284, 316)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("All JSON numbers must be finite")
    if isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def required(values, name):
    if name not in values:
        raise ValueError(
            "Missing field variables." + name +
            "; required from the reformulated model's default DZN solution"
        )
    return values[name]


def read_integer(values, name):
    value = required(values, name)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected integer in variables." + name)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected finite integer in variables." + name)
    return int(value)


def read_boolean(values, name):
    value = required(values, name)
    if not isinstance(value, bool):
        raise ValueError("Expected Boolean in variables." + name)
    return value


def reconstruct(document):
    if "variables" not in document:
        raise ValueError("Missing field variables")
    values = document["variables"]
    if not isinstance(values, dict):
        raise ValueError("Field variables must be an object")

    result = {}
    days = []
    outsourced = []

    for base in STAGE_BASES:
        day_name = "chooseDay" + str(base)
        bool_name = "chooseBool" + str(base + 1)
        day = read_integer(values, day_name)
        flag = read_boolean(values, bool_name)
        if day not in CALENDAR:
            raise ValueError(day_name + " is outside its original domain")
        days.append(CALENDAR.index(day))
        outsourced.append(flag)
        result[day_name] = day
        result[bool_name] = flag

    def put(prefix, number, value):
        name = prefix + str(number)
        if name in result:
            raise ValueError("Duplicate reconstructed variable: " + name)
        result[name] = value

    loads = [0] * len(CALENDAR)

    selected_count = int(outsourced[0])
    ranks = [0]
    put("ite", 2, selected_count)
    put("index", 3, days[0] + 1)

    if not outsourced[0]:
        loads[days[0]] += DURATIONS[0]
    for offset, load in enumerate(loads):
        put("hoursAssigned", 4 + offset, load)
    put("hoursAssigned", 17, loads[days[0]])
    put("maxHours", 18, CAPACITIES[days[0]])

    for task in range(1, len(DURATIONS)):
        base = STAGE_BASES[task]
        task_count = task + 1
        flag = outsourced[task]

        new_rank = selected_count if flag else task
        updated_ranks = [
            rank + int(flag and rank >= selected_count)
            for rank in ranks
        ]

        put("ite", base + 2, new_rank)
        for offset, rank in enumerate(updated_ranks):
            put("ite", base + 3 + offset, rank)

        selected_count += int(flag)
        put("ite", base + task_count + 2, selected_count)
        ranks = updated_ranks + [new_rank]

        put("index", base + task_count + 3, days[task] + 1)
        put("hoursAssigned", base + task_count + 4, loads[days[task]])

        if not flag:
            loads[days[task]] += DURATIONS[task]

        for offset, load in enumerate(loads):
            put("hoursAssigned", base + task_count + 5 + offset, load)

        put("hoursAssigned", base + task_count + 18, loads[days[task]])
        put("maxHours", base + task_count + 19, CAPACITIES[days[task]])

    day_number_tasks = (2, 0, 4, 1, 8, 12, 5, 9)
    for offset, task in enumerate(day_number_tasks):
        put("dayNumber", 349 + offset, days[task] + 1)

    outsourcing_days = {
        days[task]
        for task in range(len(DURATIONS))
        if outsourced[task]
    }
    running_cost = 5 * len(outsourcing_days)

    for target_rank in range(len(DURATIONS)):
        inverse_value = len(DURATIONS) + 1
        for offset, task in enumerate(range(len(DURATIONS) - 2, -1, -1)):
            if ranks[task] == target_rank:
                inverse_value = task + 2
            put("ite", 357 + 12 * target_rank + offset, inverse_value)

        lookup_index = inverse_value - 1
        duration = DURATIONS[lookup_index - 1]
        put("index", 513 + 3 * target_rank, lookup_index)
        put("duration", 514 + 3 * target_rank, duration)

        if selected_count > target_rank:
            running_cost += 2 * duration
        put("ite", 515 + 3 * target_rank, running_cost)

    direct_cost = (
        5 * len(outsourcing_days) +
        2 * sum(
            duration
            for duration, flag in zip(DURATIONS, outsourced)
            if flag
        )
    )
    if running_cost != direct_cost:
        raise ValueError("Inconsistent reconstruction of the original objective")

    if len(result) != 552:
        raise ValueError("Reconstruction did not produce all 552 original variables")

    suffixes = []
    for name in result:
        position = len(name)
        while position > 0 and name[position - 1].isdigit():
            position -= 1
        suffixes.append(int(name[position:]))
    if sorted(suffixes) != list(range(552)):
        raise ValueError("Original variable numbering is incomplete")

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(document)
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")

    mapped = reconstruct(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, sort_keys=True)
        destination.write("\n")


if __name__ == "__main__":
    main()