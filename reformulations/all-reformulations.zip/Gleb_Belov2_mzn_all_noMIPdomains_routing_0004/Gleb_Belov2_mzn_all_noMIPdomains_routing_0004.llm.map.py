import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the reformulated model's "
            "default DZN solution.".format(name)
        )
    return variables[name]


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in document:
        raise ValueError("Missing variables; required from the solver solution.")
    variables = document["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object.")

    # These values are the unchanged singleton domains in the
    # self-contained original model, not inferred solution values.
    fixed_coordinates = {
        "nXNd__1_1_X": 212,
        "nXNd__1_1_Y": 58,
        "nXNd__1_1_Z": 115,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 43,
        "nXNd__1_10_Z": 113,
    }

    restored = {}
    for node in range(1, 11):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = require_value(variables, name)

    # All six original independent arrays retain their names,
    # index domains, element order, and meanings.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        restored[name] = require_value(variables, name)

    # obj was declared independently in the original model.
    restored["obj"] = require_value(variables, "obj")

    check_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(document, "input")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)