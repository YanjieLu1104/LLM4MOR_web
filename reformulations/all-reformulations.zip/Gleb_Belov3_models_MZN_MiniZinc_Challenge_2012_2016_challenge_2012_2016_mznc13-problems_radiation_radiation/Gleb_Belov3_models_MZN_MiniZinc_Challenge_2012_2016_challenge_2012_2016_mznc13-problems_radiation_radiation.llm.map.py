import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, list):
        for item in value:
            check_finite(item)
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        data = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    if not isinstance(data["variables"], dict):
        raise ValueError("variables must be a JSON object")

    variables = data["variables"]
    restored = {}

    for name in ("Beamtime", "K", "N", "Q"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables."
                + name
                + "; expected the unchanged original decision variable "
                "from the default DZN solution"
            )
        restored[name] = variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": restored},
            stream,
            allow_nan=False,
            separators=(",", ":"),
        )
        stream.write("\n")


if __name__ == "__main__":
    main()