import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def require_integer(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(name + " must be an integer")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError(name + " must be a finite integer")
    return int(value)


def decode_index_set(value, name):
    if not isinstance(value, dict):
        raise ValueError(name + " must use the MiniZinc index-set encoding")
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(name + ": invalid range")
        lo = require_integer(bounds[0], name)
        hi = require_integer(bounds[1], name)
        return list(range(lo, hi + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(name + ": invalid set")
        elements = [require_integer(item, name) for item in elements]
        if len(elements) != len(set(elements)):
            raise ValueError(name + ": duplicate set elements")
        return sorted(elements)
    raise ValueError(name + ": invalid index-set encoding")


def copy_array(variables, name, rank):
    if name not in variables or variables[name] is None:
        raise ValueError("Missing variables." + name + " from default DZN output")
    value = variables[name]
    if not isinstance(value, dict):
        raise ValueError("variables." + name + " must be an encoded array")
    if "array" not in value or "index_sets" not in value:
        raise ValueError("variables." + name + " lacks array or index_sets")
    elements = value["array"]
    indices = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(indices, list):
        raise ValueError("Invalid array encoding for variables." + name)
    if len(indices) != rank:
        raise ValueError("Wrong rank for variables." + name)
    size = 1
    for dimension, index_set in enumerate(indices):
        size *= len(decode_index_set(
            index_set, "variables." + name + ".index_sets[" + str(dimension) + "]"
        ))
    if size != len(elements):
        raise ValueError("Element count mismatch for variables." + name)
    return {
        "array": [
            require_integer(item, "variables." + name)
            for item in elements
        ],
        "index_sets": indices,
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        data = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables")
    variables = data["variables"]

    # These singleton domains are fixed in the original self-contained model.
    fixed_coordinates = {
        "nXNd__1_1_X": 65,
        "nXNd__1_1_Y": 114,
        "nXNd__1_1_Z": 80,
        "nXNd__1_10_X": 64,
        "nXNd__1_10_Y": 41,
        "nXNd__1_10_Z": 5,
    }
    result = dict(fixed_coordinates)

    # These names enumerate the original independent coordinate declarations.
    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name not in variables or variables[name] is None:
                raise ValueError(
                    "Missing variables." + name + " from default DZN output"
                )
            result[name] = require_integer(variables[name], "variables." + name)

    for name, rank in (
        ("nXLeg1", 2),
        ("nXLeg2", 2),
        ("nLLeg", 2),
        ("nDirLeg", 1),
        ("fExistLeg", 1),
        ("fLastLeg", 1),
    ):
        result[name] = copy_array(variables, name, rank)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in data and data["objective"] is not None:
        result["obj"] = require_integer(data["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj from default DZN output and missing objective"
        )

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": result},
            stream,
            allow_nan=False,
            separators=(",", ":"),
        )
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as exc:
        print("Mapping error: " + str(exc), file=sys.stderr)
        sys.exit(1)