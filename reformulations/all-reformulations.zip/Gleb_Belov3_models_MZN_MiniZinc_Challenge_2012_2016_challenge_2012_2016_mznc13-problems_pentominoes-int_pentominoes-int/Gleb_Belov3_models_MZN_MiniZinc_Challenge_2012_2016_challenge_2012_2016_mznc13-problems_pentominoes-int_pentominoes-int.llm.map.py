import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite JSON number")
    if isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload)

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    if not isinstance(payload["variables"], dict):
        raise ValueError("variables must be a JSON object")
    if "board" not in payload["variables"]:
        raise ValueError(
            "Missing required field: variables.board "
            "(original board variable from default DZN solution output)"
        )

    board = payload["variables"]["board"]
    if not isinstance(board, dict):
        raise ValueError("variables.board must use the MiniZinc array encoding")
    if "array" not in board or "index_sets" not in board:
        raise ValueError(
            "variables.board requires both array and index_sets"
        )
    if not isinstance(board["array"], list):
        raise ValueError("variables.board.array must be a list")
    if not isinstance(board["index_sets"], list) or len(board["index_sets"]) != 1:
        raise ValueError("variables.board must have exactly one index set")
    if any(type(value) is not int for value in board["array"]):
        raise ValueError("variables.board.array must contain integer values")

    result = {
        "variables": {
            "board": {
                "array": board["array"],
                "index_sets": board["index_sets"],
            }
        }
    }

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()