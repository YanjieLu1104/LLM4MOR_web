import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            validate_finite(item, path + "[" + str(index) + "]")


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name +
            "; required from the reformulated model's default DZN solution"
        )
    return variables[name]


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = data["variables"]
    restored = {}

    fixed_endpoints = {
        "nXNd__1_1_X": 211,
        "nXNd__1_1_Y": 48,
        "nXNd__1_1_Z": 5,
        "nXNd__1_10_X": 210,
        "nXNd__1_10_Y": 77,
        "nXNd__1_10_Z": 45,
    }

    for name, fixed_value in fixed_endpoints.items():
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            restored[name] = required_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        restored[name] = required_variable(variables, name)

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    validate_finite(data, "input")
    result = map_solution(data)
    validate_finite(result, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()