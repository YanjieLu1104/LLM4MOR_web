import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("All JSON numbers must be finite")
    elif isinstance(value, list):
        for element in value:
            check_finite(element)
    elif isinstance(value, dict):
        for element in value.values():
            check_finite(element)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    if not isinstance(data["variables"], dict):
        raise ValueError("Field variables must be a JSON object")
    if "A" not in data["variables"]:
        raise ValueError(
            "Missing required field: variables.A; "
            "A must come from the reformulated model's default DZN solution"
        )

    value = data["variables"]["A"]
    if value is None:
        raise ValueError("Required field variables.A has no solution value")
    if not isinstance(value, dict):
        raise ValueError("variables.A must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "variables.A must contain array and index_sets"
        )
    if not isinstance(value["array"], list):
        raise ValueError("variables.A.array must be a JSON array")
    if (
        not isinstance(value["index_sets"], list)
        or len(value["index_sets"]) != 2
    ):
        raise ValueError("variables.A must retain its two index sets")

    result = {"variables": {"A": value}}
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)