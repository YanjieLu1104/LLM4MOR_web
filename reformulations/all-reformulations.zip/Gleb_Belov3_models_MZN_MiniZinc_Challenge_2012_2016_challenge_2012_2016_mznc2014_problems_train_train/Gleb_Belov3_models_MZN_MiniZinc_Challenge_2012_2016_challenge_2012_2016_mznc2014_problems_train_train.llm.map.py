import json
import math
import sys


ORIGINAL_VARIABLES = (
    "departure",
    "arrival",
    "sigmaLower",
    "sigmaUpper",
    "collect",
    "load",
    "dwell",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for position, element in enumerate(value):
            check_finite(element, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def index_cardinality(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError(path + " must be an encoded index set")

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(bound) is not int for bound in bounds)
        ):
            raise ValueError(path + ".range must contain two integers")
        return max(0, bounds[1] - bounds[0] + 1)

    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError(path + ".set must be a list")
        if any(type(element) is not int for element in elements):
            raise ValueError(path + ".set must contain integer indices")
        if len(set(elements)) != len(elements):
            raise ValueError(path + ".set contains duplicate indices")
        return len(elements)

    raise ValueError(path + " must contain exactly 'range' or 'set'")


def validate_array(value, path):
    if not isinstance(value, dict):
        raise ValueError(path + " must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(path + " requires 'array' and 'index_sets'")

    elements = value["array"]
    index_sets = value["index_sets"]

    if not isinstance(elements, list):
        raise ValueError(path + ".array must be a list")
    if not isinstance(index_sets, list) or len(index_sets) != 2:
        raise ValueError(path + ".index_sets must contain two dimensions")

    count = 1
    for dimension, encoded in enumerate(index_sets):
        count *= index_cardinality(
            encoded, "{}.index_sets[{}]".format(path, dimension)
        )

    if len(elements) != count:
        raise ValueError(path + " has an inconsistent array length")
    if any(type(element) is not int for element in elements):
        raise ValueError(path + ".array must contain integer values")


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data, "input")

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = data["variables"]
    restored = {}

    for name in ORIGINAL_VARIABLES:
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables."
                + name
                + "; expected the retained original array in the "
                + "reformulated solver's default DZN solution"
            )
        validate_array(variables[name], "variables." + name)
        restored[name] = variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)