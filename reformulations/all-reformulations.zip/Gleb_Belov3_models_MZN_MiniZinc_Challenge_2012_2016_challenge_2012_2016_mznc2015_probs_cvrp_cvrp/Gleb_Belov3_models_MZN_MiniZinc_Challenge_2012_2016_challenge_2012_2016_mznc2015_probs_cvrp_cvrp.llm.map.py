import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(data, "input")

    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    required = (
        "successor",
        "predecessor",
        "vehicle",
        "load",
        "arrivalTime",
        "objective",
    )

    restored = {}
    for name in required:
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables.{}; "
                "source must be the reformulated model's default DZN solution"
                .format(name)
            )
        restored[name] = variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(
            {"variables": restored},
            target,
            allow_nan=False,
            separators=(",", ":"),
        )
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)