import json
import math
import sys


ORIGINAL_VARIABLES = (
    "poAct0",
    "poAct1",
    "poAct2",
    "poAct3",
    "poAct4",
    "poAct5",
    "piPort",
    "piWeek",
    "reposType",
    "sosAct",
    "sos",
    "sosActSavings",
    "directCost",
    "sosActBCost",
    "sosActACost",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            check_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in document:
        raise ValueError(
            "Missing field 'variables'; required source is the default DZN solution."
        )

    variables = document["variables"]
    if not isinstance(variables, dict):
        raise ValueError("'variables' must be a JSON object.")

    missing = [
        name for name in ORIGINAL_VARIABLES
        if name not in variables or variables[name] is None
    ]
    if missing:
        raise ValueError(
            "Missing original decision-variable values from the default DZN "
            "solution: " + ", ".join("variables." + name for name in missing)
        )

    restored = {}
    for name in ORIGINAL_VARIABLES:
        value = variables[name]
        check_finite(value, "variables." + name)
        restored[name] = value

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(document, "input")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, ensure_ascii=False, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)