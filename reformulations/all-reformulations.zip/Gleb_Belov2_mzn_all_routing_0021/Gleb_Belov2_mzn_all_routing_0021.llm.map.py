import json
import math
import sys


SOURCE_NODE_PIPE = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
SOURCE_DIAM = [1]
SOURCE_LENGTH_COST = [6000]
SOURCE_BEND_COST = [60000]
SOURCE_SUPPORT_COST = 5000
SOURCE_OBJECTIVE_DIVISOR = 100
SOURCE_FIRST_ENDPOINT = (308, 25, 3)
SOURCE_LAST_ENDPOINT = (308, 47, 48)
SOURCE_FIRST_DIRECTION = 3
SOURCE_LAST_DIRECTION = 2
SOURCE_PREFERRED_BOXES = (
    ((0, 80, 0), (350, 65, 3), 0),
    ((0, 80, 15), (350, 65, 3), 0),
    ((0, 80, 30), (350, 65, 3), 0),
    ((0, 80, 45), (350, 65, 3), 0),
    ((0, 80, 60), (350, 65, 3), 0),
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def integer(value, field):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("Expected a finite integer for " + field)


def decode_set(value, field):
    if not isinstance(value, dict):
        raise ValueError("Invalid index-set encoding for " + field)
    if "range" in value:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range for " + field)
        lower = integer(bounds[0], field)
        upper = integer(bounds[1], field)
        return list(range(lower, upper + 1))
    if "set" in value:
        entries = value["set"]
        if not isinstance(entries, list):
            raise ValueError("Invalid set for " + field)
        result = [integer(entry, field) for entry in entries]
        if result != sorted(set(result)):
            raise ValueError("Unordered or duplicated indices for " + field)
        return result
    raise ValueError("Missing set or range in " + field)


def decode_array(value, field, expected_domains=None):
    if not isinstance(value, dict) or "array" not in value:
        raise ValueError("Expected MiniZinc array encoding for " + field)
    if "index_sets" not in value:
        raise ValueError("Missing index_sets for " + field)
    domains = [
        decode_set(index_set, field + ".index_sets")
        for index_set in value["index_sets"]
    ]
    if expected_domains is not None and domains != expected_domains:
        raise ValueError("Unexpected array indices for " + field)
    entries = value["array"]
    if not isinstance(entries, list):
        raise ValueError("Invalid array elements for " + field)
    size = 1
    for domain in domains:
        size *= len(domain)
    if len(entries) != size:
        raise ValueError("Array element count does not match indices for " + field)
    return [integer(entry, field) for entry in entries], domains


def original_vector(parameters, name, embedded):
    if name not in parameters:
        return list(embedded)
    if parameters[name] is None:
        raise ValueError("Missing value for parameters." + name)
    value = parameters[name]
    if isinstance(value, list):
        result = [integer(entry, "parameters." + name) for entry in value]
    else:
        result, domains = decode_array(value, "parameters." + name)
        if len(domains) != 1 or domains[0] != list(range(1, len(result) + 1)):
            raise ValueError("Unexpected original indices for parameters." + name)
    if result != list(embedded):
        raise ValueError("parameters." + name + " differs from the fixed original instance")
    return result


def original_scalar(parameters, name, embedded):
    if name not in parameters:
        return embedded
    result = integer(parameters[name], "parameters." + name)
    if result != embedded:
        raise ValueError("parameters." + name + " differs from the fixed original instance")
    return result


def encode_array(name, entries, domains, indices):
    if name in indices:
        encoded_domains = indices[name]
        actual_domains = [
            decode_set(value, "indices." + name) for value in encoded_domains
        ]
        if actual_domains != domains:
            raise ValueError("indices." + name + " disagrees with the original model")
    else:
        encoded_domains = []
        for domain in domains:
            if domain:
                if domain != list(range(domain[0], domain[-1] + 1)):
                    raise ValueError("Noncontiguous array domain for " + name)
                encoded_domains.append({"range": [domain[0], domain[-1]]})
            else:
                encoded_domains.append({"range": [1, 0]})
    return {"array": entries, "index_sets": encoded_domains}


def map_solution(document):
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing variables object")
    if "parameters" not in document or not isinstance(document["parameters"], dict):
        raise ValueError("Missing parameters object")

    variables = document["variables"]
    parameters = document["parameters"]
    indices = document["indices"] if "indices" in document else {}
    if not isinstance(indices, dict):
        raise ValueError("Invalid indices object")

    node_pipe = original_vector(parameters, "nNodePipe", SOURCE_NODE_PIPE)
    diameters = original_vector(parameters, "nDiam", SOURCE_DIAM)
    length_costs = original_vector(
        parameters, "nCostPipePerLenUnit", SOURCE_LENGTH_COST
    )
    bend_costs = original_vector(parameters, "nCostBend", SOURCE_BEND_COST)
    default_support = original_scalar(
        parameters, "nCostSupport0", SOURCE_SUPPORT_COST
    )
    divisor = original_scalar(
        parameters, "nOBJCOEFDIVISOR", SOURCE_OBJECTIVE_DIVISOR
    )

    node_count = len(node_pipe)
    axes = ("X", "Y", "Z")
    node_domain = list(range(1, node_count + 1))
    coord_domain = list(range(1, len(axes) + 1))

    coordinate_view = None
    if "nXNd" in variables and variables["nXNd"] is not None:
        coordinate_view, _ = decode_array(
            variables["nXNd"], "variables.nXNd", [node_domain, coord_domain]
        )
    elif "nXNd_1D" in variables and variables["nXNd_1D"] is not None:
        coordinate_view, _ = decode_array(
            variables["nXNd_1D"],
            "variables.nXNd_1D",
            [list(range(1, node_count * len(axes) + 1))],
        )

    result = {}
    coordinates = []
    pipe_local_counts = {}

    for node_offset, pipe in enumerate(node_pipe):
        if pipe not in pipe_local_counts:
            pipe_local_counts[pipe] = 0
        pipe_local_counts[pipe] += 1
        local_node = pipe_local_counts[pipe]
        point = []
        for axis_offset, axis in enumerate(axes):
            name = "nXNd__{}_{}_{}".format(pipe, local_node, axis)
            if name in variables and variables[name] is not None:
                value = integer(variables[name], "variables." + name)
            elif coordinate_view is not None:
                value = coordinate_view[node_offset * len(axes) + axis_offset]
            elif node_offset == 0:
                value = SOURCE_FIRST_ENDPOINT[axis_offset]
            elif node_offset == node_count - 1:
                value = SOURCE_LAST_ENDPOINT[axis_offset]
            elif (
                node_offset == 1
                and axis_offset != (SOURCE_FIRST_DIRECTION - 1) % len(axes)
            ):
                value = SOURCE_FIRST_ENDPOINT[axis_offset]
            elif (
                node_offset == node_count - 2
                and axis_offset != (SOURCE_LAST_DIRECTION - 1) % len(axes)
            ):
                value = SOURCE_LAST_ENDPOINT[axis_offset]
            else:
                raise ValueError(
                    "Missing variables.{}: required original coordinate; "
                    "neither variables.nXNd nor variables.nXNd_1D supplies it".format(name)
                )
            point.append(value)
            result[name] = value
        coordinates.append(point)

    lower = []
    upper = []
    lengths = []
    directions = []
    exists = []
    actual = []

    for offset, point in enumerate(coordinates):
        is_actual = (
            offset + 1 < node_count
            and node_pipe[offset + 1] == node_pipe[offset]
        )
        actual.append(is_actual)
        if not is_actual:
            lower.extend([0] * len(axes))
            upper.extend([0] * len(axes))
            lengths.extend([0] * len(axes))
            directions.append(0)
            exists.append(0)
            continue

        next_point = coordinates[offset + 1]
        radius = diameters[node_pipe[offset] - 1] // 2
        delta = [next_point[k] - point[k] for k in range(len(axes))]
        nonzero_axes = [k for k in range(len(axes)) if delta[k] != 0]

        lower.extend(
            min(point[k], next_point[k]) - radius for k in range(len(axes))
        )
        upper.extend(
            max(point[k], next_point[k]) + radius for k in range(len(axes))
        )
        lengths.extend(abs(component) for component in delta)
        exists.append(int(bool(nonzero_axes)))

        if not nonzero_axes:
            directions.append(0)
        elif len(nonzero_axes) == 1:
            k = nonzero_axes[0]
            directions.append(k + 1 if delta[k] > 0 else k + 1 + len(axes))
        elif "nDirLeg" in variables and variables["nDirLeg"] is not None:
            directions.append(0)
        else:
            raise ValueError(
                "Cannot reconstruct nDirLeg: node pair {} is not axis-aligned".format(
                    offset + 1
                )
            )

    last = []
    for offset in range(node_count):
        if not actual[offset]:
            last.append(0)
        elif offset + 1 < node_count and actual[offset + 1]:
            last.append(exists[offset] - exists[offset + 1])
        else:
            last.append(exists[offset])

    reconstructed = {
        "nXLeg1": (lower, [node_domain, coord_domain]),
        "nXLeg2": (upper, [node_domain, coord_domain]),
        "nLLeg": (lengths, [node_domain, coord_domain]),
        "nDirLeg": (directions, [node_domain]),
        "fExistLeg": (exists, [node_domain]),
        "fLastLeg": (last, [node_domain]),
    }

    restored_arrays = {}
    for name, (entries, domains) in reconstructed.items():
        if name in variables and variables[name] is not None:
            entries, _ = decode_array(variables[name], "variables." + name, domains)
        restored_arrays[name] = entries
        result[name] = encode_array(name, entries, domains, indices)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = integer(variables["obj"], "variables.obj")
    elif "objective" in document and document["objective"] is not None:
        result["obj"] = integer(document["objective"], "objective")
    else:
        objective = 0
        restored_lengths = restored_arrays["nLLeg"]
        restored_exists = restored_arrays["fExistLeg"]
        for offset, pipe in enumerate(node_pipe):
            if not actual[offset]:
                continue

            leg_length = sum(
                restored_lengths[offset * len(axes):(offset + 1) * len(axes)]
            )
            objective += (length_costs[pipe - 1] // divisor + 1) * leg_length

            is_first = offset == 0 or node_pipe[offset - 1] != pipe
            if is_first:
                continue

            active = restored_exists[offset]
            objective += (bend_costs[pipe - 1] // divisor + 1) * active

            radius = diameters[pipe - 1] // 2
            point = coordinates[offset]
            preferred_count = 0
            preferred_charge = 0
            for origin, size, cost in SOURCE_PREFERRED_BOXES:
                in_zone = all(
                    origin[k]
                    <= point[k] - (radius if k == len(axes) - 1 else 0)
                    <= origin[k] + size[k]
                    for k in range(len(axes))
                )
                if in_zone:
                    preferred_count += 1
                    preferred_charge += cost // divisor + 1

            support_charge = (
                (1 - preferred_count) * (default_support // divisor + 1)
                + preferred_charge
            )
            objective += active * support_charge

        result["obj"] = objective

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    mapped = map_solution(document)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()