import json
import math
import sys


ORIGINAL_VARIABLES = (
    "departure",
    "arrival",
    "sigmaLower",
    "sigmaUpper",
    "collect",
    "load",
    "dwell",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def index_size(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected encoded index set at " + path)

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(bound) is not int for bound in bounds)
        ):
            raise ValueError("Invalid integer range at " + path)
        lower, upper = bounds
        return max(0, upper - lower + 1)

    if set(encoded) == {"set"}:
        members = encoded["set"]
        if not isinstance(members, list):
            raise ValueError("Invalid set at " + path)
        if any(type(member) is not int for member in members):
            raise ValueError("Expected integer indices at " + path)
        if len(set(members)) != len(members):
            raise ValueError("Duplicate indices at " + path)
        return len(members)

    raise ValueError("Invalid index-set encoding at " + path)


def validate_array(name, value):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected encoded array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)

    elements = value["array"]
    domains = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError("Expected flattened array at " + path + ".array")
    if not isinstance(domains, list) or len(domains) != 2:
        raise ValueError("Expected two index sets at " + path + ".index_sets")

    expected = 1
    for dimension, domain in enumerate(domains):
        expected *= index_size(
            domain, "{}.index_sets[{}]".format(path, dimension)
        )
    if len(elements) != expected:
        raise ValueError("Array size does not match index sets at " + path)

    for position, element in enumerate(elements):
        if type(element) is not int:
            raise ValueError(
                "Expected integer at {}.array[{}]".format(path, position)
            )


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing variables from the solver solution")
    supplied = payload["variables"]
    if not isinstance(supplied, dict):
        raise ValueError("variables must be a JSON object")

    restored = {}
    for name in ORIGINAL_VARIABLES:
        if name not in supplied or supplied[name] is None:
            raise ValueError(
                "Missing variables.{}; required source: the reformulated "
                "solver's default DZN solution".format(name)
            )
        validate_array(name, supplied[name])
        restored[name] = supplied[name]

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)