import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be an object")

    for name, value in variables.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Non-numeric AMPL variable value: " + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Non-finite AMPL variable value: " + name)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump({"variables": variables}, destination, allow_nan=False)


if __name__ == "__main__":
    main()