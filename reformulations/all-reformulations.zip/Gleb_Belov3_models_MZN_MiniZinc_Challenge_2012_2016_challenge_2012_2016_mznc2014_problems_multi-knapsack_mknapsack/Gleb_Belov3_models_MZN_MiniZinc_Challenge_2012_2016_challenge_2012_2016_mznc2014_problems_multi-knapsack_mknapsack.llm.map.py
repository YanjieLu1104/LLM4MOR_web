import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, list):
        for element in value:
            check_finite(element)
    elif isinstance(value, dict):
        for element in value.values():
            check_finite(element)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    if not isinstance(data["variables"], dict):
        raise ValueError("Field variables must be a JSON object")
    if "x" not in data["variables"]:
        raise ValueError(
            "Missing required field: variables.x "
            "(the unchanged original decision array from default DZN output)"
        )

    x = data["variables"]["x"]
    if not isinstance(x, dict):
        raise ValueError("variables.x must use the MiniZinc array encoding")
    if "array" not in x or "index_sets" not in x:
        raise ValueError(
            "variables.x must contain array and index_sets"
        )
    if not isinstance(x["array"], list):
        raise ValueError("variables.x.array must be a list")
    if not isinstance(x["index_sets"], list) or len(x["index_sets"]) != 1:
        raise ValueError("variables.x must have exactly one index set")
    for value in x["array"]:
        if type(value) is not int or value not in (0, 1):
            raise ValueError("variables.x contains a non-binary integer value")

    result = {"variables": {"x": x}}

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()