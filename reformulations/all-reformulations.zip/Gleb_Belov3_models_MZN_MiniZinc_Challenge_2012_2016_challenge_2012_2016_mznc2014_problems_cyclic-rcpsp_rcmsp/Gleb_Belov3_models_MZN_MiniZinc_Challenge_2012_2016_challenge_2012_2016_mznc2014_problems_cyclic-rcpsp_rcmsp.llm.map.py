import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, list):
        for item in value:
            check_finite(item)
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)


def original_array(payload, name):
    variables = payload["variables"]
    parameters = payload["parameters"]

    if name in variables and variables[name] is not None:
        value = variables[name]
        source = "variables." + name
    elif name in parameters and parameters[name] is not None:
        value = parameters[name]
        source = "parameters." + name
    else:
        raise ValueError(
            "Missing original variable "
            + name
            + ": required from variables."
            + name
            + " in the default DZN solution, or parameters."
            + name
            + " if supplied as fixed original instance data"
        )

    if not isinstance(value, dict):
        raise ValueError(source + " must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(source + " requires array and index_sets")
    if not isinstance(value["array"], list):
        raise ValueError(source + ".array must be a list")
    if not isinstance(value["index_sets"], list):
        raise ValueError(source + ".index_sets must be a list")
    if len(value["index_sets"]) != 1:
        raise ValueError(source + " must be a one-dimensional array")
    if any(type(item) is not int for item in value["array"]):
        raise ValueError(source + ".array must contain integer values")

    return {
        "array": value["array"],
        "index_sets": value["index_sets"],
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload)

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    for field in ("variables", "parameters"):
        if field not in payload:
            raise ValueError("Missing input field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError(field + " must be a JSON object")

    result = {
        "variables": {
            "s": original_array(payload, "s"),
            "k": original_array(payload, "k"),
        }
    }

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(result, handle, allow_nan=False)
        handle.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)