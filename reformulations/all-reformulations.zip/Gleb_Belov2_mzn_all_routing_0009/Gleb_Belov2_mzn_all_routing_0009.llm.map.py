import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 309,
    "nXNd__1_1_Y": 106,
    "nXNd__1_1_Z": 80,
    "nXNd__1_10_X": 302,
    "nXNd__1_10_Y": 60,
    "nXNd__1_10_Z": 54,
}

REQUIRED_VARIABLES = (
    "nXNd__1_2_X",
    "nXNd__1_2_Y",
    "nXNd__1_2_Z",
    "nXNd__1_3_X",
    "nXNd__1_3_Y",
    "nXNd__1_3_Z",
    "nXNd__1_4_X",
    "nXNd__1_4_Y",
    "nXNd__1_4_Z",
    "nXNd__1_5_X",
    "nXNd__1_5_Y",
    "nXNd__1_5_Z",
    "nXNd__1_6_X",
    "nXNd__1_6_Y",
    "nXNd__1_6_Z",
    "nXNd__1_7_X",
    "nXNd__1_7_Y",
    "nXNd__1_7_Z",
    "nXNd__1_8_X",
    "nXNd__1_8_Y",
    "nXNd__1_8_Z",
    "nXNd__1_9_X",
    "nXNd__1_9_Y",
    "nXNd__1_9_Z",
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def map_solution(payload):
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = payload["variables"]
    restored = {}

    for name in REQUIRED_VARIABLES:
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables."
                + name
                + "; expected in the reformulated model's default DZN output"
            )
        restored[name] = variables[name]

    for name, fixed_value in FIXED_COORDINATES.items():
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in payload and payload["objective"] is not None:
        objective = payload["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be a finite integer-valued number")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing required field variables.obj or objective; "
            "the original obj equals the reformulated minimization objective"
        )

    check_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()