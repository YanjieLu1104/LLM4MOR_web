import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 210,
    "nXNd__1_1_Y": 83,
    "nXNd__1_1_Z": 52,
    "nXNd__1_10_X": 55,
    "nXNd__1_10_Y": 114,
    "nXNd__1_10_Z": 80,
}

ORIGINAL_ARRAY_VARIABLES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            validate_finite(item, path + "[" + str(index) + "]")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; expected in the reformulated model's default DZN solution."
        )
    return variables[name]


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid required field variables.")

    variables = document["variables"]
    restored = {}

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in FIXED_COORDINATES:
                restored[name] = FIXED_COORDINATES[name]
            else:
                restored[name] = require_variable(variables, name)

    for name in ORIGINAL_ARRAY_VARIABLES:
        restored[name] = require_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in document and document["objective"] is not None:
        objective = document["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("Field objective must be a finite integer-valued number.")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("Field objective must be a finite integer-valued number.")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing required field variables.obj and no non-null objective "
            "is available to reconstruct the original objective variable."
        )

    validate_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    validate_finite(document, "input")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)