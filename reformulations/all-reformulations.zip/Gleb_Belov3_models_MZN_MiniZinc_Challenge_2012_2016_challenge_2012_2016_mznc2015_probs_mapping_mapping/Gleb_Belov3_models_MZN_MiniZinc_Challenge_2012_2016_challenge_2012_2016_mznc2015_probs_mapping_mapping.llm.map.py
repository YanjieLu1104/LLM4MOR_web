import json
import math
import sys


ORIGINAL_VARIABLES = (
    "cpu_loads",
    "cost",
    "communication_cost",
    "objective",
    "flow_processor",
    "comm_full",
    "flow_from_processor",
    "cc",
    "inFlow",
    "outFlow",
    "commFlow",
    "flows",
    "actor_processor",
    "total_flow",
)


def reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + repr(key))
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def check_present(value, path):
    if value is None:
        raise ValueError("Missing solution value at " + path)
    if isinstance(value, list):
        for index, item in enumerate(value):
            check_present(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_present(item, path + "." + key)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=reject_duplicate_keys,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    check_finite(payload, "input")

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    missing = [name for name in ORIGINAL_VARIABLES if name not in variables]
    if missing:
        raise ValueError(
            "Missing original decision-variable values from the default "
            "DZN solution (variables): " + ", ".join(missing)
        )

    restored = {}
    for name in ORIGINAL_VARIABLES:
        value = variables[name]
        check_present(value, "variables." + name)
        restored[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)