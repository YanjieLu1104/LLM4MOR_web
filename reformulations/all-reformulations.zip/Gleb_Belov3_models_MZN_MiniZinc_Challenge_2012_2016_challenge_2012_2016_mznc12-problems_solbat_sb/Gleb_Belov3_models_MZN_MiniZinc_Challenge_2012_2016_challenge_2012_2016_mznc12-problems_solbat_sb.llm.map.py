import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            validate_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    validate_finite(data, "input")

    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    restored = {}
    for name, dimensions in (("board", 2), ("fill", 2), ("npiece", 1)):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables.{}; "
                "expected from the solver's default DZN solution".format(name)
            )
        value = variables[name]
        if not isinstance(value, dict):
            raise ValueError("variables.{} must be an encoded array".format(name))
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables.{} requires array and index_sets".format(name)
            )
        if not isinstance(value["array"], list):
            raise ValueError("variables.{}.array must be a list".format(name))
        if (
            not isinstance(value["index_sets"], list)
            or len(value["index_sets"]) != dimensions
        ):
            raise ValueError(
                "variables.{} must have {} index sets".format(name, dimensions)
            )
        restored[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(
            {"variables": restored},
            target,
            ensure_ascii=False,
            allow_nan=False,
        )
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)