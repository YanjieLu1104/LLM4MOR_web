import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required_variable(variables, name):
    if name not in variables:
        raise ValueError(
            "Missing variables.{}; required source is the reformulated "
            "model's default DZN solution output.".format(name)
        )
    value = variables[name]
    if value is None:
        raise ValueError("Absent solution value: variables." + name)
    return value


def check_array(value, name, boolean):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError(path + " must use the MiniZinc array encoding.")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(path + " requires array and index_sets fields.")
    if not isinstance(value["array"], list):
        raise ValueError(path + ".array must be a list.")
    if (
        not isinstance(value["index_sets"], list)
        or len(value["index_sets"]) != 1
    ):
        raise ValueError(path + " must have exactly one index set.")
    for index, item in enumerate(value["array"]):
        expected_type = bool if boolean else int
        if type(item) is not expected_type:
            raise ValueError(
                "{}.array[{}] must be {}.".format(
                    path, index, "Boolean" if boolean else "integer"
                )
            )


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload, "input")
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in payload:
        raise ValueError("Missing input field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Input field variables must be a JSON object.")

    restored = {
        name: required_variable(variables, name)
        for name in ("start", "dur", "b", "objective")
    }

    check_array(restored["start"], "start", False)
    check_array(restored["dur"], "dur", False)
    check_array(restored["b"], "b", True)
    if type(restored["objective"]) is not int:
        raise ValueError("variables.objective must be an integer.")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)