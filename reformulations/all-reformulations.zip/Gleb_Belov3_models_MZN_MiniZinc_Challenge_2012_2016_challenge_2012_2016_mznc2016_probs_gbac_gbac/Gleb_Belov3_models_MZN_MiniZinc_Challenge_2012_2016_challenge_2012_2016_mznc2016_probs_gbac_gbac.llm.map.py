import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            validate_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            validate_finite(element, path + "." + key)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    validate_finite(payload, "input")

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    restored = {}
    for name in ("period_of", "load_of", "delta", "objective"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables.{}; expected the retained "
                "original variable from default DZN solution output".format(name)
            )
        restored[name] = variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": restored},
            stream,
            ensure_ascii=False,
            allow_nan=False,
        )
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)