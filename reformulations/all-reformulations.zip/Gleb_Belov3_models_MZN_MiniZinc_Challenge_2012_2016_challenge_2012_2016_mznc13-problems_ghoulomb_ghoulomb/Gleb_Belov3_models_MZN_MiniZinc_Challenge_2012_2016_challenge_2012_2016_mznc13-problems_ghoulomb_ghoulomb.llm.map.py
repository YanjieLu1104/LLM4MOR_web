import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def validate_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, dict):
        for child in value.values():
            validate_finite(child)
    elif isinstance(value, list):
        for child in value:
            validate_finite(child)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        data = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    validate_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data:
        raise ValueError("Missing required input field: variables")

    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Input field variables must be a JSON object")

    restored = {}
    for name in ("mark1", "mark2", "mark3"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables."
                + name
                + "; expected the original mark array from default DZN output"
            )

        value = variables[name]
        if not isinstance(value, dict):
            raise ValueError("variables." + name + " must use array encoding")
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables." + name + " requires array and index_sets fields"
            )
        if not isinstance(value["array"], list):
            raise ValueError("variables." + name + ".array must be a list")
        if (
            not isinstance(value["index_sets"], list)
            or len(value["index_sets"]) != 1
        ):
            raise ValueError(
                "variables." + name + " must have exactly one index set"
            )
        if any(type(element) is not int for element in value["array"]):
            raise ValueError(
                "variables." + name + " must contain integer mark values"
            )

        restored[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": restored}, stream, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)