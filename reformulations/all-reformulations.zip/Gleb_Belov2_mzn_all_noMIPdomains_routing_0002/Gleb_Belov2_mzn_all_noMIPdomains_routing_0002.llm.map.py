import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + ": required from the reformulated model's default DZN solution"
        )
    return variables[name]


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected integer value at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected finite integer value at " + path)
    return int(value)


def index_values(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected encoded index set at " + path)

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))

    if set(encoded) == {"set"}:
        members = encoded["set"]
        if not isinstance(members, list):
            raise ValueError("Invalid set at " + path)
        result = [
            require_integer(item, path + ".set")
            for item in members
        ]
        if result != sorted(set(result)):
            raise ValueError("Index set must be sorted and unique at " + path)
        return result

    raise ValueError("Invalid index-set encoding at " + path)


def copy_integer_array(variables, name, expected_domains):
    value = require_value(variables, name)
    if not isinstance(value, dict):
        raise ValueError("Expected encoded array at variables." + name)
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "Missing array or index_sets in variables." + name
        )

    elements = value["array"]
    domains = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(domains, list):
        raise ValueError("Invalid encoded array at variables." + name)
    if len(domains) != len(expected_domains):
        raise ValueError("Wrong array dimension at variables." + name)

    count = 1
    for dimension, (domain, expected) in enumerate(
        zip(domains, expected_domains)
    ):
        actual = index_values(
            domain,
            "variables.{}.index_sets[{}]".format(name, dimension),
        )
        if actual != expected:
            raise ValueError(
                "Wrong index domain at variables.{}.index_sets[{}]".format(
                    name, dimension
                )
            )
        count *= len(actual)

    if len(elements) != count:
        raise ValueError("Wrong element count at variables." + name)

    return {
        "array": [
            require_integer(
                item, "variables.{}.array[{}]".format(name, position)
            )
            for position, item in enumerate(elements)
        ],
        "index_sets": domains,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = payload["variables"]
    restored = {}

    # These singleton domains and the ten-node dimension are embedded
    # unchanged in the original self-contained model.
    fixed_coordinates = {
        "nXNd__1_1_X": 309,
        "nXNd__1_1_Y": 54,
        "nXNd__1_1_Z": 101,
        "nXNd__1_10_X": 153,
        "nXNd__1_10_Y": 51,
        "nXNd__1_10_Z": 38,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                restored[name] = require_integer(
                    variables[name], "variables." + name
                )
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = require_integer(
                    require_value(variables, name), "variables." + name
                )

    node_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        restored[name] = copy_integer_array(
            variables, name, [node_domain, coordinate_domain]
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        restored[name] = copy_integer_array(
            variables, name, [node_domain]
        )

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        restored["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective: the original independent "
            "objective variable requires its emitted value or solution objective"
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(result, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    main()