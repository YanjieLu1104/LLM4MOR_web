import json
import math
import sys


DAY_SUFFIXES = (0, 18, 39, 61, 84, 108, 133, 159, 186, 214, 243, 273)
DURATIONS = (3, 1, 2, 2, 1, 1, 2, 3, 4, 3, 1, 1)
DATES = tuple(range(16, 28))
CAPACITIES = (2, 4, 0, 1, 2, 0, 0, 2, 4, 0, 1, 2)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("Non-finite JSON number: " + value)
    return result


def required(values, name):
    if name not in values:
        raise ValueError(
            "Missing field variables." + name +
            "; required from the reformulated model's default DZN solution"
        )
    return values[name]


def reconstruct(document):
    if "variables" not in document:
        raise ValueError("Missing field variables")
    values = document["variables"]
    if not isinstance(values, dict):
        raise ValueError("Field variables must be an object")

    result = {}
    days = []
    external = []

    for suffix in DAY_SUFFIXES:
        day_name = "chooseDay" + str(suffix)
        bool_name = "chooseBool" + str(suffix + 1)
        day = required(values, day_name)
        mode = required(values, bool_name)

        if type(day) is not int or day not in DATES:
            raise ValueError(
                "Field variables." + day_name +
                " must be an integer in 16..27"
            )
        if type(mode) is not bool:
            raise ValueError(
                "Field variables." + bool_name + " must be a Boolean"
            )

        days.append(day)
        external.append(mode)
        result[day_name] = day
        result[bool_name] = mode

    date_index = {day: position for position, day in enumerate(DATES)}
    loads = [0] * len(DATES)
    ranks = []
    external_count = 0

    for task, suffix in enumerate(DAY_SUFFIXES):
        position = date_index[days[task]]
        mode = external[task]

        if task == 0:
            external_count = int(mode)
            ranks = [0]
            result["ite2"] = external_count
            result["index3"] = position + 1

            if not mode:
                loads[position] += DURATIONS[task]

            for slot, load in enumerate(loads):
                result["hoursAssigned" + str(4 + slot)] = load

            result["hoursAssigned16"] = loads[position]
            result["maxHours17"] = CAPACITIES[position]
            continue

        previous_count = external_count
        new_rank = previous_count if mode else task
        updated_ranks = [
            rank + int(mode and rank >= previous_count)
            for rank in ranks
        ]

        result["ite" + str(suffix + 2)] = new_rank
        for previous_task, rank in enumerate(updated_ranks):
            result["ite" + str(suffix + 3 + previous_task)] = rank

        external_count += int(mode)
        count_suffix = suffix + task + 3
        index_suffix = count_suffix + 1
        result["ite" + str(count_suffix)] = external_count
        result["index" + str(index_suffix)] = position + 1

        result["hoursAssigned" + str(index_suffix + 1)] = loads[position]

        if not mode:
            loads[position] += DURATIONS[task]

        for slot, load in enumerate(loads):
            result["hoursAssigned" + str(index_suffix + 2 + slot)] = load

        result["hoursAssigned" + str(index_suffix + 14)] = loads[position]
        result["maxHours" + str(index_suffix + 15)] = CAPACITIES[position]

        ranks = updated_ranks + [new_rank]

    day_number_tasks = (3, 1, 5, 0, 9, 10, 8, 11, 2)
    for offset, task in enumerate(day_number_tasks):
        result["dayNumber" + str(304 + offset)] = date_index[days[task]] + 1

    external_dates = {
        day for day, mode in zip(days, external) if mode
    }
    accumulated_cost = 5 * len(external_dates)

    for rank_value in range(len(DURATIONS)):
        selected_label = len(DURATIONS) + 1

        for scan_offset, task in enumerate(
            range(len(DURATIONS) - 2, -1, -1)
        ):
            if ranks[task] == rank_value:
                selected_label = task + 2

            ite_suffix = (
                313 + (len(DURATIONS) - 1) * rank_value + scan_offset
            )
            result["ite" + str(ite_suffix)] = selected_label

        selected_index = selected_label - 1
        selected_duration = DURATIONS[selected_index - 1]
        result["index" + str(445 + 3 * rank_value)] = selected_index
        result["duration" + str(446 + 3 * rank_value)] = selected_duration

        if external_count > rank_value:
            accumulated_cost += 2 * selected_duration

        if rank_value < len(DURATIONS) - 1:
            result["ite" + str(447 + 3 * rank_value)] = accumulated_cost
        else:
            result["objective"] = accumulated_cost

    direct_cost = (
        5 * len(external_dates)
        + 2 * sum(
            duration
            for duration, mode in zip(DURATIONS, external)
            if mode
        )
    )
    if accumulated_cost != direct_cost:
        raise ValueError("Internal reconstruction error: objective mismatch")

    if "objective" in values:
        reported = values["objective"]
        if type(reported) not in (int, float):
            raise ValueError("Field variables.objective must be numeric")
        if reported != accumulated_cost:
            raise ValueError(
                "Field variables.objective disagrees with the reconstructed objective"
            )

    if "objective" in document and document["objective"] is not None:
        reported = document["objective"]
        if type(reported) not in (int, float):
            raise ValueError("Field objective must be numeric or null")
        if reported != accumulated_cost:
            raise ValueError(
                "Field objective disagrees with the reconstructed objective"
            )

    if len(result) != 481:
        raise ValueError("Internal reconstruction error: incomplete variable set")

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
            parse_float=finite_float,
        )

    if not isinstance(document, dict):
        raise ValueError("Input JSON must be an object")

    mapped = reconstruct(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, sort_keys=True)
        destination.write("\n")


if __name__ == "__main__":
    main()