import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name +
            "; required from the reformulated model's default DZN solution"
        )
    return variables[name]


def map_solution(data):
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object")
    variables = data["variables"]
    result = {}

    # These singleton-domain values are fixed in the original self-contained
    # model and may be omitted by the MiniZinc output machinery.
    fixed_coordinates = {
        "nXNd__1_1_X": 302,
        "nXNd__1_1_Y": 54,
        "nXNd__1_1_Z": 20,
        "nXNd__1_10_X": 282,
        "nXNd__1_10_Y": 54,
        "nXNd__1_10_Z": 8,
    }

    # All original independent coordinate variables remain in the model.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                result[name] = variables[name]
            elif name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                result[name] = required(variables, name)

    # Copy only original independent arrays, preserving their encoded
    # dimensions, index domains, and element order without modification.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        result[name] = required(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    elif "objective" in data and data["objective"] is not None:
        objective = data["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be finite and integer-valued")
        result["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj and objective; one is required to restore obj"
        )

    check_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(data, "input")
    output = map_solution(data)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(output, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()