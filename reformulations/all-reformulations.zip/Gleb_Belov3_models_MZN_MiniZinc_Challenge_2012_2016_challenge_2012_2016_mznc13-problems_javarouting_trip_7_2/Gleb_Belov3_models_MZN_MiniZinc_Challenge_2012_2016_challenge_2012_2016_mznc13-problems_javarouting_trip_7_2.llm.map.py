import json
import math
import sys


ORDER_SUFFIXES = (
    200, 234, 270, 308, 348, 390, 434,
    480, 528, 578, 630, 684, 740, 798,
)

LIST_SUFFIXES = (
    899, 1112, 2256, 2966, 3676, 4386, 5096,
    5806, 6516, 7226, 7936, 8646, 9356, 10066,
)

CHOSEN_SUFFIXES = (
    964, 1163, 2307, 3017, 3727, 4437, 5147,
    5857, 6567, 7277, 7987, 8697, 9407, 10117,
)

LOCATION_SUFFIXES = (
    966, 1165, 2309, 3019, 3729, 4439, 5149,
    5859, 6569, 7279, 7989, 8699, 9409, 10119,
)

MAP_SUFFIXES = (
    1048, 1182, 1645, 2326, 2355, 3036, 3065,
    3746, 3775, 4456, 4485, 5166, 5195, 5876,
    5905, 6586, 6615, 7296, 7325, 8006, 8035,
    8716, 8745, 9426, 9455, 10136, 10165, 10786,
    10815,
)

ARRIVAL_SUFFIXES = (
    11026, 11029, 11040, 11043, 11054, 11057, 11068,
    11071, 11082, 11085, 11096, 11099, 11110, 11113,
)

ORIGINAL_VARIABLES = (
    tuple("chooseOrder" + str(x) for x in ORDER_SUFFIXES)
    + tuple("listget" + str(x) for x in LIST_SUFFIXES)
    + tuple("chosenIndex" + str(x) for x in CHOSEN_SUFFIXES)
    + tuple("initialFieldValueslocationID" + str(x)
            for x in LOCATION_SUFFIXES)
    + tuple("mapget" + str(x) for x in MAP_SUFFIXES)
    + tuple("expectedArrivalTime" + str(x) for x in ARRIVAL_SUFFIXES)
    + tuple("expectedArrivalTimeX" + str(x) for x in range(14, 28))
    + tuple("listget" + str(x) + "X" for x in LIST_SUFFIXES)
    + tuple("mapget" + str(x) + "X" for x in MAP_SUFFIXES)
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Input contains a non-finite number")
    elif isinstance(value, dict):
        for child in value.values():
            check_finite(child)
    elif isinstance(value, list):
        for child in value:
            check_finite(child)


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document:
        raise ValueError("Missing required input field: variables")
    variables = document["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Input field variables must be a JSON object")

    missing = [name for name in ORIGINAL_VARIABLES if name not in variables]
    if missing:
        raise ValueError(
            "Missing required fields from default DZN solution variables: "
            + ", ".join(missing)
        )

    restored = {}
    for name in ORIGINAL_VARIABLES:
        value = variables[name]
        if type(value) is not int:
            raise ValueError(
                "Expected an integer scalar in solution field variables."
                + name
            )
        restored[name] = value

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(document)
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)