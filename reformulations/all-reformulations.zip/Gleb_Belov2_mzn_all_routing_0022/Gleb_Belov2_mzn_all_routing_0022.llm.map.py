import json
import math
import sys


FIXED_ENDPOINTS = {
    "nXNd__1_1_X": 315,
    "nXNd__1_1_Y": 54,
    "nXNd__1_1_Z": 73,
    "nXNd__1_10_X": 335,
    "nXNd__1_10_Y": 53,
    "nXNd__1_10_Z": 8,
}

COORDINATE_NAMES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
)

ARRAY_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from default DZN solution output".format(name)
        )
    return variables[name]


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = data["variables"]
    restored = {}

    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in FIXED_ENDPOINTS:
            restored[name] = FIXED_ENDPOINTS[name]
        else:
            restored[name] = required_variable(variables, name)

    for name in ARRAY_NAMES:
        restored[name] = required_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in data and data["objective"] is not None:
        objective = data["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(objective, float) and not math.isfinite(objective):
            raise ValueError("objective must be finite")
        if int(objective) != objective:
            raise ValueError("objective must be integer-valued")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj and objective: one is required to restore obj"
        )

    check_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data, "input")
    result = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    main()