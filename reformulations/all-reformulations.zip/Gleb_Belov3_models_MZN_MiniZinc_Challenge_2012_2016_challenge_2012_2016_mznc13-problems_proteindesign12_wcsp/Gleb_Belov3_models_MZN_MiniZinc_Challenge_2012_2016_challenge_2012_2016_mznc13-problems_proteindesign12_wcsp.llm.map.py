import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        data = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data, "input")

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid required field: variables")

    source = data["variables"]
    restored = {}

    for name in ("p", "ocosts1", "ocosts2", "objective"):
        if name not in source or source[name] is None:
            raise ValueError(
                "Missing required field: variables."
                + name
                + "; expected in the reformulated model's default DZN output"
            )
        restored[name] = source[name]

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(
            {"variables": restored},
            handle,
            ensure_ascii=False,
            allow_nan=False,
        )
        handle.write("\n")


if __name__ == "__main__":
    main()