import json
import math
import sys


SCALARS = (
    "poAct0", "poAct1", "poAct2", "poAct3", "poAct4", "piPort"
)

ARRAYS = (
    "piWeek", "reposType", "sosAct", "sos", "sosActSavings",
    "seAct", "seBfixed", "seBdur", "seDfixed", "seDdur",
    "seAfixed", "seAdur", "directCost", "sosActBCost", "sosActACost"
)

ZERO_ARRAYS = {
    "sosAct", "sos", "sosActSavings", "sosActBCost", "sosActACost"
}


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected integer at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected finite integer at " + path)
    return int(value)


def decode_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected encoded index set at " + path)
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = integer(bounds[0], path + ".range[0]")
        upper = integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        decoded = [integer(item, path + ".set") for item in elements]
        if len(set(decoded)) != len(decoded):
            raise ValueError("Duplicate index at " + path)
        return sorted(decoded)
    raise ValueError("Invalid encoded index set at " + path)


def array_value(value, name, expected):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected encoded array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    domains = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError("Expected flat element list at " + path + ".array")
    if not isinstance(domains, list) or len(domains) != 1:
        raise ValueError("Expected one index domain at " + path)
    if decode_set(domains[0], path + ".index_sets[0]") != expected:
        raise ValueError("Incorrect original index domain for " + name)
    if len(elements) != len(expected):
        raise ValueError("Incorrect element count for " + name)
    return {
        "array": [
            integer(item, path + ".array[" + str(position) + "]")
            for position, item in enumerate(elements)
        ],
        "index_sets": domains,
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        data = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(data, "input")
    if not isinstance(data, dict):
        raise ValueError("Expected input object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing required object: variables")
    if "parameters" not in data or not isinstance(data["parameters"], dict):
        raise ValueError("Missing required object: parameters")

    variables = data["variables"]
    parameters = data["parameters"]

    # The original main file assigns vv = 5 and VESSELS = 1..vv.
    # These are embedded original data, not external-instance defaults.
    vessel_count = 5
    if "vv" in parameters:
        supplied_count = integer(parameters["vv"], "parameters.vv")
        if supplied_count != vessel_count:
            raise ValueError("parameters.vv conflicts with original vv = 5")
    vessel_indices = list(range(1, vessel_count + 1))

    indices = data["indices"] if "indices" in data else {}
    if not isinstance(indices, dict):
        raise ValueError("Expected object: indices")

    def domains_for(name):
        if name in indices:
            domains = indices[name]
            if not isinstance(domains, list) or len(domains) != 1:
                raise ValueError("Expected one index domain in indices." + name)
            if decode_set(domains[0], "indices." + name) != vessel_indices:
                raise ValueError("Incorrect original index domain in indices." + name)
            return domains
        return [{"range": [1, vessel_count]}]

    result = {}

    for name in SCALARS:
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing variables." + name
                + "; required from the reformulated model's default DZN solution"
            )
        result[name] = integer(variables[name], "variables." + name)

    for name in ARRAYS:
        if name in variables and variables[name] is not None:
            result[name] = array_value(variables[name], name, vessel_indices)
            if name in ZERO_ARRAYS and any(result[name]["array"]):
                raise ValueError(
                    name + " must be zero under the original fixed SOS data"
                )
        elif name in ZERO_ARRAYS:
            # Every positive SOS activity has after-sailing cost -1,
            # while sosActACost is nonnegative. Consequently SOS is
            # impossible, and all five original SOS arrays are zero.
            result[name] = {
                "array": [0 for _ in vessel_indices],
                "index_sets": domains_for(name),
            }
        else:
            raise ValueError(
                "Missing variables." + name
                + "; required from the reformulated model's default DZN solution"
            )

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(
            {"variables": result},
            handle,
            allow_nan=False,
            separators=(",", ":"),
        )
        handle.write("\n")


if __name__ == "__main__":
    main()