import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload)

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required input field: variables")
    if not isinstance(payload["variables"], dict):
        raise ValueError("Input field variables must be a JSON object")

    original_variables = {}
    for name in ("f", "objective"):
        if name not in payload["variables"]:
            raise ValueError(
                "Missing required field variables."
                + name
                + "; expected the retained original variable "
                + "from the default DZN solution"
            )
        value = payload["variables"][name]
        if value is None:
            raise ValueError("Missing solution value: variables." + name)
        original_variables[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(
            {"variables": original_variables},
            target,
            allow_nan=False,
            ensure_ascii=False,
        )
        target.write("\n")


if __name__ == "__main__":
    main()