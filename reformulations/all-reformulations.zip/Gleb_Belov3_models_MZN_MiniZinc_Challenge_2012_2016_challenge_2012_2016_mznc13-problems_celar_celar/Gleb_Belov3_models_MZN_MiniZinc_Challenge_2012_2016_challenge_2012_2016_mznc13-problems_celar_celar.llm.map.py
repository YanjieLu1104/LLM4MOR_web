import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite numeric input")
    elif isinstance(value, list):
        for element in value:
            check_finite(element)
    elif isinstance(value, dict):
        for element in value.values():
            check_finite(element)


def recover_value(name, payload, variables, parameters):
    if name in variables and variables[name] is not None:
        return variables[name]

    if name in parameters and parameters[name] is not None:
        return parameters[name]

    if name == "objective":
        if "objective" in payload and payload["objective"] is not None:
            value = payload["objective"]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("The objective field must be a finite number")
            if isinstance(value, float) and not value.is_integer():
                raise ValueError("The original objective must be an integer")
            return int(value)

    if name == "objective":
        raise ValueError(
            "Missing objective: expected variables.objective, an original "
            "data binding in parameters.objective, or the solution objective field"
        )

    raise ValueError(
        "Missing " + name + ": expected variables." + name
        + " or an original data binding in parameters." + name
    )


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(payload)

    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")
    if "parameters" not in payload or not isinstance(payload["parameters"], dict):
        raise ValueError("Missing or invalid parameters object")

    variables = payload["variables"]
    parameters = payload["parameters"]

    restored = {
        name: recover_value(name, payload, variables, parameters)
        for name in ("f", "objective")
    }

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            ensure_ascii=False,
            allow_nan=False,
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)