import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 309,
    "nXNd__1_1_Y": 54,
    "nXNd__1_1_Z": 101,
    "nXNd__1_10_X": 153,
    "nXNd__1_10_Y": 51,
    "nXNd__1_10_Z": 38,
}

ARRAY_DIMENSIONS = {
    "nXLeg1": 2,
    "nXLeg2": 2,
    "nLLeg": 2,
    "nDirLeg": 1,
    "fExistLeg": 1,
    "fLastLeg": 1,
}


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def integer_value(value, field):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError(field + " must contain a finite integer")


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution"
        )
    return variables[name]


def decode_index_set(encoded, field):
    if not isinstance(encoded, dict):
        raise ValueError(field + " must use the MiniZinc set encoding")

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(field + ".range must contain two bounds")
        lower = integer_value(bounds[0], field + ".range[0]")
        upper = integer_value(bounds[1], field + ".range[1]")
        return list(range(lower, upper + 1))

    if set(encoded) == {"set"}:
        members = encoded["set"]
        if not isinstance(members, list):
            raise ValueError(field + ".set must be a list")
        result = [integer_value(value, field + ".set") for value in members]
        if result != sorted(set(result)):
            raise ValueError(field + " must have distinct increasing integer indices")
        return result

    raise ValueError(field + " must contain exactly 'range' or 'set'")


def mapped_array(variables, name, dimensions, context_indices):
    encoded = required_variable(variables, name)

    if not isinstance(encoded, dict):
        raise ValueError("variables." + name + " must use the MiniZinc array encoding")
    if "array" not in encoded or "index_sets" not in encoded:
        raise ValueError(
            "variables." + name + " requires both array and index_sets"
        )

    elements = encoded["array"]
    index_sets = encoded["index_sets"]

    if not isinstance(elements, list):
        raise ValueError("variables." + name + ".array must be a list")
    if not isinstance(index_sets, list) or len(index_sets) != dimensions:
        raise ValueError("Incorrect number of index sets for variables." + name)

    decoded = [
        decode_index_set(index_set, "variables." + name + ".index_sets")
        for index_set in index_sets
    ]
    expected_length = math.prod(len(index_set) for index_set in decoded)
    if len(elements) != expected_length:
        raise ValueError("Element count does not match index sets for variables." + name)

    if name in context_indices:
        original_sets = context_indices[name]
        if not isinstance(original_sets, list) or len(original_sets) != dimensions:
            raise ValueError("Invalid indices." + name)
        original_decoded = [
            decode_index_set(index_set, "indices." + name)
            for index_set in original_sets
        ]
        if decoded != original_decoded:
            raise ValueError("Index domains differ from the original for " + name)

    return {
        "array": [
            integer_value(value, "variables." + name + ".array")
            for value in elements
        ],
        "index_sets": index_sets,
    }


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = document["variables"]

    if "indices" in document:
        context_indices = document["indices"]
        if not isinstance(context_indices, dict):
            raise ValueError("indices must be an object")
    else:
        context_indices = {}

    result = dict(FIXED_COORDINATES)

    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            result[name] = integer_value(
                required_variable(variables, name),
                "variables." + name,
            )

    for name, dimensions in ARRAY_DIMENSIONS.items():
        result[name] = mapped_array(
            variables, name, dimensions, context_indices
        )

    if "objective" not in document or document["objective"] is None:
        raise ValueError(
            "Missing objective; the original obj variable requires the "
            "reformulated solution's shared objective field"
        )
    result["obj"] = integer_value(document["objective"], "objective")

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)