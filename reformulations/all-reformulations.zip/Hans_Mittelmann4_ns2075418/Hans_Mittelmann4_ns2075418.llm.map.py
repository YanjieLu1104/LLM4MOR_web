import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be an object")

    restored = {}
    for name, value in variables.items():
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise ValueError("Variable value must be numeric: " + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Variable value must be finite: " + name)

        if name.startswith("x[") or name.startswith("v["):
            restored[name] = value
        elif name.startswith("rf_start["):
            continue
        else:
            raise ValueError("Unexpected reformulated variable: " + name)

    if not any(name.startswith("x[") for name in restored):
        raise ValueError("Missing required original variable values: x")
    if not any(name.startswith("v[") for name in restored):
        raise ValueError("Missing required original variable values: v")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump({"variables": restored}, destination, allow_nan=False)


if __name__ == "__main__":
    main()