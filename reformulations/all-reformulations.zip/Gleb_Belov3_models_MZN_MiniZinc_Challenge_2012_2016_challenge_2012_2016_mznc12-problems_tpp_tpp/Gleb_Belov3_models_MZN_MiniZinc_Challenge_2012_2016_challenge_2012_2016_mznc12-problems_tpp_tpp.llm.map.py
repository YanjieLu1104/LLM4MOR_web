import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            check_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(data, "input")

    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    source_variables = data["variables"]
    restored = {}

    for name in ("succ", "travelCost", "purchaseLoc", "purchaseCost"):
        if name not in source_variables or source_variables[name] is None:
            raise ValueError(
                "Missing variables.{}: required from the solver's default "
                "DZN output for the retained original variable".format(name)
            )
        restored[name] = source_variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)