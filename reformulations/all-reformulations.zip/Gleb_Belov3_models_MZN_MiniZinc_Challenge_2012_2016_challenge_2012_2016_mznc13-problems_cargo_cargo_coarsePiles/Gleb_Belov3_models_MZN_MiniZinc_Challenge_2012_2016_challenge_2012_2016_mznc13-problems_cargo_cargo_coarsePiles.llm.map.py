import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("Expected an integer at " + path)


def check_array(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError("Expected a list at " + path + ".array")
    if not isinstance(index_sets, list) or len(index_sets) != 1:
        raise ValueError("Expected one index set at " + path + ".index_sets")
    domain = index_sets[0]
    if not isinstance(domain, dict):
        raise ValueError("Invalid index set at " + path)
    if set(domain) == {"range"}:
        bounds = domain["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid index range at " + path)
        require_integer(bounds[0], path + ".index_sets[0].range[0]")
        require_integer(bounds[1], path + ".index_sets[0].range[1]")
        size = max(0, bounds[1] - bounds[0] + 1)
    elif set(domain) == {"set"}:
        members = domain["set"]
        if not isinstance(members, list):
            raise ValueError("Invalid index set members at " + path)
        for index, member in enumerate(members):
            require_integer(member, "{}.index_sets[0].set[{}]".format(path, index))
        if len(set(members)) != len(members):
            raise ValueError("Duplicate index set members at " + path)
        size = len(members)
    else:
        raise ValueError("Unsupported index set encoding at " + path)
    if len(elements) != size:
        raise ValueError("Array length does not match its index set at " + path)
    for index, element in enumerate(elements):
        require_integer(element, "{}.array[{}]".format(path, index))


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        data = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data, "input")
    if not isinstance(data, dict):
        raise ValueError("Expected a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    source = data["variables"]
    array_names = ("tS__", "h__", "tR", "dT__")
    scalar_names = ("sum_delay", "objective")
    required_names = array_names + scalar_names
    missing = [
        name for name in required_names
        if name not in source or source[name] is None
    ]
    if missing:
        raise ValueError(
            "Missing original decision variables from the default DZN solution: "
            + ", ".join("variables." + name for name in missing)
        )

    result = {}
    for name in array_names:
        check_array(source[name], "variables." + name)
        result[name] = source[name]
    for name in scalar_names:
        require_integer(source[name], "variables." + name)
        result[name] = source[name]

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": result}, stream, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)