import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, child in value.items():
            check_finite(child, path + "." + key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            check_finite(child, path + "[" + str(index) + "]")


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(path + " must be an integer")


def validate_successors(value):
    if not isinstance(value, dict):
        raise ValueError("variables.succ must use the MiniZinc array encoding")

    if "array" not in value:
        raise ValueError("Missing variables.succ.array")
    if "index_sets" not in value:
        raise ValueError("Missing variables.succ.index_sets")

    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError("variables.succ.array must be a list")
    if not isinstance(index_sets, list) or len(index_sets) != 1:
        raise ValueError("variables.succ must have exactly one index set")

    domain = index_sets[0]
    if not isinstance(domain, dict):
        raise ValueError("Invalid variables.succ.index_sets[0]")

    if set(domain) == {"range"}:
        bounds = domain["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid successor index range")
        require_integer(bounds[0], "successor index lower bound")
        require_integer(bounds[1], "successor index upper bound")
        count = max(0, bounds[1] - bounds[0] + 1)
    elif set(domain) == {"set"}:
        members = domain["set"]
        if not isinstance(members, list):
            raise ValueError("Successor index set must contain a list")
        for member in members:
            require_integer(member, "successor index")
        if len(set(members)) != len(members):
            raise ValueError("Duplicate successor index")
        count = len(members)
    else:
        raise ValueError("Invalid successor index-set encoding")

    if len(elements) != count:
        raise ValueError("Successor element count does not match its index set")

    for index, element in enumerate(elements):
        require_integer(element, "variables.succ.array[" + str(index) + "]")


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data, "input")
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = data["variables"]
    restored = {}
    for name in ("succ", "fuel", "objective"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing variables."
                + name
                + "; required source is the reformulated model's "
                  "default DZN solution"
            )
        restored[name] = variables[name]

    validate_successors(restored["succ"])
    require_integer(restored["fuel"], "variables.fuel")
    require_integer(restored["objective"], "variables.objective")

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump({"variables": restored}, target, allow_nan=False)
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)