import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def require_integer(value, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(field + " must be an integer")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError(field + " must be a finite integer")
    return int(value)


def decode_index_set(value, field):
    if not isinstance(value, dict):
        raise ValueError(field + " must be an encoded index set")
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(field + ".range must contain two bounds")
        lower = require_integer(bounds[0], field + ".range[0]")
        upper = require_integer(bounds[1], field + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(field + ".set must be a list")
        indices = [
            require_integer(item, field + ".set")
            for item in elements
        ]
        if len(indices) != len(set(indices)):
            raise ValueError(field + " contains duplicate indices")
        return sorted(indices)
    raise ValueError(field + " must contain either range or set")


def copy_integer_array(value, field, expected_domains):
    if not isinstance(value, dict):
        raise ValueError(field + " must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(field + " requires array and index_sets")
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError(field + " has invalid array encoding")
    if len(index_sets) != len(expected_domains):
        raise ValueError(field + " has the wrong number of dimensions")
    size = 1
    for dimension, (encoded, expected) in enumerate(
        zip(index_sets, expected_domains)
    ):
        actual = decode_index_set(
            encoded, field + ".index_sets[" + str(dimension) + "]"
        )
        if actual != expected:
            raise ValueError(field + " has an incorrect index domain")
        size *= len(actual)
    if len(elements) != size:
        raise ValueError(field + " has an incorrect element count")
    return {
        "array": [
            require_integer(item, field + ".array[" + str(position) + "]")
            for position, item in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = payload["variables"]
    result = {}

    # These endpoint coordinates and dimensions are fixed in the original
    # self-contained main model, not obtained from an external instance.
    fixed_coordinates = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 86,
        "nXNd__1_1_Z": 100,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 62,
        "nXNd__1_10_Z": 58,
    }

    # These additional coordinate values follow from the original fixed
    # nozzle directions, axis-aligned legs, and zero-length trailing legs.
    implied_coordinates = {
        "nXNd__1_2_X": 245,
        "nXNd__1_2_Y": 86,
        "nXNd__1_9_X": 245,
        "nXNd__1_9_Z": 58,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                result[name] = require_integer(
                    variables[name], "variables." + name
                )
            elif name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            elif name in implied_coordinates:
                result[name] = implied_coordinates[name]
            else:
                raise ValueError(
                    "Missing field variables." + name
                    + "; required from the reformulated default DZN solution"
                )

    node_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))
    array_domains = {
        "nXLeg1": [node_domain, coordinate_domain],
        "nXLeg2": [node_domain, coordinate_domain],
        "nLLeg": [node_domain, coordinate_domain],
        "nDirLeg": [node_domain],
        "fExistLeg": [node_domain],
        "fLastLeg": [node_domain],
    }

    for name, domains in array_domains.items():
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing field variables." + name
                + "; required from the reformulated default DZN solution"
            )
        result[name] = copy_integer_array(
            variables[name], "variables." + name, domains
        )

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        result["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; one must provide "
            "the reformulated solution objective"
        )

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump({"variables": result}, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()