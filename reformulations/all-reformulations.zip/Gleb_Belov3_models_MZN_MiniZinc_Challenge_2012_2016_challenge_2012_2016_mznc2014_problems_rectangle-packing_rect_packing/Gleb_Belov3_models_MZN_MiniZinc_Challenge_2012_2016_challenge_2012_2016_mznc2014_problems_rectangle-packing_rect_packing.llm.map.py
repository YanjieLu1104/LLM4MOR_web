import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            check_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def require_integer(value, path):
    if type(value) is not int:
        raise ValueError("Expected an integer at " + path)


def check_coordinate_array(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)

    elements = value["array"]
    indices = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError("Expected a flattened array at " + path + ".array")
    if not isinstance(indices, list) or len(indices) != 1:
        raise ValueError("Expected one index set at " + path + ".index_sets")

    for index, element in enumerate(elements):
        require_integer(element, "{}.array[{}]".format(path, index))

    index_set = indices[0]
    if not isinstance(index_set, dict):
        raise ValueError("Invalid index-set encoding at " + path)

    if set(index_set) == {"range"}:
        bounds = index_set["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid index range at " + path)
        require_integer(bounds[0], path + ".index_sets[0].range[0]")
        require_integer(bounds[1], path + ".index_sets[0].range[1]")
        cardinality = max(0, bounds[1] - bounds[0] + 1)
    elif set(index_set) == {"set"}:
        members = index_set["set"]
        if not isinstance(members, list):
            raise ValueError("Invalid index set at " + path)
        for index, member in enumerate(members):
            require_integer(
                member, "{}.index_sets[0].set[{}]".format(path, index)
            )
        if len(set(members)) != len(members):
            raise ValueError("Duplicate index-set member at " + path)
        cardinality = len(members)
    else:
        raise ValueError("Invalid index-set encoding at " + path)

    if cardinality != len(elements):
        raise ValueError("Array size and index set disagree at " + path)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = payload["variables"]
    result = {}
    for name in ("X", "Y", "Width", "Height", "Area"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing variables.{}; required source is the "
                "reformulated model's default DZN solution".format(name)
            )
        value = variables[name]
        if name in ("X", "Y"):
            check_coordinate_array(value, "variables." + name)
        else:
            require_integer(value, "variables." + name)
        result[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump({"variables": result}, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)