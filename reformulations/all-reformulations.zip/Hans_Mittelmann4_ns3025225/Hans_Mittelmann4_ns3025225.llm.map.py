import json
import math
import sys
from fractions import Fraction


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def finite_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(name + " must be a finite number")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(name + " must be a finite number")
    return value


def required_number(container, name, prefix):
    if name not in container:
        raise ValueError("Missing required field: " + prefix + name)
    return finite_number(container[name], prefix + name)


def rational_parameter(parameters, name):
    value = required_number(parameters, name, "parameters.")
    return Fraction(str(value))


def positive_integer_parameter(parameters, name):
    value = rational_parameter(parameters, name)
    if value.denominator != 1 or value <= 0:
        raise ValueError("parameters." + name + " must be a positive integer")
    return int(value)


def ceil_fraction(value):
    return -((-value.numerator) // value.denominator)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    for field in ("variables", "parameters"):
        if field not in payload:
            raise ValueError("Missing required field: " + field)
        if not isinstance(payload[field], dict):
            raise ValueError(field + " must be a JSON object")

    variables = payload["variables"]
    parameters = payload["parameters"]

    width = positive_integer_parameter(parameters, "width")
    height = positive_integer_parameter(parameters, "height")
    blocks = positive_integer_parameter(parameters, "blocks")
    levels = positive_integer_parameter(parameters, "levels")
    separation = rational_parameter(parameters, "separation")
    objective_bound = rational_parameter(parameters, "objectiveBound")

    restored = {
        "maximumWireLength": required_number(
            variables, "maximumWireLength", "variables."
        )
    }

    for i in range(1, levels + 1):
        required_top = ceil_fraction(Fraction(i * blocks, width))
        if required_top > (i - 1) * separation:
            low_row = max(Fraction(1), required_top - separation)
        else:
            low_row = Fraction(1)

        for j in range(1, blocks + 1):
            origin = Fraction(width * j, blocks + 1)

            for m in range(1, height + 1):
                row_allowed = low_row <= m <= i * separation

                for n in range(1, width + 1):
                    key = "placement[{},{},{},{}]".format(i, j, m, n)
                    column_allowed = (
                        origin - (Fraction(n) - Fraction(1, 2))
                        <= objective_bound
                    )

                    if row_allowed and column_allowed:
                        restored[key] = required_number(
                            variables, key, "variables."
                        )
                    else:
                        restored[key] = 0

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            {"variables": restored},
            stream,
            allow_nan=False,
            separators=(",", ":"),
        )


if __name__ == "__main__":
    main()