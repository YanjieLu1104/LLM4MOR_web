import json
import math
import sys


VALUES = [40,43,46,49,52,55,58,61,64,67,70,73,76,79]
DEPOT = [14,11,18,5,1,14,6,3,6,20,17,1,8,5]
ROW_KEYS = [22,25,26,27,29,30,31,32,33,34,35,36,37,38]
TRAVEL = [
    [0,18,10,13,15,11,15,14,18,17,7,8,12,16],
    [18,0,1,18,10,7,6,17,9,7,11,1,1,6],
    [10,1,0,6,5,1,13,2,15,8,3,3,6,16],
    [13,18,6,0,19,6,8,7,17,9,19,8,3,10],
    [15,10,5,19,0,16,7,1,9,4,20,17,5,18],
    [11,7,1,6,16,0,4,2,20,17,6,3,17,20],
    [15,6,13,8,7,4,0,13,10,1,15,14,19,2],
    [14,17,2,7,1,2,13,0,11,7,1,6,16,7],
    [18,9,15,17,9,20,10,11,0,12,13,1,3,5],
    [17,7,8,9,4,17,1,7,12,0,4,5,10,6],
    [7,11,3,19,20,6,15,1,13,4,0,1,14,1],
    [8,1,3,8,17,3,14,6,1,5,1,0,16,3],
    [12,1,6,3,5,17,19,16,3,10,14,16,0,16],
    [16,6,16,10,18,20,2,7,5,6,1,3,16,0],
]


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def decode_index(encoded, field):
    if not isinstance(encoded, dict):
        raise ValueError(field + " must be a encoded index set")
    if "range" in encoded:
        bounds = encoded["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(v) is not int for v in bounds)
        ):
            raise ValueError("Invalid range in " + field)
        return list(range(bounds[0], bounds[1] + 1))
    if "set" in encoded:
        elements = encoded["set"]
        if (
            not isinstance(elements, list)
            or any(type(v) is not int for v in elements)
            or len(set(elements)) != len(elements)
        ):
            raise ValueError("Invalid set in " + field)
        return sorted(elements)
    raise ValueError("Missing range or set in " + field)


def binary_value(value):
    if isinstance(value, bool):
        return int(value)
    if not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError("rf7_arc contains a non-finite or non-numeric value")
    if abs(value) <= 1e-6:
        return 0
    if abs(value - 1) <= 1e-6:
        return 1
    raise ValueError("rf7_arc contains a nonbinary value")


def encoded_array(elements):
    return {
        "array": elements,
        "index_sets": [{"range": [1, len(elements)]}],
    }


def reconstruct(document):
    if "variables" not in document:
        raise ValueError("Missing required field: variables")
    variables = document["variables"]
    if "rf7_arc" not in variables:
        raise ValueError(
            "Missing required field: variables.rf7_arc "
            "(required from default DZN solver output)"
        )
    encoded = variables["rf7_arc"]
    if not isinstance(encoded, dict) or "array" not in encoded:
        raise ValueError("variables.rf7_arc must use the MiniZinc array encoding")
    if "index_sets" not in encoded or len(encoded["index_sets"]) != 2:
        raise ValueError("Missing two index sets for variables.rf7_arc")
    n = len(VALUES)
    expected_nodes = list(range(n + 1))
    for dimension, index in enumerate(encoded["index_sets"]):
        if decode_index(index, "rf7_arc.index_sets[" + str(dimension) + "]") != expected_nodes:
            raise ValueError("Unexpected index domain for variables.rf7_arc")
    flat = encoded["array"]
    if not isinstance(flat, list) or len(flat) != (n + 1) ** 2:
        raise ValueError("Unexpected element count for variables.rf7_arc")
    bits = [binary_value(v) for v in flat]
    arcs = [bits[i * (n + 1):(i + 1) * (n + 1)] for i in expected_nodes]
    if any(sum(row) != 1 for row in arcs):
        raise ValueError("rf7_arc must have exactly one outgoing arc per node")
    if any(sum(arcs[i][j] for i in expected_nodes) != 1 for j in expected_nodes):
        raise ValueError("rf7_arc must have exactly one incoming arc per node")
    successor = [row.index(1) for row in arcs]

    route = []
    visited = {0}
    node = successor[0]
    while node != 0:
        if node in visited:
            raise ValueError("rf7_arc contains a disconnected cycle")
        visited.add(node)
        route.append(node)
        node = successor[node]
    if len(route) != n:
        raise ValueError("rf7_arc is not a tour through all customers")

    positions = {node: k + 1 for k, node in enumerate(route)}
    if any(positions[pickup] >= positions[pickup + 1]
           for pickup in range(1, n + 1, 2)):
        raise ValueError("rf7_arc violates pickup-before-delivery precedence")

    legs = [DEPOT[route[0] - 1]]
    legs.extend(TRAVEL[a - 1][b - 1] for a, b in zip(route, route[1:]))
    times = []
    total = 0
    for leg in legs:
        total += leg
        times.append(total)
    finish = total + DEPOT[route[-1] - 1]

    result = {
        "chooseOrderIndex_2": encoded_array(route),
        "chooseOrderVal_2": encoded_array([VALUES[node - 1] for node in route]),
        "prev": encoded_array([8,7,1,6,3,2,5,4]),
        "objective": finish,
        "iobjective": 1,
    }

    def assign(name, value, lookup=None):
        if name in result:
            raise ValueError("Duplicate reconstructed variable: " + name)
        result[name] = value
        if lookup is not None:
            index_name = "i" + name
            if index_name in result:
                raise ValueError("Duplicate reconstructed variable: " + index_name)
            result[index_name] = lookup

    for k, customer in enumerate(route):
        offset = 65 * k
        stop = VALUES[customer - 1]
        assign("listget_" + str(1126 + offset), stop)
        assign("stop_" + str(1138 + offset), stop, 1)
        assign("locationID_" + str(1144 + offset), customer, customer)
        assign("ret_getLocation_" + str(1148 + offset), customer, 1)
        assign("nextLocation_" + str(1155 + offset), customer, 1)
        assign("location2_" + str(1167 + offset), customer, 1)
        assign("unnamed_" + str(1170 + offset), customer, 1)

        if k == 0:
            lookup_index = customer
        else:
            previous = route[k - 1]
            lookup_index = n * (previous - 1) + customer
            assign("currentTime_" + str(1151 + offset), times[k - 1], 1)
            assign("currentLocation_" + str(1152 + offset), previous, 1)
            assign("location1_" + str(1162 + offset), previous, 1)
            assign("unnamed_" + str(1165 + offset), previous, 1)
            assign("mapget_" + str(1166 + offset),
                   ROW_KEYS[previous - 1], previous)

        assign("mapget_" + str(1171 + offset), legs[k], lookup_index)
        assign("ret_travelTime_" + str(1175 + offset), legs[k], 1)
        assign("nextLocation_" + str(1178 + offset), customer, 1)
        assign("stop_" + str(1180 + offset), stop, 1)
        assign("currentTime_" + str(1183 + offset), times[k], 1)

    last = route[-1]
    assign("currentTime_2032", times[-1], 1)
    assign("currentLocation_2033", last, 1)
    assign("location1_2043", last, 1)
    assign("unnamed_2046", last, 1)
    assign("mapget_2047", ROW_KEYS[last - 1], last)
    assign("mapget_2052", DEPOT[last - 1], last)
    assign("ret_travelTime_2056", DEPOT[last - 1], 1)
    assign("tripFinishTime_2322", finish, 1)

    for pair in range(n // 2):
        pickup = 2 * pair + 1
        delivery = pickup + 1
        pickup_position = positions[pickup]
        delivery_position = positions[delivery]
        assign(
            "expectedArrivalTime_" + str(2092 + 36 * pair),
            times[pickup_position - 1],
            pickup_position + 1,
        )
        assign(
            "expectedArrivalTime_" + str(2099 + 36 * pair),
            times[delivery_position - 1],
            delivery_position + 1,
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    result = reconstruct(document)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()