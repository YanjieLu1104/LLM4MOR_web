import json
import sys
from collections import Counter


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def require_int(value, name):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(name + " must be an integer")
    return value


def decode_index_set(value, name):
    if not isinstance(value, dict):
        raise ValueError(name + " must use the MiniZinc index-set encoding")
    if "range" in value:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range in " + name)
        lower = require_int(bounds[0], name)
        upper = require_int(bounds[1], name)
        return list(range(lower, upper + 1))
    if "set" in value:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set in " + name)
        for element in elements:
            require_int(element, name)
        if len(set(elements)) != len(elements):
            raise ValueError("Duplicate index in " + name)
        return sorted(elements)
    raise ValueError("Missing range or set in " + name)


def decode_array(value, name):
    if not isinstance(value, dict):
        raise ValueError(name + " must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets in " + name)
    elements = value["array"]
    domains = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError(name + ".array must be a list")
    if not isinstance(domains, list) or len(domains) != 1:
        raise ValueError(name + " must be one-dimensional")
    indices = decode_index_set(domains[0], name + ".index_sets[0]")
    if len(indices) != len(elements):
        raise ValueError("Index and element counts disagree for " + name)
    return dict(zip(indices, elements))


def encode_array(elements, upper):
    return {
        "array": elements,
        "index_sets": [{"range": [1, upper]}],
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if "variables" not in payload:
        raise ValueError("Missing variables from reformulated solver output")
    if "parameters" not in payload:
        raise ValueError("Missing parameters from original instance")

    variables = payload["variables"]
    parameters = payload["parameters"]
    if not isinstance(variables, dict) or not isinstance(parameters, dict):
        raise ValueError("variables and parameters must be objects")

    def supplied(name):
        if name in variables and variables[name] is not None:
            return variables[name]
        if name in parameters and parameters[name] is not None:
            return parameters[name]
        return None

    how = supplied("how")
    if how is None:
        if "n" not in parameters:
            raise ValueError(
                "Missing variables.how and original parameters.n"
            )
        n = require_int(parameters["n"], "parameters.n")
        if n > 0:
            raise ValueError(
                "Missing how: required from solver variables "
                "or its original data binding in parameters"
            )
        how = encode_array([], n)

    how_entries = decode_array(how, "how")
    for value in how_entries.values():
        require_int(value, "how element")

    used = supplied("used")
    if used is None:
        if "m" not in parameters:
            raise ValueError(
                "Missing variables.used and original parameters.m"
            )
        m = require_int(parameters["m"], "parameters.m")
        if m <= 0:
            used = encode_array([], m)
        else:
            if "buy" not in parameters or parameters["buy"] is None:
                raise ValueError(
                    "Missing original parameters.buy, needed to reconstruct used"
                )
            buy_entries = decode_array(parameters["buy"], "parameters.buy")
            expected = list(range(1, m + 1))
            if sorted(buy_entries) != expected:
                raise ValueError("parameters.buy must have index domain 1..m")
            counts = Counter(how_entries.values())
            used_values = []
            for voucher in expected:
                threshold = require_int(
                    buy_entries[voucher], "parameters.buy element"
                )
                used_values.append(counts[-voucher] >= threshold)
            used = encode_array(used_values, m)

    used_entries = decode_array(used, "used")
    if any(not isinstance(value, bool) for value in used_entries.values()):
        raise ValueError("used elements must be Booleans")

    result = {"variables": {"how": how, "used": used}}
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()