import json
import math
import sys


ORIGINAL_VARIABLES = (
    "cpu_loads",
    "cost",
    "communication_cost",
    "objective",
    "flow_processor",
    "comm_full",
    "flow_from_processor",
    "cc",
    "inFlow",
    "outFlow",
    "commFlow",
    "flows",
    "actor_processor",
    "total_flow",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_value(value, path):
    if value is None:
        raise ValueError("Missing value at " + path)
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, list):
        for position, item in enumerate(value):
            validate_value(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_value(item, path + "." + key)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")
    if "parameters" not in data or not isinstance(data["parameters"], dict):
        raise ValueError("Missing or invalid input field: parameters")

    variables = data["variables"]
    parameters = data["parameters"]
    restored = {}

    for name in ORIGINAL_VARIABLES:
        if name in variables and variables[name] is not None:
            value = variables[name]
        elif name in parameters and parameters[name] is not None:
            value = parameters[name]
        else:
            raise ValueError(
                "Missing original variable {!r}: required from default DZN "
                "solution field variables.{}, or from parameters.{} if "
                "bound by the original instance data".format(name, name, name)
            )
        validate_value(value, name)
        restored[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)