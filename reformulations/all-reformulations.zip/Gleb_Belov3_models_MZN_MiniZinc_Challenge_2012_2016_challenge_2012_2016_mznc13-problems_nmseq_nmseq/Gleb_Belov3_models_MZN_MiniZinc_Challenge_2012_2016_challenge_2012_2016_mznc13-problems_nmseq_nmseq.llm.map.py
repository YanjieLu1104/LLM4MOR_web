import json
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reconstruct(payload):
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be an object")

    if "s" in variables and variables["s"] is not None:
        return {"variables": {"s": variables["s"]}}

    if "parameters" not in payload:
        raise ValueError(
            "Missing variables.s; parameters.n is required to determine "
            "whether the original sequence is empty"
        )

    parameters = payload["parameters"]
    if not isinstance(parameters, dict):
        raise ValueError("parameters must be an object")

    if "s" in parameters and parameters["s"] is not None:
        return {"variables": {"s": parameters["s"]}}

    if "n" not in parameters:
        raise ValueError(
            "Missing variables.s and original instance parameter parameters.n"
        )

    n = parameters["n"]
    if isinstance(n, bool) or not isinstance(n, int):
        raise ValueError("parameters.n must be an integer")

    if n <= 0:
        if "indices" in payload and "s" in payload["indices"]:
            index_sets = payload["indices"]["s"]
        else:
            index_sets = [{"range": [1, n]}]
        return {
            "variables": {
                "s": {
                    "array": [],
                    "index_sets": index_sets
                }
            }
        }

    raise ValueError(
        "Missing variables.s: the nonempty original sequence must be "
        "provided by the solver's default DZN solution"
    )


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object
        )

    result = reconstruct(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()