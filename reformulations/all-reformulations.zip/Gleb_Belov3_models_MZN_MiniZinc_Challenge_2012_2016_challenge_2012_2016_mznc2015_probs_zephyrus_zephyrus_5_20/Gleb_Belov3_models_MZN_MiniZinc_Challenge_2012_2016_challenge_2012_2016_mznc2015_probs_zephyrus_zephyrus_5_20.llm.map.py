import json
import math
import sys


LOCATIONS = (
    "c3_xlarge___0",
    "c3_xlarge___1",
    "c3_xlarge___2",
    "c3_xlarge___3",
    "c3_xlarge___4",
    "m3_medium___5",
    "m3_medium___6",
    "m3_medium___7",
    "m3_medium___8",
    "m3_medium___9",
    "m1_large___10",
    "m1_large___11",
    "m1_large___12",
    "m1_large___13",
    "m1_large___14",
    "m1_xlarge___15",
    "m1_xlarge___16",
    "m1_xlarge___17",
    "m1_xlarge___18",
    "m1_xlarge___19",
    "c3_large___20",
    "c3_large___21",
    "c3_large___22",
    "c3_large___23",
    "c3_large___24",
    "amazon_internals___25",
)

COMPONENTS = (
    "def___fredhoppercloudservices_platformserviceimpl_on",
    "def___fredhoppercloudservices_loadbalancerserviceimpl_on",
    "def___fredhoppercloudservices_deploymentserviceimpl_on",
    "def___fredhoppercloudservices_serviceproviderimpl_on",
    "def___fredhoppercloudservices_queryserviceimpl_on",
    "amazon_internals___fredhoppercloudservices_infrastructureserviceimpl_on",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def required(obj, key, source):
    if not isinstance(obj, dict) or key not in obj:
        raise ValueError("Missing required field " + source + "." + key)
    return obj[key]


def integer_value(value, source):
    if isinstance(value, bool):
        raise ValueError(source + " must be an integer, not a boolean")
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError(source + " must be a finite integer")


def check_index_set(encoded, size, source):
    if not isinstance(encoded, dict):
        raise ValueError(source + " must be an encoded index set")

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(source + ".range must contain two bounds")
        lower = integer_value(bounds[0], source + ".range[0]")
        upper = integer_value(bounds[1], source + ".range[1]")
        if lower != 1 or upper != size:
            raise ValueError(source + " must be the range 1.." + str(size))
        return

    if set(encoded) == {"set"}:
        members = encoded["set"]
        if not isinstance(members, list):
            raise ValueError(source + ".set must be a list")
        members = [
            integer_value(value, source + ".set[" + str(index) + "]")
            for index, value in enumerate(members)
        ]
        if len(members) != size or sorted(members) != list(range(1, size + 1)):
            raise ValueError(source + " must contain exactly 1.." + str(size))
        return

    raise ValueError(source + " must use set or range encoding")


def reconstruct(payload):
    variables = required(payload, "variables", "input")
    encoded = required(variables, "zrf_1_local", "input.variables")
    flat = required(encoded, "array", "input.variables.zrf_1_local")
    index_sets = required(encoded, "index_sets", "input.variables.zrf_1_local")

    if not isinstance(index_sets, list) or len(index_sets) != 2:
        raise ValueError("zrf_1_local.index_sets must contain two dimensions")

    check_index_set(
        index_sets[0], len(LOCATIONS), "zrf_1_local.index_sets[0]"
    )
    check_index_set(
        index_sets[1], len(COMPONENTS), "zrf_1_local.index_sets[1]"
    )

    expected_length = len(LOCATIONS) * len(COMPONENTS)
    if not isinstance(flat, list) or len(flat) != expected_length:
        raise ValueError(
            "zrf_1_local.array must contain "
            + str(expected_length)
            + " values"
        )

    values = [
        integer_value(value, "zrf_1_local.array[" + str(index) + "]")
        for index, value in enumerate(flat)
    ]

    restored = {}
    totals = [0 for _ in COMPONENTS]

    for row, location in enumerate(LOCATIONS):
        for column, component in enumerate(COMPONENTS):
            value = values[row * len(COMPONENTS) + column]
            restored["local_" + location + "_component_" + component] = value
            totals[column] += value

    for component, total in zip(COMPONENTS, totals):
        restored["global_component_" + component] = total

    restored["objective"] = (
        2 * (totals[0] + totals[1] + totals[3] + totals[4])
        + totals[2]
        + totals[5]
    )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    result = reconstruct(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(result, stream, allow_nan=False, sort_keys=True)
        stream.write("\n")


if __name__ == "__main__":
    main()