import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, list):
        for item in value:
            check_finite(item)
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)


def index_size(value, field):
    if not isinstance(value, dict):
        raise ValueError(field + " must use the MiniZinc set encoding")

    if set(value) == {"range"}:
        bounds = value["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(item) is not int for item in bounds)
        ):
            raise ValueError(field + ".range must contain two integers")
        return max(0, bounds[1] - bounds[0] + 1)

    if set(value) == {"set"}:
        elements = value["set"]
        if (
            not isinstance(elements, list)
            or any(type(item) is not int for item in elements)
        ):
            raise ValueError(field + ".set must contain integer indices")
        if len(set(elements)) != len(elements):
            raise ValueError(field + ".set contains duplicate indices")
        return len(elements)

    raise ValueError(field + " must contain exactly 'range' or 'set'")


def validate_array(value, name, dimensions):
    field = "variables." + name
    if not isinstance(value, dict):
        raise ValueError(field + " must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(field + " requires 'array' and 'index_sets'")

    elements = value["array"]
    indices = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError(field + ".array must be a list")
    if not isinstance(indices, list) or len(indices) != dimensions:
        raise ValueError(
            field + ".index_sets must contain "
            + str(dimensions) + " index sets"
        )

    expected = 1
    for position, domain in enumerate(indices):
        expected *= index_size(
            domain, field + ".index_sets[" + str(position) + "]"
        )

    if len(elements) != expected:
        raise ValueError(field + " element count does not match its index sets")
    if any(type(item) is not int for item in elements):
        raise ValueError(field + " must contain integer values")

    return {"array": elements, "index_sets": indices}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload)
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    restored = {}
    for name, dimensions in (("board", 2), ("fill", 2), ("npiece", 1)):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables."
                + name
                + " (required source: reformulated solver DZN solution)"
            )
        restored[name] = validate_array(variables[name], name, dimensions)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)