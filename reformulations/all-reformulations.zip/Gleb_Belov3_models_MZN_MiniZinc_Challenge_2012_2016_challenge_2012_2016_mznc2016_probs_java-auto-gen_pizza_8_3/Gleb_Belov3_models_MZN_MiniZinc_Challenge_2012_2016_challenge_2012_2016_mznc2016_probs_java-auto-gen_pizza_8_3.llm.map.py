import json
import math
import sys


CHOICE_SUFFIXES = (
    1530, 1581, 1632, 1683, 1734,
    2405, 2456, 2507, 2564, 2621, 2678, 2735,
    3496, 3553, 3610,
)

PIZZA_SUFFIXES = (
    1539, 1590, 1641, 1692, 1743,
    2414, 2465, 2516, 2573, 2630, 2687, 2744,
    3505, 3562, 3619,
)

BEFORE_SLICE_SUFFIXES = (
    1599, 1650, 1701, 1752, 2423, 2474, 2525,
    2582, 2639, 2696, 2753, 3514, 3571, 3628,
)

AFTER_SLICE_SUFFIXES = (
    2529, 2586, 2643, 2700, 2757, 3518, 3575, 3632,
)

FINAL_SLICE_SUFFIXES = (
    3722, 3788, 3854, 3920, 3986, 4052, 4118, 4184,
)

LOOSE_SLICE_SUFFIXES = (
    3726, 3792, 3858, 3924, 3990, 4056, 4122, 4188,
)

FULL_SUFFIXES = (
    2592, 2649, 2706, 2763, 3524, 3581, 3638,
    3783, 3849, 3915, 3981, 4047, 4113, 4179,
)

SLICE_COST_SUFFIXES = (
    3731, 3797, 3863, 3929, 3995, 4061, 4127, 4193,
    3739, 3805, 3871, 3937, 4003, 4069, 4135, 4201,
)

COST_SUFFIXES = (
    3804, 3870, 3936, 4002, 4068, 4134, 4200,
    3743, 3809, 3875, 3941, 4007, 4073, 4139, 4205,
)

RETURN_COST_SUFFIXES = (
    3747, 3813, 3879, 3945, 4011, 4077, 4143, 4209,
)

TOTAL_COST_SUFFIXES = (
    3772, 3838, 3904, 3970, 4036, 4102, 4168, 4214,
)


def names(prefix, suffixes):
    return [prefix + str(suffix) for suffix in suffixes]


def reject_constant(value):
    raise ValueError("Nonfinite JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite JSON number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            check_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def integer_value(value, name):
    if isinstance(value, bool):
        raise ValueError("Expected an integer for variables." + name)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("Expected a finite integer for variables." + name)


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("The input must be a JSON object")
    if "variables" not in document:
        raise ValueError("Missing required input field: variables")
    source = document["variables"]
    if not isinstance(source, dict):
        raise ValueError("The input field variables must be a JSON object")

    copied = []
    copied += names("chooseobj_", CHOICE_SUFFIXES)
    copied += names("pizza_", PIZZA_SUFFIXES)

    all_slice_suffixes = (
        BEFORE_SLICE_SUFFIXES
        + AFTER_SLICE_SUFFIXES
        + FINAL_SLICE_SUFFIXES
        + LOOSE_SLICE_SUFFIXES
    )
    copied += names("numSlices_", all_slice_suffixes)
    copied += names(
        "inumSlices_",
        BEFORE_SLICE_SUFFIXES
        + FINAL_SLICE_SUFFIXES
        + LOOSE_SLICE_SUFFIXES,
    )

    copied += names("fullPizzas_", FULL_SUFFIXES)
    copied += names("ifullPizzas_", FULL_SUFFIXES)
    copied += names("slicesCost_", SLICE_COST_SUFFIXES)
    copied += names("islicesCost_", SLICE_COST_SUFFIXES)
    copied += names("cost_", COST_SUFFIXES)
    copied += names("icost_", COST_SUFFIXES)
    copied += names("ret_getCost_", RETURN_COST_SUFFIXES)
    copied += names("totalcost_", TOTAL_COST_SUFFIXES)
    copied += ["ret_totalCost_4218", "objective"]

    fixed = []
    fixed += names("ipizza_", PIZZA_SUFFIXES)
    fixed += names("inumSlices_", AFTER_SLICE_SUFFIXES)
    fixed += names("iret_getCost_", RETURN_COST_SUFFIXES)
    fixed += names("itotalcost_", TOTAL_COST_SUFFIXES)
    fixed += ["iret_totalCost_4218", "iobjective"]

    if len(set(copied + fixed)) != len(copied + fixed):
        raise RuntimeError("The reconstruction manifest contains duplicate names")

    missing = [name for name in copied if name not in source]
    if missing:
        raise ValueError(
            "Missing required fields from the default DZN solution in variables: "
            + ", ".join(missing)
        )

    restored = {
        name: integer_value(source[name], name)
        for name in copied
    }

    for name in fixed:
        restored[name] = 1

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        document = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(document, "$")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(
            result,
            stream,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, RuntimeError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)