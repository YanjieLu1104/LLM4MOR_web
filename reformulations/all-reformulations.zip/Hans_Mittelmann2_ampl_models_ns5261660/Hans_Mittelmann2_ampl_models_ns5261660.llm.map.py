import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Invalid JSON numeric constant: " + value)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    for name, value in variables.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Non-numeric variable value: " + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Non-finite variable value: " + name)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump({"variables": variables}, destination, allow_nan=False)


if __name__ == "__main__":
    main()