import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 335,
    "nXNd__1_1_Y": 43,
    "nXNd__1_1_Z": 8,
    "nXNd__1_10_X": 315,
    "nXNd__1_10_Y": 54,
    "nXNd__1_10_Z": 93,
}

RETAINED_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{}; "
            "it must come from the reformulated model's default DZN solution."
            .format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in payload:
        raise ValueError("Missing required field variables.")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("The field variables must be a JSON object.")

    result = dict(FIXED_COORDINATES)

    for node in range(2, 10):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            result[name] = required_variable(variables, name)

    for name in RETAINED_ARRAYS:
        result[name] = required_variable(variables, name)

    result["obj"] = required_variable(variables, "obj")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload, "input")
    output = map_solution(payload)
    check_finite(output, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(output, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError, KeyError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)