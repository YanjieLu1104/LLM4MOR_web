import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            validate_finite(item, "{}[{}]".format(path, index))


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(path + " must be an integer")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError(path + " must be a finite integer")
    return int(value)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + " from the default DZN solution"
        )
    return variables[name]


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError(path + " must be an encoded index set")
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(path + ".range must contain two bounds")
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(path + ".set must be an array")
        decoded = [
            require_integer(item, path + ".set")
            for item in elements
        ]
        if len(decoded) != len(set(decoded)):
            raise ValueError(path + " contains duplicate indices")
        return sorted(decoded)
    raise ValueError(path + " must use the range or set encoding")


def copy_array(variables, name, expected_indices):
    value = require_variable(variables, name)
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError(path + " must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(path + " requires array and index_sets")
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError(path + " has malformed array encoding")
    if len(index_sets) != len(expected_indices):
        raise ValueError(path + " has the wrong number of dimensions")

    element_count = 1
    for dimension, (encoded, expected) in enumerate(
        zip(index_sets, expected_indices)
    ):
        actual = decode_index_set(
            encoded, "{}.index_sets[{}]".format(path, dimension)
        )
        if actual != expected:
            raise ValueError(path + " has an incorrect index domain")
        element_count *= len(actual)

    if len(elements) != element_count:
        raise ValueError(path + " has an incorrect element count")

    return {
        "array": [
            require_integer(item, "{}.array[{}]".format(path, position))
            for position, item in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    variables = payload["variables"]
    result = {}

    # These singleton domains are fixed in the self-contained original model.
    fixed_coordinates = {
        "nXNd__1_1_X": 212,
        "nXNd__1_1_Y": 58,
        "nXNd__1_1_Z": 115,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 43,
        "nXNd__1_10_Z": 113,
    }
    result.update(fixed_coordinates)

    # The original self-contained instance has eight intermediate nodes.
    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            result[name] = require_integer(
                require_variable(variables, name),
                "variables." + name,
            )

    node_indices = list(range(1, 11))
    coordinate_indices = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        result[name] = copy_array(
            variables, name, [node_indices, coordinate_indices]
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        result[name] = copy_array(variables, name, [node_indices])

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        result["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj from the default DZN solution "
            "and no non-null objective is available"
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    validate_finite(payload, "input")
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)