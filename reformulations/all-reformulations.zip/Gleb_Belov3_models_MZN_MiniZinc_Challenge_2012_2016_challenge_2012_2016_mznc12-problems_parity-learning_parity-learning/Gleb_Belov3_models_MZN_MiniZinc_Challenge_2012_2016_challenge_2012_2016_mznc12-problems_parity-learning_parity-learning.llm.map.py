import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("JSON numbers must be finite")
    if isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    variables = data["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    restored = {}
    for name in ("parity_bits", "computed_parities"):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables."
                + name
                + " (required from the default DZN solution)"
            )

        value = variables[name]
        if not isinstance(value, dict):
            raise ValueError("variables." + name + " must use array encoding")
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables." + name + " requires array and index_sets"
            )
        if not isinstance(value["array"], list):
            raise ValueError("variables." + name + ".array must be a list")
        if (
            not isinstance(value["index_sets"], list)
            or len(value["index_sets"]) != 1
        ):
            raise ValueError(
                "variables." + name + " must have exactly one index set"
            )
        if any(type(item) is not bool for item in value["array"]):
            raise ValueError(
                "variables." + name + " must contain Boolean elements"
            )

        restored[name] = {
            "array": value["array"],
            "index_sets": value["index_sets"],
        }

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump({"variables": restored}, target, allow_nan=False)
        target.write("\n")


if __name__ == "__main__":
    main()