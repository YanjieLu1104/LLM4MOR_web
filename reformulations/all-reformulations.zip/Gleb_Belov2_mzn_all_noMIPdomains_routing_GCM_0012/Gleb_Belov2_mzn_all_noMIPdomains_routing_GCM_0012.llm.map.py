import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{} from the default DZN "
            "solution of the reformulated model".format(name)
        )
    return variables[name]


def map_solution(payload):
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    variables = payload["variables"]
    restored = {}

    # These singleton domains are fixed data in the self-contained source.
    fixed_coordinates = {
        "nXNd__1_1_X": 65,
        "nXNd__1_1_Y": 114,
        "nXNd__1_1_Z": 80,
        "nXNd__1_10_X": 64,
        "nXNd__1_10_Y": 41,
        "nXNd__1_10_Z": 5,
    }
    restored.update(fixed_coordinates)

    # Every other original coordinate remains an independent scalar variable.
    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            restored[name] = require_variable(variables, name)

    # These original independent arrays retain their names, values, dimensions,
    # and index domains. Copy their complete MiniZinc JSON encodings.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        restored[name] = require_variable(variables, name)

    # obj is independent in the original source despite its defining constraint.
    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    else:
        if "objective" not in payload or payload["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; either the default DZN "
                "obj value or the reformulated solution objective is required"
            )
        value = payload["objective"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(value, float):
            if not math.isfinite(value) or not value.is_integer():
                raise ValueError("objective must be a finite integer-valued number")
        restored["obj"] = int(value)

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")

    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()