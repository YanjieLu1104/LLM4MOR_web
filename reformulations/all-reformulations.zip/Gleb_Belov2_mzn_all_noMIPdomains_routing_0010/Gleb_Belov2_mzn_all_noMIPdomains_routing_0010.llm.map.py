import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            validate_finite(item, "{}[{}]".format(path, position))


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{} from default DZN solver output"
            .format(name)
        )
    return variables[name]


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    variables = data["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 176,
        "nXNd__1_1_Y": 44,
        "nXNd__1_1_Z": 27,
        "nXNd__1_10_X": 210,
        "nXNd__1_10_Y": 83,
        "nXNd__1_10_Z": 45,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = required_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        restored[name] = required_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in data and data["objective"] is not None:
        objective = data["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be a finite integer-valued number")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj from default DZN output and missing objective"
        )

    result = {"variables": restored}
    validate_finite(result, "output")
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    validate_finite(data, "input")
    result = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()