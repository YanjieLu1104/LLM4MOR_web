import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    source = payload["variables"]
    if not isinstance(source, dict):
        raise ValueError("Field variables must be an object")

    restored = {}
    for name, value in source.items():
        if name.startswith(("X[", "Y[", "W[")):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("Expected numeric variable value: " + name)
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError("Non-finite variable value: " + name)
            restored[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": restored}, stream, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()