import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            check_finite(element, f"{path}[{index}]")
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; expected in the reformulated model's default DZN solution."
        )
    return variables[name]


def map_solution(data):
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid required field variables.")

    variables = data["variables"]
    result = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 302,
        "nXNd__1_1_Y": 54,
        "nXNd__1_1_Z": 20,
        "nXNd__1_10_X": 282,
        "nXNd__1_10_Y": 54,
        "nXNd__1_10_Z": 8,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = f"nXNd__1_{node}_{axis}"
            if name in fixed_coordinates:
                if name in variables and variables[name] is not None:
                    result[name] = variables[name]
                else:
                    result[name] = fixed_coordinates[name]
            else:
                result[name] = required_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        result[name] = required_variable(variables, name)

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(data, "input")
    mapped = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()