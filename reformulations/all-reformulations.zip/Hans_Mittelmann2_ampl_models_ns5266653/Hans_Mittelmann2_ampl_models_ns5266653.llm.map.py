import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict) or "variables" not in payload:
        raise ValueError("Missing required field: variables")

    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a dictionary")

    for name, value in variables.items():
        if not (
            isinstance(name, str)
            and name.endswith("]")
            and name.startswith(("X[", "Y[", "W["))
        ):
            raise ValueError("Unexpected variable: " + str(name))
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Variable must have a numeric value: " + name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Variable must have a finite value: " + name)

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump({"variables": variables}, target, allow_nan=False)
        target.write("\n")


if __name__ == "__main__":
    main()