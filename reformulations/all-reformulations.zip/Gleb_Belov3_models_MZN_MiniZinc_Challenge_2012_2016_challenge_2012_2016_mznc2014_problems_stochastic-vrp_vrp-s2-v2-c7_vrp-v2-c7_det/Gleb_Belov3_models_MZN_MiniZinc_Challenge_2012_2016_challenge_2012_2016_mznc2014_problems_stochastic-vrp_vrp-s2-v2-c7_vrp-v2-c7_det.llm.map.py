import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def validate_value(value, path):
    if value is None:
        raise ValueError("Missing solution value: " + path)
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite solution value: " + path)
    if isinstance(value, list):
        for index, element in enumerate(value):
            validate_value(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            validate_value(element, path + "." + key)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required input field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Input field variables must be a JSON object")

    original_names = (
        "successor",
        "predecessor",
        "vehicle",
        "arrivalTime",
        "objective",
    )
    restored = {}
    for name in original_names:
        if name not in variables:
            raise ValueError(
                "Missing required field variables.{}; "
                "expected from the reformulated model's default DZN solution"
                .format(name)
            )
        validate_value(variables[name], "variables." + name)
        restored[name] = variables[name]

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": restored},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    main()