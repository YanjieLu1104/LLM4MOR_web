import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite JSON number")
    elif isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data)

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data:
        raise ValueError("Missing required field: variables")
    if not isinstance(data["variables"], dict):
        raise ValueError("variables must be a JSON object")

    original_variables = {}
    for name in ("x", "y"):
        if name not in data["variables"]:
            raise ValueError(
                "Missing required field: variables."
                + name
                + " (required from the reformulated solver's DZN output)"
            )
        value = data["variables"][name]
        if value is None:
            raise ValueError("Missing value for variables." + name)
        original_variables[name] = value

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(
            {"variables": original_variables},
            destination,
            allow_nan=False,
            separators=(",", ":"),
        )
        destination.write("\n")


if __name__ == "__main__":
    main()