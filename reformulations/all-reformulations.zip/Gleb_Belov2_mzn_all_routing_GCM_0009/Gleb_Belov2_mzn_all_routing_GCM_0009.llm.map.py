import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution."
        )
    return variables[name]


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid input.variables")

    variables = payload["variables"]
    restored = {}

    # These six singleton domains are fixed data in the original main file.
    fixed_coordinates = {
        "nXNd__1_1_X": 309,
        "nXNd__1_1_Y": 106,
        "nXNd__1_1_Z": 80,
        "nXNd__1_10_X": 302,
        "nXNd__1_10_Y": 60,
        "nXNd__1_10_Z": 54,
    }

    # All original independent coordinate variables are retained.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = required(variables, name)

    # Copy the complete encoded arrays, preserving their original index sets.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        restored[name] = required(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in payload and payload["objective"] is not None:
        objective = payload["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("input.objective must be a finite integer-valued number")
        if isinstance(objective, float) and not objective.is_integer():
            raise ValueError("input.objective is not integer-valued")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj and input.objective; "
            "the original independent objective variable must be restored."
        )

    check_finite(restored, "output.variables")
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump({"variables": restored}, target, allow_nan=False)
        target.write("\n")


if __name__ == "__main__":
    main()