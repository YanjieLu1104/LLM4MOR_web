import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("Expected an integer at " + path)
    return value


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        members = value["set"]
        if not isinstance(members, list):
            raise ValueError("Invalid set at " + path)
        for position, member in enumerate(members):
            require_integer(member, path + ".set[" + str(position) + "]")
        if len(set(members)) != len(members):
            raise ValueError("Duplicate index at " + path)
        return sorted(members)
    raise ValueError("Invalid index-set encoding at " + path)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables."
            + name
            + "; required source is the reformulated solver's default DZN solution"
        )
    return variables[name]


def validate_vessel_array(value, name):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    domains = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError("Expected a flattened array at " + path + ".array")
    if not isinstance(domains, list) or len(domains) != 1:
        raise ValueError("Expected one index domain at " + path + ".index_sets")

    # These dimensions are fixed in the original main model: vv = 9,
    # VESSELS = 1..vv. They are not external instance data.
    expected = list(range(1, 10))
    actual = decode_index_set(domains[0], path + ".index_sets[0]")
    if actual != expected or len(elements) != len(expected):
        raise ValueError("Array domain or length differs from VESSELS at " + path)
    for position, element in enumerate(elements):
        require_integer(element, path + ".array[" + str(position) + "]")
    return {"array": elements, "index_sets": domains}


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = payload["variables"]
    restored = {}

    for name in ["poAct" + str(position) for position in range(9)] + ["piPort"]:
        restored[name] = require_integer(
            require_variable(variables, name), "variables." + name
        )

    for name in ("piWeek", "directCost"):
        restored[name] = validate_vessel_array(
            require_variable(variables, name), name
        )

    # REPOSTYPES = 1..3, with types 2 and 3 prohibited for every vessel.
    # Reconstruct this array even when compiler propagation removes it
    # from the default DZN solution.
    restored["reposType"] = {
        "array": [1] * 9,
        "index_sets": [{"range": [1, 9]}],
    }

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)