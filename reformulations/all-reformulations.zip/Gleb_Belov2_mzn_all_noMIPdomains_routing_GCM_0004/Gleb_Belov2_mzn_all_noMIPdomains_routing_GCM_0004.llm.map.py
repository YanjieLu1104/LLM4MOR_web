import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 212,
    "nXNd__1_1_Y": 58,
    "nXNd__1_1_Z": 115,
    "nXNd__1_10_X": 245,
    "nXNd__1_10_Y": 43,
    "nXNd__1_10_Z": 113,
}

ORIGINAL_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution"
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = payload["variables"]
    restored = {}

    # This self-contained original instance explicitly declares ten nodes.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in FIXED_COORDINATES:
                restored[name] = FIXED_COORDINATES[name]
            else:
                restored[name] = required_variable(variables, name)

    # Retain the complete MiniZinc array encoding, including its index sets.
    for name in ORIGINAL_ARRAYS:
        restored[name] = required_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in payload and payload["objective"] is not None:
        objective = payload["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be a finite integer-valued number")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj and objective; "
            "one must provide the reformulated solution's objective value"
        )

    check_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, ensure_ascii=False)
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)